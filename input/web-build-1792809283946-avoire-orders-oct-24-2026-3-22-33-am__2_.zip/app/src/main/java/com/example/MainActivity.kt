package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.People
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DecantItem
import com.example.data.OrderEntity
import com.example.data.OrderStatus
import com.example.ui.AvoireViewModel
import com.example.ui.BottomNavTab
import com.example.ui.components.AvoireTopBar
import com.example.ui.components.BackupRestoreDialog
import com.example.ui.components.FeedbackToastBar
import com.example.ui.components.LowStockBanner
import com.example.ui.components.NotificationsSheet
import com.example.ui.screens.AiAddOrderScreen
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.FlaconsScreen
import com.example.ui.screens.OrderEditorSheet
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.ShipmentsScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoireOrdersTheme
import com.example.ui.theme.AvoireSoftViolet
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary
import com.example.ui.theme.StatusCoralText
import com.example.ui.theme.StatusEmeraldText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: AvoireViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AvoireBackground.toArgb()),
            navigationBarStyle = SystemBarStyle.dark(AvoireCard.toArgb())
        )
        setContent {
            AvoireOrdersTheme {
                AvoireOrdersMainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AvoireOrdersMainApp(viewModel: AvoireViewModel) {
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val flacons by viewModel.flacons.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedStatusFilter by viewModel.selectedStatusFilter.collectAsStateWithLifecycle()
    val editingOrder by viewModel.editingOrder.collectAsStateWithLifecycle()

    val aiConversationText by viewModel.aiConversationText.collectAsStateWithLifecycle()
    val aiSelectedUris by viewModel.aiSelectedUris.collectAsStateWithLifecycle()
    val isAnalyzingAi by viewModel.isAnalyzingAi.collectAsStateWithLifecycle()
    val aiAnalysisResult by viewModel.aiAnalysisResult.collectAsStateWithLifecycle()

    val bannerMessage by viewModel.bannerMessage.collectAsStateWithLifecycle()
    val lowStockWarningBanner by viewModel.lowStockWarningBanner.collectAsStateWithLifecycle()

    var showNotificationsSheet by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var hasNotificationPermission by remember {
        mutableStateOf(viewModel.notificationHelper.hasNotificationPermission())
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
        if (granted) {
            viewModel.showFeedback("Włączono powiadomienia Push o statusach zamówień")
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val createBackupDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            viewModel.exportBackupToUri(uri)
        }
    }

    val openBackupDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importBackupFromUri(uri)
        }
    }

    // BackHandler dla zakładek podrzędnych
    if (selectedTab != BottomNavTab.ORDERS) {
        BackHandler {
            viewModel.selectTab(BottomNavTab.ORDERS)
        }
    }

    val unreadNotificationsCount = remember(notifications) {
        notifications.count { !it.isRead }
    }
    val lowStockCount = remember(flacons) {
        flacons.count { it.isLowStock }
    }
    val readyShipmentsCount = remember(orders) {
        orders.count { it.status == OrderStatus.READY_TO_SHIP }
    }
    val pendingTasksCount = remember(tasks) {
        tasks.count { !it.isDone }
    }

    val bottomTabs = remember {
        listOf(
            BottomNavTab.ORDERS,
            BottomNavTab.AI_ADD,
            BottomNavTab.FLACONS,
            BottomNavTab.CUSTOMERS,
            BottomNavTab.SHIPMENTS
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = AvoireBackground,
        topBar = {
            Column {
                AvoireTopBar(
                    selectedTab = selectedTab,
                    ordersCount = orders.size,
                    flaconsCount = flacons.size,
                    pendingTasksCount = pendingTasksCount,
                    unreadNotificationsCount = unreadNotificationsCount,
                    onSelectTab = viewModel::selectTab,
                    onAddClick = {
                        viewModel.openOrderEditor(
                            OrderEntity(
                                customerName = "",
                                deadline = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                                items = listOf(
                                    DecantItem(
                                        perfumeName = flacons.firstOrNull()?.fullName ?: "Ataraxia Deity",
                                        capacityMl = 5,
                                        quantity = 1
                                    )
                                )
                            )
                        )
                    },
                    onOpenNotifications = {
                        viewModel.markNotificationsRead()
                        showNotificationsSheet = true
                    },
                    onOpenBackupDialog = {
                        showBackupDialog = true
                    }
                )
                LowStockBanner(
                    message = lowStockWarningBanner,
                    onDismiss = { viewModel.dismissLowStockWarning() },
                    onGoToFlacons = {
                        viewModel.dismissLowStockWarning()
                        viewModel.selectTab(BottomNavTab.FLACONS)
                    }
                )
                FeedbackToastBar(
                    message = bannerMessage,
                    onDismiss = { viewModel.dismissBanner() }
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = AvoireCard,
                contentColor = AvoireTextPrimary,
                tonalElevation = 8.dp
            ) {
                bottomTabs.forEach { tab ->
                    val selected = selectedTab == tab
                    val (selectedIcon, unselectedIcon) = when (tab) {
                        BottomNavTab.ORDERS -> Icons.Filled.Inventory2 to Icons.Outlined.Inventory2
                        BottomNavTab.AI_ADD -> Icons.Filled.AutoAwesome to Icons.Outlined.AutoAwesome
                        BottomNavTab.FLACONS -> Icons.Filled.Inventory2 to Icons.Outlined.Inventory2
                        BottomNavTab.CUSTOMERS -> Icons.Filled.People to Icons.Outlined.People
                        BottomNavTab.TASKS -> Icons.Filled.CheckBox to Icons.Outlined.CheckBox
                        BottomNavTab.SHIPMENTS -> Icons.Filled.LocalShipping to Icons.Outlined.LocalShipping
                    }

                    NavigationBarItem(
                        selected = selected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    when (tab) {
                                        BottomNavTab.FLACONS -> if (lowStockCount > 0) {
                                            Badge(
                                                containerColor = StatusCoralText,
                                                contentColor = AvoireBackground
                                            ) {
                                                Text(lowStockCount.toString())
                                            }
                                        }
                                        BottomNavTab.SHIPMENTS -> if (readyShipmentsCount > 0) {
                                            Badge(
                                                containerColor = StatusEmeraldText,
                                                contentColor = AvoireBackground
                                            ) {
                                                Text(readyShipmentsCount.toString())
                                            }
                                        }
                                        else -> Unit
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (selected) selectedIcon else unselectedIcon,
                                    contentDescription = tab.labelPl
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.labelPl,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AvoireLavenderAccent,
                            selectedTextColor = AvoireLavenderAccent,
                            indicatorColor = AvoireSoftViolet,
                            unselectedIconColor = AvoireTextSecondary,
                            unselectedTextColor = AvoireTextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                BottomNavTab.ORDERS -> {
                    OrdersScreen(
                        orders = orders,
                        tasks = tasks,
                        searchQuery = searchQuery,
                        selectedStatusFilter = selectedStatusFilter,
                        onSearchChange = viewModel::updateSearchQuery,
                        onStatusFilterChange = viewModel::selectStatusFilter,
                        onOpenNewOrder = {
                            viewModel.openOrderEditor(
                                OrderEntity(
                                    customerName = "",
                                    deadline = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                                    items = listOf(
                                        DecantItem(
                                            perfumeName = flacons.firstOrNull()?.fullName ?: "Ataraxia Deity",
                                            capacityMl = 5,
                                            quantity = 1
                                        )
                                    )
                                )
                            )
                        },
                        onOpenAiTab = { viewModel.selectTab(BottomNavTab.AI_ADD) },
                        onOpenTasksTab = { viewModel.selectTab(BottomNavTab.TASKS) },
                        onToggleTaskDone = viewModel::toggleWorkshopTask,
                        onEditOrder = { viewModel.openOrderEditor(it) },
                        onToggleDecantReady = { orderId, decantId, ready ->
                            viewModel.toggleDecantReady(orderId, decantId, ready)
                        },
                        onToggleOrderPacked = viewModel::toggleOrderPacked,
                        onAdvanceStatus = { order, nextStatus ->
                            viewModel.changeOrderStatus(order.id, nextStatus)
                        },
                        onTogglePaid = { orderId, isPaid ->
                            viewModel.toggleOrderPaid(orderId, isPaid)
                        },
                        onCopyFeedback = viewModel::showFeedback
                    )
                }

                BottomNavTab.AI_ADD -> {
                    AiAddOrderScreen(
                        conversationText = aiConversationText,
                        selectedUris = aiSelectedUris,
                        isAnalyzing = isAnalyzingAi,
                        analysisResult = aiAnalysisResult,
                        knownFlacons = flacons,
                        onConversationTextChange = viewModel::updateAiConversationText,
                        onScreenshotsSelected = viewModel::setAiScreenshots,
                        onRemoveScreenshot = viewModel::removeAiScreenshot,
                        onLoadSampleConversation = viewModel::loadSampleConversationForAi,
                        onRunAnalysis = viewModel::runAiAnalysis,
                        onUpdateDraft = viewModel::updateAiDraftOrder,
                        onConfirmAndSaveDraft = viewModel::confirmAndSaveAiDraft,
                        onClearDraft = viewModel::clearAiDraft
                    )
                }

                BottomNavTab.FLACONS -> {
                    FlaconsScreen(
                        flacons = flacons,
                        onSaveFlacon = viewModel::saveFlacon,
                        onAdjustMl = viewModel::adjustFlaconMl,
                        onSetVolumeMl = viewModel::setFlaconVolumeMl,
                        onBulkAddFlacons = viewModel::bulkAddFlaconsFromText,
                        onDeleteFlacon = viewModel::deleteFlacon
                    )
                }

                BottomNavTab.CUSTOMERS -> {
                    CustomersScreen(
                        customers = customers,
                        orders = orders,
                        onSaveCustomer = viewModel::saveCustomer,
                        onDeleteCustomer = viewModel::deleteCustomer,
                        onCreateOrderForCustomer = { customer ->
                            viewModel.openOrderEditor(
                                OrderEntity(
                                    customerName = customer.name,
                                    customerId = customer.id,
                                    recipientName = customer.name,
                                    phone = customer.phone,
                                    email = customer.email,
                                    paczkomatCode = customer.defaultPaczkomat,
                                    street = customer.street,
                                    postalCode = customer.postalCode,
                                    city = customer.city,
                                    deadline = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                                    items = listOf(
                                        DecantItem(
                                            perfumeName = customer.favoriteScents.firstOrNull()
                                                ?: flacons.firstOrNull()?.fullName
                                                ?: "Ataraxia Deity",
                                            capacityMl = 5,
                                            quantity = 1
                                        )
                                    )
                                )
                            )
                        },
                        onEditOrder = { viewModel.openOrderEditor(it) },
                        onCopyFeedback = viewModel::showFeedback
                    )
                }

                BottomNavTab.TASKS -> {
                    TasksScreen(
                        tasks = tasks,
                        onAddTask = viewModel::addWorkshopTask,
                        onToggleTask = viewModel::toggleWorkshopTask,
                        onDeleteTask = viewModel::deleteWorkshopTask
                    )
                }

                BottomNavTab.SHIPMENTS -> {
                    ShipmentsScreen(
                        orders = orders,
                        onMarkAsShipped = { order, trackingNumber ->
                            viewModel.changeOrderStatus(
                                orderId = order.id,
                                newStatus = OrderStatus.SHIPPED,
                                trackingNumber = trackingNumber
                            )
                        },
                        onMarkReadyToShip = { order ->
                            viewModel.changeOrderStatus(
                                orderId = order.id,
                                newStatus = OrderStatus.READY_TO_SHIP
                            )
                        },
                        onEditOrder = { viewModel.openOrderEditor(it) },
                        onCopyFeedback = viewModel::showFeedback
                    )
                }
            }
        }
    }

    // Modal edycji / tworzenia zamówienia
    editingOrder?.let { orderToEdit ->
        OrderEditorSheet(
            initialOrder = orderToEdit,
            knownCustomers = customers,
            knownFlacons = flacons,
            onSave = { updated -> viewModel.saveOrder(updated) },
            onDelete = { id -> viewModel.deleteOrder(id) },
            onDismiss = { viewModel.openOrderEditor(null) }
        )
    }

    // Dolny arkusz powiadomień push i szablonów dla klienta
    if (showNotificationsSheet) {
        NotificationsSheet(
            notifications = notifications,
            hasPermission = hasNotificationPermission,
            onRequestPermission = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            },
            onSendTestPush = { viewModel.sendTestPushNotification() },
            onClearAll = { viewModel.clearAllNotifications() },
            onCopyFeedback = { viewModel.showFeedback(it) },
            onDismiss = { showNotificationsSheet = false }
        )
    }

    // Okno Kopia zapasowa JSON & Powiadomienia Push
    if (showBackupDialog) {
        val dateStamp = remember {
            SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        }
        BackupRestoreDialog(
            ordersCount = orders.size,
            flaconsCount = flacons.size,
            customersCount = customers.size,
            unreadNotificationsCount = unreadNotificationsCount,
            onOpenNotificationsSheet = {
                viewModel.markNotificationsRead()
                showNotificationsSheet = true
            },
            onShareJsonFile = { viewModel.shareBackupJsonFile() },
            onSaveJsonToFile = {
                createBackupDocLauncher.launch("avoire_backup_$dateStamp.json")
            },
            onImportJsonFromFile = {
                openBackupDocLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
            },
            onImportRawJson = { raw -> viewModel.importBackupFromRawJson(raw) },
            onResetDemoData = { viewModel.resetDemoData() },
            onDismiss = { showBackupDialog = false }
        )
    }
}
