package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.example.BuildConfig
import com.example.data.CarrierType
import com.example.data.CustomerEntity
import com.example.data.DecantItem
import com.example.data.FlaconEntity
import com.example.data.OrderEntity
import com.example.data.OrderStatus
import com.example.data.generateOrderTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

// --- Gemini REST API Data Classes ---

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String? = null,
    val inlineData: InlineData? = null
)

@Serializable
data class InlineData(
    val mimeType: String,
    val data: String
)

@Serializable
data class GenerationConfig(
    val responseMimeType: String? = null,
    val responseSchema: JsonObject? = null,
    val temperature: Float? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate> = emptyList()
)

@Serializable
data class Candidate(
    val content: Content? = null
)

// --- Structured Output Model for Parsed Order ---

@Serializable
data class AiParsedItemDto(
    val perfumeName: String = "",
    val capacityMl: Int = 5,
    val quantity: Int = 1,
    val isGratis: Boolean = false,
    val needsAvailabilityCheck: Boolean = false,
    val note: String = ""
)

@Serializable
data class AiParsedOrderDto(
    val customerName: String = "",
    val recipientName: String = "",
    val phone: String = "",
    val email: String = "",
    val paczkomatCode: String = "",
    val street: String = "",
    val postalCode: String = "",
    val city: String = "",
    val carrier: String = "INPOST_LOCKER",
    val orderPricePln: Double = 0.0,
    val shippingCostPln: Double = 17.0,
    val isPaid: Boolean = false,
    val deadline: String = "",
    val items: List<AiParsedItemDto> = emptyList(),
    val detectedChanges: List<String> = emptyList(),
    val toConfirm: List<String> = emptyList(),
    val notes: String = ""
)

data class AiAnalysisResult(
    val draftOrder: OrderEntity,
    val matchedCustomer: CustomerEntity?,
    val usedEngine: String, // "Gemini AI (Vision + Tekst)" or "Parser lokalny (Offline)"
    val warningMessage: String? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiRetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GeminiApiService::class.java)
    }

    fun decodeOrderDto(rawJson: String): AiParsedOrderDto {
        val cleaned = rawJson
            .trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        return json.decodeFromString<AiParsedOrderDto>(cleaned)
    }
}

object AvoireAiParser {

    suspend fun analyzeConversation(
        context: Context,
        conversationText: String,
        imageUris: List<Uri>,
        knownFlacons: List<FlaconEntity>,
        knownCustomers: List<CustomerEntity>,
        preferLocalOnly: Boolean = false
    ): AiAnalysisResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val canUseGemini = !preferLocalOnly &&
                apiKey.isNotBlank() &&
                apiKey != "MY_GEMINI_API_KEY" &&
                (conversationText.isNotBlank() || imageUris.isNotEmpty())

        if (canUseGemini) {
            try {
                val parts = mutableListOf<Part>()
                imageUris.forEach { uri ->
                    uriToBase64Jpeg(context, uri)?.let { base64 ->
                        parts.add(
                            Part(
                                inlineData = InlineData(
                                    mimeType = "image/jpeg",
                                    data = base64
                                )
                            )
                        )
                    }
                }

                val flaconCatalogSummary = knownFlacons.joinToString("; ") {
                    "${it.fullName} (stan: ${it.currentVolumeMl} ml, cena: ${it.pricePerMlPln} zł/ml)"
                }
                val customerCatalogSummary = knownCustomers.joinToString("; ") {
                    "${it.name} (tel: ${it.phone}, paczkomat: ${it.defaultPaczkomat}, email: ${it.email})"
                }

                val promptText = buildString {
                    appendLine("Przeanalizuj zrzuty ekranu i/lub tekst rozmowy dotyczącej zamówienia odlewek perfum w perfumerii Avoire.")
                    appendLine("Dostępne flakony w bazie Avoire: $flaconCatalogSummary")
                    appendLine("Znani klienci w bazie Avoire: $customerCatalogSummary")
                    appendLine()
                    appendLine("ZASADY KRYTYCZNE:")
                    appendLine("1. Wyodrębnij pełną listę zamówionych odlewek (perfumeName, capacityMl, quantity, isGratis, needsAvailabilityCheck, note).")
                    appendLine("2. Uwzględnij kontekst całej rozmowy: jeśli klient w trakcie pisania zmienił zapach lub pojemność (np. 'jednak zamiast X wezmę Y' albo 'zmień 5ml na 10ml'), w polu 'items' umieść WYŁĄCZNIE ostateczną aktualną wersję, a opis zmiany dodaj do 'detectedChanges' (np. 'Zamiana Baccarat Rouge na Nishane Ani 5 ml').")
                    appendLine("3. Odróżniaj pozycje płatne od gratisów ('gratis', 'próbka', 'do powąchania' -> isGratis = true).")
                    appendLine("4. Wyciągnij dane wysyłki: kod Paczkomatu (np. WAW242M, KRA01A), 9-cyfrowy numer telefonu, e-mail, ulicę, kod pocztowy, miasto oraz przewoźnika (INPOST_LOCKER, INPOST_COURIER, DPD, ORLEN).")
                    appendLine("5. NIGDY nie zgaduj brakujących danych! Wszystko, czego brakuje lub co jest niepewne (np. brak kodu Paczkomatu, brak telefonu, niepotwierdzona pojemność, pytanie o gratis), dodaj do listy 'toConfirm'.")
                    appendLine()
                    if (conversationText.isNotBlank()) {
                        appendLine("TEKST ROZMOWY:")
                        appendLine(conversationText)
                    } else {
                        appendLine("Odczytaj wszystkie wiadomości ze załączonych zrzutów ekranu.")
                    }
                }
                parts.add(Part(text = promptText))

                val schema = buildJsonObject {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("customerName") { put("type", "STRING") }
                        putJsonObject("recipientName") { put("type", "STRING") }
                        putJsonObject("phone") { put("type", "STRING") }
                        putJsonObject("email") { put("type", "STRING") }
                        putJsonObject("paczkomatCode") { put("type", "STRING") }
                        putJsonObject("street") { put("type", "STRING") }
                        putJsonObject("postalCode") { put("type", "STRING") }
                        putJsonObject("city") { put("type", "STRING") }
                        putJsonObject("carrier") { put("type", "STRING") }
                        putJsonObject("orderPricePln") { put("type", "NUMBER") }
                        putJsonObject("shippingCostPln") { put("type", "NUMBER") }
                        putJsonObject("isPaid") { put("type", "BOOLEAN") }
                        putJsonObject("deadline") { put("type", "STRING") }
                        putJsonObject("notes") { put("type", "STRING") }
                        putJsonObject("detectedChanges") {
                            put("type", "ARRAY")
                            putJsonObject("items") { put("type", "STRING") }
                        }
                        putJsonObject("toConfirm") {
                            put("type", "ARRAY")
                            putJsonObject("items") { put("type", "STRING") }
                        }
                        putJsonObject("items") {
                            put("type", "ARRAY")
                            putJsonObject("items") {
                                put("type", "OBJECT")
                                putJsonObject("properties") {
                                    putJsonObject("perfumeName") { put("type", "STRING") }
                                    putJsonObject("capacityMl") { put("type", "INTEGER") }
                                    putJsonObject("quantity") { put("type", "INTEGER") }
                                    putJsonObject("isGratis") { put("type", "BOOLEAN") }
                                    putJsonObject("needsAvailabilityCheck") { put("type", "BOOLEAN") }
                                    putJsonObject("note") { put("type", "STRING") }
                                }
                            }
                        }
                    }
                }

                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = parts)),
                    generationConfig = GenerationConfig(
                        responseMimeType = "application/json",
                        responseSchema = schema,
                        temperature = 0.15f
                    )
                )

                val response = GeminiRetrofitClient.service.generateContent(apiKey, request)
                val rawText = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!rawText.isNullOrBlank()) {
                    val dto = GeminiRetrofitClient.decodeOrderDto(rawText)
                    return@withContext enrichAndMatchOrder(
                        dto = dto,
                        knownFlacons = knownFlacons,
                        knownCustomers = knownCustomers,
                        engineLabel = "Gemini AI (Vision + Tekst)"
                    )
                }
            } catch (e: Exception) {
                val localFallback = parseLocally(
                    conversationText = conversationText,
                    knownFlacons = knownFlacons,
                    knownCustomers = knownCustomers
                )
                return@withContext localFallback.copy(
                    warningMessage = "Użyto szybkiego parsera lokalnego (błąd połączenia Gemini API lub brak klucza w Secrets: ${e.localizedMessage ?: "nieznany błąd"})."
                )
            }
        }

        val fallbackReason = if (preferLocalOnly) {
            null
        } else if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            "Klucz GEMINI_API_KEY nie został jeszcze ustawiony w panelu Secrets AI Studio — użyto wbudowanego parsera lokalnego Avoire."
        } else {
            null
        }

        parseLocally(
            conversationText = conversationText,
            knownFlacons = knownFlacons,
            knownCustomers = knownCustomers
        ).copy(warningMessage = fallbackReason)
    }

    fun parseLocally(
        conversationText: String,
        knownFlacons: List<FlaconEntity>,
        knownCustomers: List<CustomerEntity>
    ): AiAnalysisResult {
        val text = conversationText.trim()
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }

        val detectedChanges = mutableListOf<String>()
        val toConfirm = mutableListOf<String>()

        // 1. Extract phone (Polish 9-digit number)
        val phoneRegex = Regex("""(?:\+?48[\s-]?)?(\d{3}[\s-]?\d{3}[\s-]?\d{3})""")
        val rawPhone = phoneRegex.find(text)?.groupValues?.getOrNull(1)?.replace(Regex("""[\s-]"""), "") ?: ""

        // 2. Extract email
        val emailRegex = Regex("""[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}""")
        val email = emailRegex.find(text)?.value ?: ""

        // 3. Extract InPost Paczkomat code (e.g. WAW242M, KRA01A, GDN118M, POZ44N)
        val paczkomatRegex = Regex("""\b([A-Z]{3}\d{2,4}[A-Z]{1,2})\b""")
        val paczkomatFromText = paczkomatRegex.find(text.uppercase())?.groupValues?.getOrNull(1) ?: ""

        // 4. Detect carrier
        val lowerText = text.lowercase()
        val carrier = when {
            lowerText.contains("dpd") -> CarrierType.DPD
            lowerText.contains("orlen") -> CarrierType.ORLEN
            lowerText.contains("kurier") && !lowerText.contains("paczkomat") -> CarrierType.INPOST_COURIER
            else -> CarrierType.INPOST_LOCKER
        }

        // 5. Detect customer name from text or knownCustomers
        var customerName = ""
        val namePrefixes = listOf("klient:", "odbiorca:", "imię i nazwisko:", "od:", "zamawiający:")
        for (line in lines) {
            val low = line.lowercase()
            val matchedPrefix = namePrefixes.firstOrNull { low.startsWith(it) }
            if (matchedPrefix != null) {
                customerName = line.substring(matchedPrefix.length).trim()
                break
            }
        }
        if (customerName.isBlank()) {
            knownCustomers.firstOrNull { cust ->
                (cust.phone.isNotBlank() && cust.phone == rawPhone) ||
                        text.contains(cust.name, ignoreCase = true) ||
                        (cust.NameFirstPart().length >= 3 && text.contains(cust.NameFirstPart(), ignoreCase = true))
            }?.let { matched ->
                customerName = matched.name
            }
        }

        // 6. Parse scent items and conversation changes line by line
        val parsedItems = mutableListOf<AiParsedItemDto>()
        val changeKeywords = listOf("zamiast", "zamień", "zamiana", "jednak", "zmieniam", "rezygnuję z")

        val itemLinePattern = Regex(
            pattern = """^(?:[-•*]\s*)?(?:(\d+)\s*[xX×]\s*)?([A-Za-zÀ-ž0-9\s'&./-]+?)\s+(\d{1,3})\s*ml\b(.*)$""",
            option = RegexOption.IGNORE_CASE
        )

        for (line in lines) {
            val lowerLine = line.lowercase()

            // Check if the line describes a change in the conversation
            if (changeKeywords.any { lowerLine.contains(it) }) {
                detectedChanges.add(line)

                // Handle "zamiast X ... wezmę/poproszę Y 10 ml"
                val insteadSplit = lowerLine.split("zamiast")
                if (insteadSplit.size > 1) {
                    val afterInstead = line.substringAfter("zamiast", "")
                    val replacementKeywords = listOf("wezmę", "poproszę", "będzie", "daj", "na ")
                    val repKey = replacementKeywords.firstOrNull { afterInstead.lowercase().contains(it) }
                    if (repKey != null) {
                        val oldPart = afterInstead.substringBefore(repKey, "").trim()
                        val newPart = afterInstead.substringAfter(repKey, "").trim()
                        if (oldPart.isNotBlank()) {
                            parsedItems.removeAll { existing ->
                                oldPart.contains(existing.perfumeName.take(6), ignoreCase = true) ||
                                        existing.perfumeName.contains(oldPart.take(6), ignoreCase = true)
                            }
                        }
                        parseSingleScentCandidate(newPart, knownFlacons)?.let { newItem ->
                            parsedItems.removeAll { it.perfumeName.equals(newItem.perfumeName, ignoreCase = true) && !it.isGratis }
                            parsedItems.add(newItem)
                        }
                        continue
                    }
                }
            }

            // Skip pure address/contact lines
            if (lowerLine.startsWith("tel") ||
                lowerLine.startsWith("paczkomat") ||
                lowerLine.startsWith("mail") ||
                lowerLine.startsWith("e-mail") ||
                lowerLine.startsWith("ul.") ||
                lowerLine.startsWith("adres")
            ) {
                continue
            }

            val match = itemLinePattern.find(line)
            if (match != null) {
                val qty = match.groupValues[1].toIntOrNull() ?: 1
                val rawName = match.groupValues[2]
                    .replace(Regex("""^(poproszę|wezmę|jeszcze|oraz|i|dodatkowo|zamawiam)\s+""", RegexOption.IGNORE_CASE), "")
                    .trim()
                val cap = match.groupValues[3].toIntOrNull() ?: 5
                val tail = match.groupValues[4].trim()
                val isGratis = lowerLine.contains("gratis") ||
                        lowerLine.contains("próbk") ||
                        lowerLine.contains("do powąchania") ||
                        lowerLine.contains("sample")

                val canonicalName = matchKnownFlaconName(rawName, knownFlacons)
                if (canonicalName.length >= 2) {
                    // If "jednak" or update for same scent, replace capacity
                    val existingIndex = parsedItems.indexOfFirst {
                        it.perfumeName.equals(canonicalName, ignoreCase = true) && it.isGratis == isGratis
                    }
                    val dto = AiParsedItemDto(
                        perfumeName = canonicalName,
                        capacityMl = cap,
                        quantity = qty,
                        isGratis = isGratis,
                        needsAvailabilityCheck = false,
                        note = if (isGratis) "Gratis / Próbka" else tail.trim('-', ',', ' ')
                    )
                    if (existingIndex >= 0 && changeKeywords.any { lowerLine.contains(it) }) {
                        val previous = parsedItems[existingIndex]
                        detectedChanges.add("Zmiana $canonicalName z ${previous.capacityMl} ml na $cap ml")
                        parsedItems[existingIndex] = dto
                    } else {
                        parsedItems.add(dto)
                    }
                }
            } else {
                // Also check if a known flacon is mentioned without explicit ml (uncertain capacity!)
                knownFlacons.forEach { flacon ->
                    if (lowerLine.contains(flacon.scentName.lowercase()) &&
                        parsedItems.none { it.perfumeName.contains(flacon.scentName, ignoreCase = true) }
                    ) {
                        val mlMatch = Regex("""(\d{1,3})\s*ml""", RegexOption.IGNORE_CASE).find(line)
                        val cap = mlMatch?.groupValues?.getOrNull(1)?.toIntOrNull()
                        val isGratis = lowerLine.contains("gratis") || lowerLine.contains("próbk") || lowerLine.contains("do powąchania")
                        if (cap != null) {
                            parsedItems.add(
                                AiParsedItemDto(
                                    perfumeName = flacon.fullName,
                                    capacityMl = cap,
                                    quantity = 1,
                                    isGratis = isGratis,
                                    note = if (isGratis) "Gratis / Próbka" else ""
                                )
                            )
                        } else {
                            parsedItems.add(
                                AiParsedItemDto(
                                    perfumeName = flacon.fullName,
                                    capacityMl = 5,
                                    quantity = 1,
                                    isGratis = isGratis,
                                    note = "Do potwierdzenia pojemność"
                                )
                            )
                            toConfirm.add("Potwierdzić pojemność odlewki ${flacon.fullName} (brak ml w wiadomości)")
                        }
                    }
                }
            }
        }

        // Check if customer asked about a gratis without specifying scent
        if ((lowerText.contains("gratis") || lowerText.contains("próbk")) && parsedItems.none { it.isGratis }) {
            toConfirm.add("Klient pyta o gratis / próbkę — dobrać zapach gratisowy")
        }

        // Extract explicit price if mentioned (e.g. "245 zł", "245,00 zł")
        val priceRegex = Regex("""(\d{2,4}(?:[.,]\d{1,2})?)\s*zł""", RegexOption.IGNORE_CASE)
        val explicitPrice = priceRegex.findAll(text)
            .mapNotNull { it.groupValues[1].replace(',', '.').toDoubleOrNull() }
            .firstOrNull { it > 25.0 } ?: 0.0

        val isPaid = lowerText.contains("opłacone") ||
                lowerText.contains("przelane") ||
                lowerText.contains("blik wysłany") ||
                lowerText.contains("zapłacone")

        val dto = AiParsedOrderDto(
            customerName = customerName,
            recipientName = customerName,
            phone = rawPhone,
            email = email,
            paczkomatCode = paczkomatFromText,
            carrier = carrier.name,
            orderPricePln = explicitPrice,
            shippingCostPln = 17.0,
            isPaid = isPaid,
            items = parsedItems,
            detectedChanges = detectedChanges.distinct(),
            toConfirm = toConfirm.distinct(),
            notes = ""
        )

        return enrichAndMatchOrder(
            dto = dto,
            knownFlacons = knownFlacons,
            knownCustomers = knownCustomers,
            engineLabel = "Parser lokalny Avoire (Offline)"
        )
    }

    private fun parseSingleScentCandidate(
        fragment: String,
        knownFlacons: List<FlaconEntity>
    ): AiParsedItemDto? {
        val mlMatch = Regex("""([A-Za-zÀ-ž0-9\s'&./-]+?)\s+(\d{1,3})\s*ml""", RegexOption.IGNORE_CASE).find(fragment)
            ?: return null
        val rawName = mlMatch.groupValues[1].trim()
        val cap = mlMatch.groupValues[2].toIntOrNull() ?: 5
        val canonical = matchKnownFlaconName(rawName, knownFlacons)
        return AiParsedItemDto(
            perfumeName = canonical,
            capacityMl = cap,
            quantity = 1,
            isGratis = fragment.contains("gratis", ignoreCase = true) || fragment.contains("próbk", ignoreCase = true)
        )
    }

    private fun matchKnownFlaconName(rawName: String, knownFlacons: List<FlaconEntity>): String {
        val clean = rawName.trim()
        val matched = knownFlacons.firstOrNull { flacon ->
            flacon.fullName.equals(clean, ignoreCase = true) ||
                    flacon.scentName.equals(clean, ignoreCase = true) ||
                    clean.contains(flacon.scentName, ignoreCase = true)
        }
        return matched?.fullName ?: clean
    }

    private fun enrichAndMatchOrder(
        dto: AiParsedOrderDto,
        knownFlacons: List<FlaconEntity>,
        knownCustomers: List<CustomerEntity>,
        engineLabel: String
    ): AiAnalysisResult {
        val cleanPhone = dto.phone.replace(Regex("""\D"""), "").takeLast(9)
        val matchedCustomer = knownCustomers.firstOrNull { cust ->
            val custPhone = cust.phone.replace(Regex("""\D"""), "").takeLast(9)
            (cleanPhone.length == 9 && custPhone == cleanPhone) ||
                    (dto.customerName.isNotBlank() && cust.name.equals(dto.customerName.trim(), ignoreCase = true)) ||
                    (dto.customerName.length >= 4 && cust.name.contains(dto.customerName.trim(), ignoreCase = true))
        }

        val finalCustomerName = when {
            dto.customerName.isNotBlank() -> dto.customerName.trim()
            matchedCustomer != null -> matchedCustomer.name
            else -> ""
        }

        val finalPhone = cleanPhone.ifBlank { matchedCustomer?.phone ?: "" }
        val finalEmail = dto.email.ifBlank { matchedCustomer?.email ?: "" }
        val finalPaczkomat = dto.paczkomatCode.uppercase().trim().ifBlank {
            matchedCustomer?.defaultPaczkomat ?: ""
        }
        val finalStreet = dto.street.ifBlank { matchedCustomer?.street ?: "" }
        val finalPostal = dto.postalCode.ifBlank { matchedCustomer?.postalCode ?: "" }
        val finalCity = dto.city.ifBlank { matchedCustomer?.city ?: "" }

        val carrierType = runCatching { CarrierType.valueOf(dto.carrier) }
            .getOrDefault(CarrierType.INPOST_LOCKER)

        val toConfirm = dto.toConfirm.toMutableList()
        val detectedChanges = dto.detectedChanges.toMutableList()

        if (matchedCustomer != null && dto.paczkomatCode.isBlank() && matchedCustomer.defaultPaczkomat.isNotBlank()) {
            detectedChanges.add("Uzupełniono zapisany Paczkomat klienta z bazy: ${matchedCustomer.defaultPaczkomat}")
        }

        var calculatedPrice = 0.0
        val decantItems = dto.items.map { itemDto ->
            val matchedFlacon = knownFlacons.firstOrNull { flacon ->
                flacon.fullName.equals(itemDto.perfumeName, ignoreCase = true) ||
                        flacon.scentName.equals(itemDto.perfumeName, ignoreCase = true) ||
                        itemDto.perfumeName.contains(flacon.scentName, ignoreCase = true)
            }
            val canonicalName = matchedFlacon?.fullName ?: itemDto.perfumeName.trim()
            val totalNeededMl = itemDto.capacityMl * itemDto.quantity.coerceAtLeast(1)
            val lowOrMissingFlacon = matchedFlacon == null || matchedFlacon.currentVolumeMl < totalNeededMl
            if (matchedFlacon != null && matchedFlacon.currentVolumeMl < totalNeededMl) {
                toConfirm.add("Sprawdzić stan ${matchedFlacon.fullName}: potrzebne $totalNeededMl ml, w bazie ${matchedFlacon.currentVolumeMl} ml")
            } else if (matchedFlacon == null) {
                toConfirm.add("Sprawdzić dostępność flakonu spoza bazy: $canonicalName")
            }

            if (!itemDto.isGratis) {
                val rate = matchedFlacon?.pricePerMlPln ?: 12.0
                calculatedPrice += rate * totalNeededMl
            }

            DecantItem(
                id = UUID.randomUUID().toString(),
                perfumeName = canonicalName,
                capacityMl = itemDto.capacityMl.coerceAtLeast(1),
                quantity = itemDto.quantity.coerceAtLeast(1),
                isGratis = itemDto.isGratis,
                isReady = false,
                isStockDeducted = false,
                needsAvailabilityCheck = itemDto.needsAvailabilityCheck || lowOrMissingFlacon,
                note = itemDto.note
            )
        }

        if (finalCustomerName.isBlank()) {
            toConfirm.add("Ustalić imię i nazwisko / nick klienta")
        }
        if (finalPhone.isBlank()) {
            toConfirm.add("Brak numeru telefonu do nadania przesyłki")
        }
        if (carrierType == CarrierType.INPOST_LOCKER && finalPaczkomat.isBlank()) {
            toConfirm.add("Brak kodu Paczkomatu InPost")
        }
        if (decantItems.isEmpty()) {
            toConfirm.add("Nie wykryto pozycji zapachowych — dodaj odlewki ręcznie")
        }

        val finalOrderPrice = if (dto.orderPricePln > 0.0) {
            dto.orderPricePln
        } else {
            ((calculatedPrice * 100.0).roundToInt() / 100.0)
        }

        val displayCustomer = finalCustomerName.ifBlank { "Nowy klient" }
        val draft = OrderEntity(
            id = UUID.randomUUID().toString(),
            customerName = displayCustomer,
            customerId = matchedCustomer?.id,
            title = generateOrderTitle(displayCustomer, decantItems),
            status = OrderStatus.NEW,
            items = decantItems,
            orderPricePln = finalOrderPrice,
            shippingCostPln = if (dto.shippingCostPln > 0) dto.shippingCostPln else 17.0,
            isPaid = dto.isPaid,
            recipientName = dto.recipientName.ifBlank { displayCustomer },
            phone = finalPhone,
            email = finalEmail,
            paczkomatCode = finalPaczkomat,
            street = finalStreet,
            postalCode = finalPostal,
            city = finalCity,
            carrier = carrierType,
            trackingNumber = "",
            deadline = dto.deadline.ifBlank { "Do ustalenia" },
            toConfirmList = toConfirm.distinct(),
            detectedChangesList = detectedChanges.distinct(),
            notes = dto.notes
        )

        return AiAnalysisResult(
            draftOrder = draft,
            matchedCustomer = matchedCustomer,
            usedEngine = engineLabel
        )
    }

    private fun CustomerEntity.NameFirstPart(): String = name.substringBefore(" ").trim()

    private fun uriToBase64Jpeg(context: Context, uri: Uri): String? {
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val original = BitmapFactory.decodeStream(input) ?: return null
                val maxDim = 1280
                val ratio = minOf(
                    maxDim.toFloat() / original.width.coerceAtLeast(1),
                    maxDim.toFloat() / original.height.coerceAtLeast(1),
                    1.0f
                )
                val scaled = if (ratio < 1.0f) {
                    Bitmap.createScaledBitmap(
                        original,
                        (original.width * ratio).roundToInt().coerceAtLeast(1),
                        (original.height * ratio).roundToInt().coerceAtLeast(1),
                        true
                    )
                } else {
                    original
                }
                val output = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 82, output)
                Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
            }
        }.getOrNull()
    }
}
