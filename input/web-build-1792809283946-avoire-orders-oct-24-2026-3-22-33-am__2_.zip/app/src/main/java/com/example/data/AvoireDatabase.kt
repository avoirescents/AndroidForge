package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class AvoireTypeConverters {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    @TypeConverter
    fun fromOrderStatus(status: OrderStatus): String = status.name

    @TypeConverter
    fun toOrderStatus(value: String): OrderStatus =
        runCatching { OrderStatus.valueOf(value) }.getOrDefault(OrderStatus.NEW)

    @TypeConverter
    fun fromCarrierType(carrier: CarrierType): String = carrier.name

    @TypeConverter
    fun toCarrierType(value: String): CarrierType =
        runCatching { CarrierType.valueOf(value) }.getOrDefault(CarrierType.INPOST_LOCKER)

    @TypeConverter
    fun fromFlaconStatus(status: FlaconStatus): String = status.name

    @TypeConverter
    fun toFlaconStatus(value: String): FlaconStatus =
        runCatching { FlaconStatus.valueOf(value) }.getOrDefault(FlaconStatus.IN_STOCK)

    @TypeConverter
    fun fromDecantItemList(items: List<DecantItem>): String = json.encodeToString(items)

    @TypeConverter
    fun toDecantItemList(value: String): List<DecantItem> =
        if (value.isBlank()) emptyList()
        else runCatching { json.decodeFromString<List<DecantItem>>(value) }.getOrDefault(emptyList())

    @TypeConverter
    fun fromStringList(list: List<String>): String = json.encodeToString(list)

    @TypeConverter
    fun toStringList(value: String): List<String> =
        if (value.isBlank()) emptyList()
        else runCatching { json.decodeFromString<List<String>>(value) }.getOrDefault(emptyList())
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun observeAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    suspend fun getAllOrdersOnce(): List<OrderEntity>

    @Query("SELECT * FROM orders WHERE id = :id LIMIT 1")
    suspend fun getOrderById(id: String): OrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOrder(order: OrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOrders(orders: List<OrderEntity>)

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Query("DELETE FROM orders WHERE id = :id")
    suspend fun deleteOrderById(id: String)

    @Query("DELETE FROM orders")
    suspend fun deleteAllOrders()
}

@Dao
interface FlaconDao {
    @Query("SELECT * FROM flacons ORDER BY brand ASC, scentName ASC")
    fun observeAllFlacons(): Flow<List<FlaconEntity>>

    @Query("SELECT * FROM flacons ORDER BY brand ASC, scentName ASC")
    suspend fun getAllFlaconsOnce(): List<FlaconEntity>

    @Query("SELECT * FROM flacons WHERE id = :id LIMIT 1")
    suspend fun getFlaconById(id: String): FlaconEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFlacon(flacon: FlaconEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFlacons(flacons: List<FlaconEntity>)

    @Query("DELETE FROM flacons WHERE id = :id")
    suspend fun deleteFlaconById(id: String)

    @Query("DELETE FROM flacons")
    suspend fun deleteAllFlacons()
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun observeAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers ORDER BY name ASC")
    suspend fun getAllCustomersOnce(): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: String): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomer(customer: CustomerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomers(customers: List<CustomerEntity>)

    @Query("DELETE FROM customers WHERE id = :id")
    suspend fun deleteCustomerById(id: String)

    @Query("DELETE FROM customers")
    suspend fun deleteAllCustomers()
}

@Dao
interface WorkshopTaskDao {
    @Query("SELECT * FROM workshop_tasks ORDER BY isDone ASC, createdAt DESC")
    fun observeAllTasks(): Flow<List<WorkshopTaskEntity>>

    @Query("SELECT * FROM workshop_tasks ORDER BY isDone ASC, createdAt DESC")
    suspend fun getAllTasksOnce(): List<WorkshopTaskEntity>

    @Query("SELECT * FROM workshop_tasks WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: String): WorkshopTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTask(task: WorkshopTaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTasks(tasks: List<WorkshopTaskEntity>)

    @Query("DELETE FROM workshop_tasks WHERE id = :id")
    suspend fun deleteTaskById(id: String)

    @Query("DELETE FROM workshop_tasks")
    suspend fun deleteAllTasks()
}

@Dao
interface NotificationLogDao {
    @Query("SELECT * FROM notification_logs ORDER BY timestamp DESC")
    fun observeAllNotifications(): Flow<List<NotificationLogItem>>

    @Query("SELECT * FROM notification_logs ORDER BY timestamp DESC")
    suspend fun getAllNotificationsOnce(): List<NotificationLogItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(item: NotificationLogItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(items: List<NotificationLogItem>)

    @Query("UPDATE notification_logs SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("DELETE FROM notification_logs")
    suspend fun clearAllNotifications()
}

@Database(
    entities = [
        OrderEntity::class,
        FlaconEntity::class,
        CustomerEntity::class,
        WorkshopTaskEntity::class,
        NotificationLogItem::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(AvoireTypeConverters::class)
abstract class AvoireDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao
    abstract fun flaconDao(): FlaconDao
    abstract fun customerDao(): CustomerDao
    abstract fun workshopTaskDao(): WorkshopTaskDao
    abstract fun notificationLogDao(): NotificationLogDao

    companion object {
        @Volatile
        private var INSTANCE: AvoireDatabase? = null

        fun getInstance(context: Context): AvoireDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AvoireDatabase::class.java,
                    "avoire_orders.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
