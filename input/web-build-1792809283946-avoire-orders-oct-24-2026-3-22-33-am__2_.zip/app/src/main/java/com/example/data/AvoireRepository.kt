package com.example.data

import android.content.Context
import com.example.util.AvoireNotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

data class StockUpdateOutcome(
    val deductedMessages: List<String> = emptyList(),
    val lowStockWarnings: List<FlaconEntity> = emptyList()
)

class AvoireRepository(
    private val context: Context,
    private val database: AvoireDatabase,
    private val notificationHelper: AvoireNotificationHelper
) {
    private val orderDao = database.orderDao()
    private val flaconDao = database.flaconDao()
    private val customerDao = database.customerDao()
    private val taskDao = database.workshopTaskDao()
    private val notificationDao = database.notificationLogDao()

    private val seedMutex = Mutex()
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val ordersFlow: Flow<List<OrderEntity>> = orderDao.observeAllOrders()
    val flaconsFlow: Flow<List<FlaconEntity>> = flaconDao.observeAllFlacons()
    val customersFlow: Flow<List<CustomerEntity>> = customerDao.observeAllCustomers()
    val tasksFlow: Flow<List<WorkshopTaskEntity>> = taskDao.observeAllTasks()
    val notificationsFlow: Flow<List<NotificationLogItem>> = notificationDao.observeAllNotifications()

    private val seedMarkerFile: File
        get() = File(context.filesDir, "avoire_seeded_v2.marker")

    private val autoSnapshotFile: File
        get() = File(context.filesDir, "avoire_auto_backup.json")

    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        seedMutex.withLock {
            if (!seedMarkerFile.exists()) {
                val existingOrders = orderDao.getAllOrdersOnce()
                val existingFlacons = flaconDao.getAllFlaconsOnce()
                val existingCustomers = customerDao.getAllCustomersOnce()

                if (existingOrders.isEmpty() && existingFlacons.isEmpty() && existingCustomers.isEmpty()) {
                    customerDao.upsertCustomers(SampleData.initialCustomers)
                    flaconDao.upsertFlacons(SampleData.initialFlacons)
                    taskDao.upsertTasks(SampleData.initialTasks)
                    val sampleOrders = SampleData.buildInitialOrders()
                    orderDao.upsertOrders(sampleOrders)

                    notificationDao.insertNotification(
                        NotificationLogItem(
                            id = "notif_welcome_1",
                            title = "Gotowe do wysyłki • Piotr Kamiński",
                            message = "Duże odlewki męskie (St Narcissus & Dark) czeka na nadanie (Paczkomat KRA04A).",
                            customerMessageTemplate = "Dzień dobry Piotr! ✨ Twoja paczka w Avoire (St. Narcissus Possessed Girl 5 ml, Dark Cathedral 5 ml + gratis Vulnus 2 ml) jest już spakowana i gotowa do nadania do Paczkomatu KRA04A.",
                            orderId = "ord_2",
                            category = "STATUS_READY",
                            isRead = false,
                            timestamp = System.currentTimeMillis() - 1800_000L
                        )
                    )
                    notificationDao.insertNotification(
                        NotificationLogItem(
                            id = "notif_welcome_2",
                            title = "Wysłane • Marta Lewandowska",
                            message = "Zestaw testowy do Gdańska nadany (Nr: 567894, Paczkomat GDN23M).",
                            customerMessageTemplate = "Dzień dobry Marta! 🚚 Twoja paczka z odlewkami Avoire została nadana do Paczkomatu GDN23M. Numer śledzenia: 567894.",
                            orderId = "ord_3",
                            category = "STATUS_SHIPPED",
                            isRead = false,
                            timestamp = System.currentTimeMillis() - 3600_000L
                        )
                    )
                }
                seedMarkerFile.writeText("seeded_v2")
                saveAutoSnapshotInternal()
            }
        }
    }

    suspend fun resetToDemoData() = withContext(Dispatchers.IO) {
        orderDao.deleteAllOrders()
        flaconDao.deleteAllFlacons()
        customerDao.deleteAllCustomers()
        taskDao.deleteAllTasks()
        notificationDao.clearAllNotifications()
        if (seedMarkerFile.exists()) {
            seedMarkerFile.delete()
        }
        ensureSeeded()
    }

    suspend fun saveOrder(
        order: OrderEntity,
        autoSyncCustomer: Boolean = true
    ): StockUpdateOutcome = withContext(Dispatchers.IO) {
        val previous = orderDao.getOrderById(order.id)
        val allFlacons = flaconDao.getAllFlaconsOnce().toMutableList()
        val deductedMessages = mutableListOf<String>()
        val lowStockAlerts = mutableListOf<FlaconEntity>()

        // Synchronize stock deduction for items marked as isReady
        val updatedItems = order.items.map { item ->
            if (item.isReady && !item.isStockDeducted) {
                val matchedIdx = findMatchingFlaconIndex(item.perfumeName, allFlacons)
                if (matchedIdx >= 0) {
                    val flacon = allFlacons[matchedIdx]
                    val newVolume = (flacon.currentVolumeMl - item.totalMl).coerceAtLeast(0)
                    val updatedFlacon = flacon.copy(currentVolumeMl = newVolume)
                    allFlacons[matchedIdx] = updatedFlacon
                    flaconDao.upsertFlacon(updatedFlacon)
                    deductedMessages.add("Odjęto ${item.totalMl} ml z flakonu ${flacon.fullName} (zostało $newVolume ml)")
                    if (updatedFlacon.isLowStock) {
                        lowStockAlerts.add(updatedFlacon)
                    }
                    item.copy(isStockDeducted = true)
                } else {
                    item
                }
            } else if (!item.isReady && item.isStockDeducted) {
                val matchedIdx = findMatchingFlaconIndex(item.perfumeName, allFlacons)
                if (matchedIdx >= 0) {
                    val flacon = allFlacons[matchedIdx]
                    val restoredVolume = (flacon.currentVolumeMl + item.totalMl).coerceAtMost(
                        flacon.initialVolumeMl.coerceAtLeast(flacon.currentVolumeMl + item.totalMl)
                    )
                    val updatedFlacon = flacon.copy(currentVolumeMl = restoredVolume)
                    allFlacons[matchedIdx] = updatedFlacon
                    flaconDao.upsertFlacon(updatedFlacon)
                    deductedMessages.add("Zwrócono ${item.totalMl} ml do flakonu ${flacon.fullName}")
                }
                item.copy(isStockDeducted = false)
            } else {
                item
            }
        }

        var syncedCustomerId = order.customerId
        if (autoSyncCustomer && order.customerName.isNotBlank()) {
            syncedCustomerId = syncCustomerFromOrder(order)
        }

        val finalTitle = if (order.title.isBlank()) {
            generateOrderTitle(order.customerName, updatedItems)
        } else {
            order.title
        }

        val savedOrder = order.copy(
            customerId = syncedCustomerId,
            title = finalTitle,
            items = updatedItems,
            updatedAt = System.currentTimeMillis()
        )
        orderDao.upsertOrder(savedOrder)

        // Check if status changed and trigger notification
        if (previous != null && previous.status != savedOrder.status) {
            val logItem = notificationHelper.buildOrderStatusNotification(savedOrder, savedOrder.status)
            notificationDao.insertNotification(logItem)
        }

        lowStockAlerts.distinctBy { it.id }.forEach { lowFlacon ->
            val stockNotif = notificationHelper.buildLowStockNotification(lowFlacon)
            notificationDao.insertNotification(stockNotif)
        }

        saveAutoSnapshotInternal()
        StockUpdateOutcome(
            deductedMessages = deductedMessages,
            lowStockWarnings = lowStockAlerts.distinctBy { it.id }
        )
    }

    suspend fun toggleDecantReady(
        orderId: String,
        decantId: String,
        markReady: Boolean
    ): StockUpdateOutcome = withContext(Dispatchers.IO) {
        val order = orderDao.getOrderById(orderId) ?: return@withContext StockUpdateOutcome()
        val updatedItems = order.items.map { item ->
            if (item.id == decantId) item.copy(isReady = markReady) else item
        }
        val allReady = updatedItems.isNotEmpty() && updatedItems.all { it.isReady }
        val anyReady = updatedItems.any { it.isReady }

        val updatedStatus = when {
            allReady && (order.status == OrderStatus.NEW || order.status == OrderStatus.TO_DECANT || order.status == OrderStatus.DECANTING) ->
                OrderStatus.READY_TO_SHIP
            anyReady && (order.status == OrderStatus.NEW || order.status == OrderStatus.TO_DECANT) ->
                OrderStatus.DECANTING
            else -> order.status
        }

        saveOrder(
            order = order.copy(
                items = updatedItems,
                status = updatedStatus,
                isPacked = allReady || order.isPacked
            ),
            autoSyncCustomer = false
        )
    }

    suspend fun toggleOrderPacked(orderId: String): StockUpdateOutcome = withContext(Dispatchers.IO) {
        val order = orderDao.getOrderById(orderId) ?: return@withContext StockUpdateOutcome()
        val targetPacked = !order.isEffectivelyPacked
        val updatedItems = order.items.map { it.copy(isReady = targetPacked) }
        val newStatus = if (targetPacked) {
            if (order.status == OrderStatus.SHIPPED || order.status == OrderStatus.COMPLETED) order.status
            else OrderStatus.READY_TO_SHIP
        } else {
            OrderStatus.DECANTING
        }
        saveOrder(
            order = order.copy(
                isPacked = targetPacked,
                items = updatedItems,
                status = newStatus
            ),
            autoSyncCustomer = false
        )
    }

    suspend fun updateOrderStatus(
        orderId: String,
        newStatus: OrderStatus,
        trackingNumber: String? = null,
        autoDeductRemainingMl: Boolean = true
    ): StockUpdateOutcome = withContext(Dispatchers.IO) {
        val order = orderDao.getOrderById(orderId) ?: return@withContext StockUpdateOutcome()
        val shouldMarkAllReady = autoDeductRemainingMl &&
                (newStatus == OrderStatus.READY_TO_SHIP || newStatus == OrderStatus.SHIPPED || newStatus == OrderStatus.COMPLETED)

        val updatedItems = if (shouldMarkAllReady) {
            order.items.map { it.copy(isReady = true) }
        } else {
            order.items
        }

        val updatedOrder = order.copy(
            status = newStatus,
            isPacked = shouldMarkAllReady || order.isPacked,
            items = updatedItems,
            trackingNumber = trackingNumber ?: order.trackingNumber,
            updatedAt = System.currentTimeMillis()
        )
        saveOrder(updatedOrder, autoSyncCustomer = false)
    }

    suspend fun toggleOrderPaid(orderId: String, isPaid: Boolean) = withContext(Dispatchers.IO) {
        val order = orderDao.getOrderById(orderId) ?: return@withContext
        orderDao.upsertOrder(order.copy(isPaid = isPaid, updatedAt = System.currentTimeMillis()))
        saveAutoSnapshotInternal()
    }

    /**
     * Usunięcie niezakończonego zamówienia zwraca odjęte ml z powrotem do flakonu.
     */
    suspend fun deleteOrder(orderId: String): List<String> = withContext(Dispatchers.IO) {
        val order = orderDao.getOrderById(orderId)
        val restoredMessages = mutableListOf<String>()
        if (order != null && order.status != OrderStatus.SHIPPED && order.status != OrderStatus.COMPLETED) {
            val allFlacons = flaconDao.getAllFlaconsOnce().toMutableList()
            order.items.filter { it.isStockDeducted || it.isReady }.forEach { item ->
                val matchedIdx = findMatchingFlaconIndex(item.perfumeName, allFlacons)
                if (matchedIdx >= 0) {
                    val flacon = allFlacons[matchedIdx]
                    val restored = (flacon.currentVolumeMl + item.totalMl).coerceAtMost(
                        flacon.initialVolumeMl.coerceAtLeast(flacon.currentVolumeMl + item.totalMl)
                    )
                    val updatedFlacon = flacon.copy(currentVolumeMl = restored)
                    allFlacons[matchedIdx] = updatedFlacon
                    flaconDao.upsertFlacon(updatedFlacon)
                    restoredMessages.add("Zwrócono ${item.totalMl} ml do ${flacon.fullName}")
                }
            }
        }
        orderDao.deleteOrderById(orderId)
        saveAutoSnapshotInternal()
        restoredMessages
    }

    suspend fun upsertFlacon(flacon: FlaconEntity) = withContext(Dispatchers.IO) {
        flaconDao.upsertFlacon(flacon)
        if (flacon.isLowStock) {
            val notif = notificationHelper.buildLowStockNotification(flacon)
            notificationDao.insertNotification(notif)
        }
        saveAutoSnapshotInternal()
    }

    suspend fun setFlaconVolumeMl(flaconId: String, targetVolumeMl: Int): FlaconEntity? = withContext(Dispatchers.IO) {
        val flacon = flaconDao.getFlaconById(flaconId) ?: return@withContext null
        val newCurrent = targetVolumeMl.coerceAtLeast(0)
        val newInitial = maxOf(flacon.initialVolumeMl, newCurrent)
        val updated = flacon.copy(
            currentVolumeMl = newCurrent,
            initialVolumeMl = newInitial
        )
        flaconDao.upsertFlacon(updated)
        if (updated.isLowStock && !flacon.isLowStock) {
            val notif = notificationHelper.buildLowStockNotification(updated)
            notificationDao.insertNotification(notif)
        }
        saveAutoSnapshotInternal()
        updated
    }

    suspend fun adjustFlaconVolume(flaconId: String, deltaMl: Int): FlaconEntity? = withContext(Dispatchers.IO) {
        val flacon = flaconDao.getFlaconById(flaconId) ?: return@withContext null
        val newCurrent = (flacon.currentVolumeMl + deltaMl).coerceAtLeast(0)
        val newInitial = maxOf(flacon.initialVolumeMl, newCurrent)
        val updated = flacon.copy(
            currentVolumeMl = newCurrent,
            initialVolumeMl = newInitial
        )
        flaconDao.upsertFlacon(updated)
        if (deltaMl < 0 && updated.isLowStock) {
            val notif = notificationHelper.buildLowStockNotification(updated)
            notificationDao.insertNotification(notif)
        }
        saveAutoSnapshotInternal()
        updated
    }

    suspend fun deleteFlacon(flaconId: String) = withContext(Dispatchers.IO) {
        flaconDao.deleteFlaconById(flaconId)
        saveAutoSnapshotInternal()
    }

    suspend fun upsertCustomer(customer: CustomerEntity) = withContext(Dispatchers.IO) {
        customerDao.upsertCustomer(customer)
        saveAutoSnapshotInternal()
    }

    suspend fun deleteCustomer(customerId: String) = withContext(Dispatchers.IO) {
        customerDao.deleteCustomerById(customerId)
        saveAutoSnapshotInternal()
    }

    suspend fun upsertTask(task: WorkshopTaskEntity) = withContext(Dispatchers.IO) {
        taskDao.upsertTask(task)
        saveAutoSnapshotInternal()
    }

    suspend fun toggleTaskDone(taskId: String) = withContext(Dispatchers.IO) {
        val existing = taskDao.getTaskById(taskId) ?: return@withContext
        taskDao.upsertTask(existing.copy(isDone = !existing.isDone))
        saveAutoSnapshotInternal()
    }

    suspend fun deleteTask(taskId: String) = withContext(Dispatchers.IO) {
        taskDao.deleteTaskById(taskId)
        saveAutoSnapshotInternal()
    }

    suspend fun markAllNotificationsRead() = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead()
    }

    suspend fun clearNotifications() = withContext(Dispatchers.IO) {
        notificationDao.clearAllNotifications()
    }

    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val backup = AvoireBackupData(
            exportedAt = System.currentTimeMillis(),
            version = 2,
            orders = orderDao.getAllOrdersOnce(),
            flacons = flaconDao.getAllFlaconsOnce(),
            customers = customerDao.getAllCustomersOnce(),
            tasks = taskDao.getAllTasksOnce(),
            notificationLogs = notificationDao.getAllNotificationsOnce()
        )
        json.encodeToString(backup)
    }

    suspend fun importBackupJson(rawJson: String): Result<AvoireBackupData> = withContext(Dispatchers.IO) {
        runCatching {
            val parsed = json.decodeFromString<AvoireBackupData>(rawJson)
            orderDao.deleteAllOrders()
            flaconDao.deleteAllFlacons()
            customerDao.deleteAllCustomers()
            taskDao.deleteAllTasks()
            notificationDao.clearAllNotifications()

            customerDao.upsertCustomers(parsed.customers)
            flaconDao.upsertFlacons(parsed.flacons)
            orderDao.upsertOrders(parsed.orders)
            taskDao.upsertTasks(parsed.tasks)
            notificationDao.insertNotifications(parsed.notificationLogs)

            seedMarkerFile.writeText("imported")
            saveAutoSnapshotInternal()
            parsed
        }
    }

    private suspend fun syncCustomerFromOrder(order: OrderEntity): String {
        val allCustomers = customerDao.getAllCustomersOnce()
        val cleanPhone = order.phone.replace(Regex("""\D"""), "").takeLast(9)
        val existing = allCustomers.firstOrNull { cust ->
            cust.id == order.customerId ||
                    (cleanPhone.length == 9 && cust.phone.replace(Regex("""\D"""), "").takeLast(9) == cleanPhone) ||
                    cust.name.equals(order.customerName.trim(), ignoreCase = true)
        }

        val orderedScents = order.items.map { it.perfumeName }.distinct()

        return if (existing != null) {
            val mergedScents = (existing.favoriteScents + orderedScents).distinct().take(8)
            val updatedCustomer = existing.copy(
                phone = order.phone.ifBlank { existing.phone },
                email = order.email.ifBlank { existing.email },
                defaultPaczkomat = order.paczkomatCode.ifBlank { existing.defaultPaczkomat },
                street = order.street.ifBlank { existing.street },
                postalCode = order.postalCode.ifBlank { existing.postalCode },
                city = order.city.ifBlank { existing.city },
                favoriteScents = mergedScents
            )
            customerDao.upsertCustomer(updatedCustomer)
            updatedCustomer.id
        } else {
            val newCustomer = CustomerEntity(
                id = UUID.randomUUID().toString(),
                name = order.customerName.trim(),
                handleOrSource = "Dodany z zamówienia",
                phone = order.phone,
                email = order.email,
                defaultPaczkomat = order.paczkomatCode,
                street = order.street,
                postalCode = order.postalCode,
                city = order.city,
                favoriteScents = orderedScents
            )
            customerDao.upsertCustomer(newCustomer)
            newCustomer.id
        }
    }

    private fun findMatchingFlaconIndex(perfumeName: String, flacons: List<FlaconEntity>): Int {
        val target = perfumeName.trim().lowercase()
        if (target.isEmpty()) return -1
        return flacons.indexOfFirst { flacon ->
            val full = flacon.fullName.lowercase()
            val scent = flacon.scentName.lowercase()
            full == target || scent == target || target.contains(scent) || full.contains(target)
        }
    }

    private suspend fun saveAutoSnapshotInternal() {
        runCatching {
            val backup = AvoireBackupData(
                exportedAt = System.currentTimeMillis(),
                version = 2,
                orders = orderDao.getAllOrdersOnce(),
                flacons = flaconDao.getAllFlaconsOnce(),
                customers = customerDao.getAllCustomersOnce(),
                tasks = taskDao.getAllTasksOnce(),
                notificationLogs = notificationDao.getAllNotificationsOnce()
            )
            autoSnapshotFile.writeText(json.encodeToString(backup))
        }
    }
}
