package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import java.util.Locale
import java.util.UUID

@Serializable
enum class OrderStatus(val labelPl: String, val stepNumber: Int) {
    NEW("Nowe", 1),
    TO_DECANT("Do odlania", 2),
    DECANTING("W trakcie odlewania", 3),
    READY_TO_SHIP("Gotowe do wysyłki", 4),
    SHIPPED("Wysłane", 5),
    COMPLETED("Zakończone", 6);

    fun nextStatus(): OrderStatus? {
        val all = entries
        val idx = all.indexOf(this)
        return if (idx in 0 until all.size - 1) all[idx + 1] else null
    }
}

/**
 * Simplified 4-group filter from the ADHD-friendly 'Paczki' screen:
 * 1. Do ogarnięcia (Nowe / Do odlania / z brakami do potwierdzenia)
 * 2. W trakcie (W trakcie odlewania / Gotowe do wysyłki)
 * 3. Wysłane (Wysłane / Zakończone)
 * 4. Wszystkie
 */
enum class SimpleOrderBucket(val labelPl: String) {
    TO_HANDLE("Do ogarnięcia"),
    IN_PROGRESS("W trakcie"),
    SHIPPED("Wysłane"),
    ALL("Wszystkie")
}

@Serializable
enum class CarrierType(val labelPl: String, val shortLabel: String) {
    INPOST_LOCKER("InPost Paczkomat", "Paczkomat"),
    INPOST_COURIER("InPost Kurier", "Kurier InPost"),
    DPD("DPD Kurier", "DPD"),
    ORLEN("Orlen Paczka", "Orlen Paczka")
}

@Serializable
enum class FlaconStatus(val labelPl: String) {
    IN_STOCK("Na stanie"),
    WISHLIST("Lista życzeń"),
    ORDERED("W drodze")
}

@Serializable
data class DecantItem(
    val id: String = UUID.randomUUID().toString(),
    val perfumeName: String,
    val capacityMl: Int = 5,
    val quantity: Int = 1,
    val isGratis: Boolean = false,
    val isReady: Boolean = false,
    val isStockDeducted: Boolean = false,
    val needsAvailabilityCheck: Boolean = false,
    val note: String = ""
) {
    val totalMl: Int get() = capacityMl * quantity
}

@Entity(tableName = "orders")
@Serializable
data class OrderEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val customerName: String,
    val customerId: String? = null,
    val title: String = "",
    val status: OrderStatus = OrderStatus.NEW,
    val items: List<DecantItem> = emptyList(),
    val orderPricePln: Double = 0.0,
    val shippingCostPln: Double = 17.0,
    val isPaid: Boolean = false,
    val isPacked: Boolean = false,
    val recipientName: String = "",
    val phone: String = "",
    val email: String = "",
    val paczkomatCode: String = "",
    val street: String = "",
    val postalCode: String = "",
    val city: String = "",
    val carrier: CarrierType = CarrierType.INPOST_LOCKER,
    val trackingNumber: String = "",
    val deadline: String = "",
    val toConfirmList: List<String> = emptyList(),
    val detectedChangesList: List<String> = emptyList(),
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val paidItemsCount: Int
        get() = items.filter { !it.isGratis }.sumOf { it.quantity }

    val gratisItemsCount: Int
        get() = items.filter { it.isGratis }.sumOf { it.quantity }

    val totalItemsCount: Int
        get() = items.sumOf { it.quantity }

    val totalVolumeMl: Int
        get() = items.sumOf { it.totalMl }

    val readyEntriesCount: Int
        get() = items.count { it.isReady }

    val totalEntriesCount: Int
        get() = items.size

    val totalWithShippingPln: Double
        get() = orderPricePln + shippingCostPln

    val displayTitle: String
        get() = if (title.isNotBlank()) title else generateOrderTitle(customerName, items)

    val isEffectivelyPacked: Boolean
        get() = isPacked ||
                status == OrderStatus.READY_TO_SHIP ||
                status == OrderStatus.SHIPPED ||
                status == OrderStatus.COMPLETED ||
                (items.isNotEmpty() && items.all { it.isReady })

    val isEffectivelyShipped: Boolean
        get() = status == OrderStatus.SHIPPED || status == OrderStatus.COMPLETED

    val simpleBucket: SimpleOrderBucket
        get() = when (status) {
            OrderStatus.NEW, OrderStatus.TO_DECANT -> SimpleOrderBucket.TO_HANDLE
            OrderStatus.DECANTING, OrderStatus.READY_TO_SHIP -> SimpleOrderBucket.IN_PROGRESS
            OrderStatus.SHIPPED, OrderStatus.COMPLETED -> SimpleOrderBucket.SHIPPED
        }

    val contentSummaryText: String
        get() {
            if (items.isEmpty()) return "Brak pozycji"
            val firstItem = items.first()
            val shortName = firstItem.perfumeName.take(18)
            val suffix = if (items.size > 1) "..." else ""
            return "$shortName ${firstItem.capacityMl}ml$suffix"
        }

    val hasUrgentOrMissingInfo: Boolean
        get() = toConfirmList.isNotEmpty() ||
                items.any { it.needsAvailabilityCheck } ||
                (carrier == CarrierType.INPOST_LOCKER && paczkomatCode.isBlank()) ||
                phone.isBlank()
}

@Entity(tableName = "flacons")
@Serializable
data class FlaconEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val brand: String,
    val scentName: String,
    val concentration: String = "Eau de Parfum",
    val fragranceFamily: String = "Niszowy / Drzewno-ambrowy",
    val notesDescription: String = "",
    val initialVolumeMl: Int = 100,
    val currentVolumeMl: Int = 100,
    val lowStockThresholdMl: Int = 20,
    val pricePerMlPln: Double = 9.0,
    val batchCode: String = "",
    val status: FlaconStatus = FlaconStatus.IN_STOCK,
    val notes: String = ""
) {
    val fullName: String
        get() = if (brand.isNotBlank() && !scentName.startsWith(brand, ignoreCase = true)) {
            "$brand $scentName".trim()
        } else {
            scentName.trim()
        }

    val fillPercent: Int
        get() = if (initialVolumeMl > 0) {
            ((currentVolumeMl.toFloat() / initialVolumeMl.toFloat()) * 100f).toInt().coerceIn(0, 100)
        } else 0

    val isLowStock: Boolean
        get() = status == FlaconStatus.IN_STOCK && (fillPercent <= 20 || currentVolumeMl <= lowStockThresholdMl)

    val isMediumStock: Boolean
        get() = status == FlaconStatus.IN_STOCK && fillPercent in 21..50

    val isHighStock: Boolean
        get() = status == FlaconStatus.IN_STOCK && fillPercent > 50

    val fillFraction: Float
        get() = if (initialVolumeMl > 0) {
            (currentVolumeMl.toFloat() / initialVolumeMl.toFloat()).coerceIn(0f, 1f)
        } else 0f
}

@Entity(tableName = "customers")
@Serializable
data class CustomerEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val handleOrSource: String = "",
    val phone: String = "",
    val email: String = "",
    val defaultPaczkomat: String = "",
    val street: String = "",
    val postalCode: String = "",
    val city: String = "",
    val favoriteScents: List<String> = emptyList(),
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "workshop_tasks")
@Serializable
data class WorkshopTaskEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val noteOrDeadline: String = "",
    val isDone: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notification_logs")
@Serializable
data class NotificationLogItem(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val customerMessageTemplate: String = "",
    val orderId: String? = null,
    val category: String = "STATUS_CHANGE",
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
data class AvoireBackupData(
    val exportedAt: Long = System.currentTimeMillis(),
    val version: Int = 2,
    val orders: List<OrderEntity> = emptyList(),
    val flacons: List<FlaconEntity> = emptyList(),
    val customers: List<CustomerEntity> = emptyList(),
    val tasks: List<WorkshopTaskEntity> = emptyList(),
    val notificationLogs: List<NotificationLogItem> = emptyList()
)

fun generateOrderTitle(customerName: String, items: List<DecantItem>): String {
    if (items.isEmpty()) {
        return if (customerName.isNotBlank()) "Odlewki — $customerName" else "Nowa paczka"
    }
    val names = items.take(2).joinToString(", ") {
        it.perfumeName.substringAfter(" ").ifBlank { it.perfumeName }.take(14)
    }
    val more = if (items.size > 2) " +${items.size - 2}" else ""
    return "Odlewki: $names$more"
}

fun Double.formatPln(): String {
    return String.format(Locale("pl", "PL"), "%.2f zł", this).replace('.', ',')
}

fun Double.formatPlnCompact(): String {
    return if (this % 1.0 == 0.0) {
        "${this.toInt()} zł"
    } else {
        String.format(Locale("pl", "PL"), "%.2f zł", this).replace('.', ',')
    }
}

val QUICK_CAPACITIES_ML = listOf(1, 2, 3, 5, 10, 15, 20, 30)
