package com.example.data

object SampleData {
    val initialCustomers = listOf(
        CustomerEntity(
            id = "cust_1",
            name = "Katarzyna Wiśniewska",
            handleOrSource = "Próbki nowości słodkich / Discovery Set",
            phone = "602 145 892",
            email = "kasia.wisniewska@example.com",
            defaultPaczkomat = "WAW101M",
            street = "ul. Puławska 42",
            postalCode = "02-512",
            city = "Warszawa",
            favoriteScents = listOf(
                "Ataraxia Deity",
                "Ataraxia Amaretto Jazz in The Melting Room",
                "Avoire Free Candy Inside"
            ),
            notes = "Kupuje głównie zapachy gourmand i ambrę. Prosi o szczelne atomizery z taśmą teflonową."
        ),
        CustomerEntity(
            id = "cust_2",
            name = "Piotr Kamiński",
            handleOrSource = "Ciężkie zapachy drzewne, kadzidlane i skórzane",
            phone = "504 332 119",
            email = "piotr.kaminski@example.com",
            defaultPaczkomat = "KRA04A",
            street = "ul. Karmelicka 19/4",
            postalCode = "31-128",
            city = "Kraków",
            favoriteScents = listOf(
                "St. Narcissus Possessed Girl in the Attic",
                "Filippo Sorcinelli Vulnus",
                "St. Narcissus Dark Cathedral"
            ),
            notes = "Zawsze bierze większe odlewki 5–10 ml w ciemnym szkle."
        ),
        CustomerEntity(
            id = "cust_3",
            name = "Marta Lewandowska",
            handleOrSource = "Zestawy testowe / Niszowe premiery Avoire",
            phone = "792 114 890",
            email = "marta.lewandowska@example.com",
            defaultPaczkomat = "GDN23M",
            street = "ul. Długa 14/7",
            postalCode = "80-827",
            city = "Gdańsk",
            favoriteScents = listOf(
                "Ataraxia My Doll's Makeup",
                "Les Liquides Imaginaires Beaute Du Diable",
                "Olympic Orchids Nightflyer"
            ),
            notes = "Szybka płatność BLIK, prosi o podpisane etykiety z logo Avoire."
        )
    )

    val initialFlacons = listOf(
        FlaconEntity(
            id = "flac_1",
            brand = "Ataraxia",
            scentName = "Deity",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Ambrowo-gourmand",
            notesDescription = "Biała czekolada, kardamon, drzewo sandałowe, wanilia madagaskarska, piżmo",
            initialVolumeMl = 100,
            currentVolumeMl = 100,
            lowStockThresholdMl = 20,
            pricePerMlPln = 8.50,
            batchCode = "ATX-01 • Półka A1",
            status = FlaconStatus.IN_STOCK,
            notes = "Bestseller jesienny Avoire."
        ),
        FlaconEntity(
            id = "flac_2",
            brand = "Ataraxia",
            scentName = "Amaretto Jazz in The Melting Room",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Likierowo-tytoniowy",
            notesDescription = "Likier amaretto, prażone migdały, dym cygarowy, fasolka tonka, benzoes",
            initialVolumeMl = 100,
            currentVolumeMl = 43,
            lowStockThresholdMl = 20,
            pricePerMlPln = 9.00,
            batchCode = "ATX-02 • Półka A1",
            status = FlaconStatus.IN_STOCK,
            notes = "Średni stan — bardzo częste zamówienia po 5 i 10 ml."
        ),
        FlaconEntity(
            id = "flac_3",
            brand = "Avoire",
            scentName = "Free Candy Inside",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Słodki / Gourmand",
            notesDescription = "Wata cukrowa, karmel, malina, różowy pieprz, ambroksan, wanilia",
            initialVolumeMl = 100,
            currentVolumeMl = 100,
            lowStockThresholdMl = 20,
            pricePerMlPln = 8.00,
            batchCode = "AVR-01 • Półka A2",
            status = FlaconStatus.IN_STOCK,
            notes = "Kompozycja autorska Avoire."
        ),
        FlaconEntity(
            id = "flac_4",
            brand = "Filippo Sorcinelli",
            scentName = "Vulnus",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Kadzidlano-drzewny",
            notesDescription = "Kadzidło kościelne, mirra, cedr, drzewo sandałowe, szara ambra",
            initialVolumeMl = 100,
            currentVolumeMl = 100,
            lowStockThresholdMl = 20,
            pricePerMlPln = 11.00,
            batchCode = "FS-09 • Półka B1",
            status = FlaconStatus.IN_STOCK,
            notes = "Ciężki, mistyczny zapach niszowy."
        ),
        FlaconEntity(
            id = "flac_5",
            brand = "Ataraxia",
            scentName = "My Doll's Makeup",
            concentration = "Eau de Parfum",
            fragranceFamily = "Pudrowo-irysowy",
            notesDescription = "Irys florencki, fiołek, puder ryżowy, szminka różana, białe piżmo",
            initialVolumeMl = 100,
            currentVolumeMl = 100,
            lowStockThresholdMl = 20,
            pricePerMlPln = 8.50,
            batchCode = "ATX-04 • Półka A2",
            status = FlaconStatus.IN_STOCK,
            notes = "Nostalgiczny pudrowy profil."
        ),
        FlaconEntity(
            id = "flac_6",
            brand = "St. Narcissus",
            scentName = "Possessed Girl in the Attic — 1 ml",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Mroczny drzewno-żywiczny",
            notesDescription = "Stare drewno cedrowe, wosk pszczeli, suszona róża, paczula, labdanum",
            initialVolumeMl = 100,
            currentVolumeMl = 100,
            lowStockThresholdMl = 20,
            pricePerMlPln = 10.00,
            batchCode = "STN-01 • Półka B2",
            status = FlaconStatus.IN_STOCK,
            notes = "Unikatowa linia St. Narcissus."
        ),
        FlaconEntity(
            id = "flac_7",
            brand = "Les Liquides Imaginaires",
            scentName = "Beaute Du Diable",
            concentration = "Eau de Parfum",
            fragranceFamily = "Korzenno-drzewny",
            notesDescription = "Gin, absynt, goździk, czerwona mandarynka, gwajakowiec, wetyweria",
            initialVolumeMl = 100,
            currentVolumeMl = 100,
            lowStockThresholdMl = 20,
            pricePerMlPln = 9.50,
            batchCode = "LLI-07 • Półka B2",
            status = FlaconStatus.IN_STOCK,
            notes = "Pełny flakon."
        ),
        FlaconEntity(
            id = "flac_8",
            brand = "Olympic Orchids",
            scentName = "Nightflyer",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Ziemisto-owocowo-mineralny",
            notesDescription = "Wilgotna jaskinia, banan, figa, nuty mineralne, drzewo sandałowe",
            initialVolumeMl = 100,
            currentVolumeMl = 100,
            lowStockThresholdMl = 20,
            pricePerMlPln = 11.50,
            batchCode = "OO-12 • Półka B3",
            status = FlaconStatus.IN_STOCK,
            notes = "Kultowa kompozycja artystyczna."
        ),
        FlaconEntity(
            id = "flac_9",
            brand = "Ataraxia",
            scentName = "Cotton Candy Glow",
            concentration = "Eau de Parfum",
            fragranceFamily = "Słodki / Waniliowy",
            notesDescription = "Cukier trzcinowy, truskawka, wanilia, kremowe piżmo",
            initialVolumeMl = 100,
            currentVolumeMl = 90,
            lowStockThresholdMl = 20,
            pricePerMlPln = 8.00,
            batchCode = "ATX-05 • Półka A3",
            status = FlaconStatus.IN_STOCK,
            notes = "Często wybierany do zestawów jesiennych."
        ),
        FlaconEntity(
            id = "flac_10",
            brand = "St. Narcissus",
            scentName = "Dark Cathedral",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Kadzidlano-skórzany",
            notesDescription = "Olibanum, czarny pieprz, skóra, popiół, wetyweria, smoła brzozowa",
            initialVolumeMl = 100,
            currentVolumeMl = 85,
            lowStockThresholdMl = 20,
            pricePerMlPln = 10.50,
            batchCode = "STN-02 • Półka B2",
            status = FlaconStatus.IN_STOCK,
            notes = ""
        ),
        FlaconEntity(
            id = "flac_11",
            brand = "Avoire",
            scentName = "Nocturnal Lavender",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Lawendowo-ambrowy",
            notesDescription = "Lawenda francuska, czarna wanilia, bób tonka, drzewo kaszmirowe",
            initialVolumeMl = 100,
            currentVolumeMl = 95,
            lowStockThresholdMl = 20,
            pricePerMlPln = 9.50,
            batchCode = "AVR-02 • Półka A1",
            status = FlaconStatus.IN_STOCK,
            notes = "Sygnaturowy zapach marki Avoire."
        ),
        FlaconEntity(
            id = "flac_12",
            brand = "Xerjoff",
            scentName = "Naxos",
            concentration = "Eau de Parfum",
            fragranceFamily = "Miodowo-tytoniowy",
            notesDescription = "Bergamotka, lawenda, miód, cynamon, liść tytoniu, wanilia",
            initialVolumeMl = 100,
            currentVolumeMl = 78,
            lowStockThresholdMl = 20,
            pricePerMlPln = 11.50,
            batchCode = "XJ-10 • Półka C1",
            status = FlaconStatus.IN_STOCK,
            notes = ""
        ),
        FlaconEntity(
            id = "flac_13",
            brand = "Louis Vuitton",
            scentName = "Imagination",
            concentration = "Eau de Parfum",
            fragranceFamily = "Cytrusowo-herbaciany",
            notesDescription = "Cytron, bergamotka, czarna herbata chińska, imbir, ambroksan",
            initialVolumeMl = 100,
            currentVolumeMl = 65,
            lowStockThresholdMl = 20,
            pricePerMlPln = 15.00,
            batchCode = "LV-01 • Półka C1",
            status = FlaconStatus.IN_STOCK,
            notes = ""
        ),
        FlaconEntity(
            id = "flac_14",
            brand = "Maison Francis Kurkdjian",
            scentName = "Baccarat Rouge 540 Extrait",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Ambrowo-migdałowy",
            notesDescription = "Gorzki migdał, szafran, jaśmin egipski, cedr, szara ambra",
            initialVolumeMl = 100,
            currentVolumeMl = 75,
            lowStockThresholdMl = 20,
            pricePerMlPln = 21.00,
            batchCode = "MFK-01 • Półka C2",
            status = FlaconStatus.IN_STOCK,
            notes = ""
        ),
        FlaconEntity(
            id = "flac_15",
            brand = "Nishane",
            scentName = "Ani",
            concentration = "Extrait de Parfum",
            fragranceFamily = "Waniliowo-korzenny",
            notesDescription = "Imbir, kardamon, bergamotka, wanilia, benzoes, sandałowiec",
            initialVolumeMl = 100,
            currentVolumeMl = 82,
            lowStockThresholdMl = 20,
            pricePerMlPln = 10.50,
            batchCode = "NSH-01 • Półka C2",
            status = FlaconStatus.IN_STOCK,
            notes = ""
        ),
        FlaconEntity(
            id = "flac_16",
            brand = "Initio",
            scentName = "Oud for Greatness",
            concentration = "Eau de Parfum",
            fragranceFamily = "Drzewno-korzenny",
            notesDescription = "Szafran, gałka muszkatołowa, lawenda, agar (oud), paczula, piżmo",
            initialVolumeMl = 100,
            currentVolumeMl = 88,
            lowStockThresholdMl = 20,
            pricePerMlPln = 14.50,
            batchCode = "INI-01 • Półka C3",
            status = FlaconStatus.IN_STOCK,
            notes = ""
        ),
        FlaconEntity(
            id = "flac_17",
            brand = "Parfums de Marly",
            scentName = "Delina Exclusif",
            concentration = "Parfum",
            fragranceFamily = "Kwiatowo-orientalny",
            notesDescription = "Liczi, gruszka, róża turecka, kadzidło, wanilia, ambra",
            initialVolumeMl = 100,
            currentVolumeMl = 70,
            lowStockThresholdMl = 20,
            pricePerMlPln = 16.00,
            batchCode = "PDM-01 • Półka C3",
            status = FlaconStatus.IN_STOCK,
            notes = ""
        )
    )

    val initialTasks = listOf(
        WorkshopTaskEntity(
            id = "task_1",
            title = "Zamówić puste atomizery szklane 2ml i 5ml ze złotym gwintem",
            noteOrDeadline = "Hurtownia szkła laboratoryjnego",
            isDone = true,
            createdAt = System.currentTimeMillis() - 3600_000L * 48
        ),
        WorkshopTaskEntity(
            id = "task_2",
            title = "Wydrukować nową partię etykiet z logo Avoire",
            noteOrDeadline = "Papier matowy odporny na olejki",
            isDone = true,
            createdAt = System.currentTimeMillis() - 3600_000L * 36
        ),
        WorkshopTaskEntity(
            id = "task_3",
            title = "Przygotować 10 zestawów próbek Discovery na grudzień",
            noteOrDeadline = "Zestawy po 5x 2 ml",
            isDone = true,
            createdAt = System.currentTimeMillis() - 3600_000L * 24
        ),
        WorkshopTaskEntity(
            id = "task_4",
            title = "Sprawdzić dostępność flakonu Amaretto Jazz (czy domawiać)",
            noteOrDeadline = "Zostało 43 ml w obecnym flakonie",
            isDone = true,
            createdAt = System.currentTimeMillis() - 3600_000L * 12
        )
    )

    fun buildInitialOrders(now: Long = System.currentTimeMillis()): List<OrderEntity> = listOf(
        OrderEntity(
            id = "ord_1",
            customerName = "Katarzyna Wiśniewska",
            customerId = "cust_1",
            title = "Odlewki jesienne: Deity, Jazz & Cotton Candy",
            status = OrderStatus.DECANTING,
            items = listOf(
                DecantItem(
                    id = "dec_1",
                    perfumeName = "Ataraxia Deity",
                    capacityMl = 2,
                    quantity = 2,
                    isGratis = false,
                    isReady = true,
                    isStockDeducted = true
                ),
                DecantItem(
                    id = "dec_2",
                    perfumeName = "Ataraxia Amaretto Jazz in The Melting Room",
                    capacityMl = 5,
                    quantity = 1,
                    isGratis = false,
                    isReady = true,
                    isStockDeducted = true
                ),
                DecantItem(
                    id = "dec_3",
                    perfumeName = "Ataraxia Cotton Candy Glow",
                    capacityMl = 2,
                    quantity = 1,
                    isGratis = false,
                    isReady = false,
                    isStockDeducted = false,
                    needsAvailabilityCheck = true
                ),
                DecantItem(
                    id = "dec_4",
                    perfumeName = "Avoire Free Candy Inside",
                    capacityMl = 1,
                    quantity = 1,
                    isGratis = true,
                    isReady = true,
                    isStockDeducted = true,
                    note = "Próbka gratis"
                )
            ),
            orderPricePln = 95.00,
            shippingCostPln = 17.00,
            isPaid = true,
            isPacked = false,
            recipientName = "Katarzyna Wiśniewska",
            phone = "602 145 892",
            email = "kasia.wisniewska@example.com",
            paczkomatCode = "WAW101M",
            street = "ul. Puławska 42",
            postalCode = "02-512",
            city = "Warszawa",
            carrier = CarrierType.INPOST_LOCKER,
            trackingNumber = "",
            deadline = "2026-10-25",
            toConfirmList = listOf("Potwierdzić czy Cotton Candy 2 ml czy 5 ml"),
            detectedChangesList = emptyList(),
            notes = "Prosi o szczelne atomizery z taśmą teflonową.",
            createdAt = now - 3600_000L * 4,
            updatedAt = now - 3600_000L * 1
        ),
        OrderEntity(
            id = "ord_2",
            customerName = "Piotr Kamiński",
            customerId = "cust_2",
            title = "Duże odlewki męskie (St Narcissus & Dark)",
            status = OrderStatus.READY_TO_SHIP,
            items = listOf(
                DecantItem(
                    id = "dec_5",
                    perfumeName = "St. Narcissus Possessed Girl in the Attic — 1 ml",
                    capacityMl = 5,
                    quantity = 1,
                    isGratis = false,
                    isReady = true,
                    isStockDeducted = true
                ),
                DecantItem(
                    id = "dec_6",
                    perfumeName = "St. Narcissus Dark Cathedral",
                    capacityMl = 5,
                    quantity = 1,
                    isGratis = false,
                    isReady = true,
                    isStockDeducted = true
                ),
                DecantItem(
                    id = "dec_7",
                    perfumeName = "Filippo Sorcinelli Vulnus",
                    capacityMl = 2,
                    quantity = 1,
                    isGratis = true,
                    isReady = true,
                    isStockDeducted = true,
                    note = "Próbka gratis"
                )
            ),
            orderPricePln = 125.00,
            shippingCostPln = 17.00,
            isPaid = true,
            isPacked = true,
            recipientName = "Piotr Kamiński",
            phone = "504 332 119",
            email = "piotr.kaminski@example.com",
            paczkomatCode = "KRA04A",
            street = "ul. Karmelicka 19/4",
            postalCode = "31-128",
            city = "Kraków",
            carrier = CarrierType.INPOST_LOCKER,
            trackingNumber = "",
            deadline = "2026-10-24",
            toConfirmList = emptyList(),
            detectedChangesList = emptyList(),
            notes = "Spakowane w pudełko Avoire, gotowe do nadania w Paczkomacie.",
            createdAt = now - 3600_000L * 12,
            updatedAt = now - 3600_000L * 2
        ),
        OrderEntity(
            id = "ord_3",
            customerName = "Marta Lewandowska",
            customerId = "cust_3",
            title = "Zestaw testowy do Gdańska",
            status = OrderStatus.SHIPPED,
            items = listOf(
                DecantItem(
                    id = "dec_8",
                    perfumeName = "Ataraxia My Doll's Makeup",
                    capacityMl = 2,
                    quantity = 1,
                    isGratis = false,
                    isReady = true,
                    isStockDeducted = true
                ),
                DecantItem(
                    id = "dec_9",
                    perfumeName = "Les Liquides Imaginaires Beaute Du Diable",
                    capacityMl = 2,
                    quantity = 1,
                    isGratis = false,
                    isReady = true,
                    isStockDeducted = true
                ),
                DecantItem(
                    id = "dec_10",
                    perfumeName = "Olympic Orchids Nightflyer",
                    capacityMl = 2,
                    quantity = 1,
                    isGratis = false,
                    isReady = true,
                    isStockDeducted = true
                )
            ),
            orderPricePln = 45.00,
            shippingCostPln = 17.00,
            isPaid = true,
            isPacked = true,
            recipientName = "Marta Lewandowska",
            phone = "792 114 890",
            email = "marta.lewandowska@example.com",
            paczkomatCode = "GDN23M",
            street = "ul. Długa 14/7",
            postalCode = "80-827",
            city = "Gdańsk",
            carrier = CarrierType.INPOST_LOCKER,
            trackingNumber = "567894",
            deadline = "2026-10-20",
            toConfirmList = emptyList(),
            detectedChangesList = emptyList(),
            notes = "Nadane w Paczkomacie.",
            createdAt = now - 3600_000L * 36,
            updatedAt = now - 3600_000L * 10
        )
    )
}
