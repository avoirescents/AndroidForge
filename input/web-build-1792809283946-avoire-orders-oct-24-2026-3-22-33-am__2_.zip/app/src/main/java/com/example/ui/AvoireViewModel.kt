package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiAnalysisResult
import com.example.ai.AvoireAiParser
import com.example.data.AvoireDatabase
import com.example.data.AvoireRepository
import com.example.data.CustomerEntity
import com.example.data.FlaconEntity
import com.example.data.FlaconStatus
import com.example.data.NotificationLogItem
import com.example.data.OrderEntity
import com.example.data.OrderStatus
import com.example.data.WorkshopTaskEntity
import com.example.util.AvoireNotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class BottomNavTab(val labelPl: String, val topPillLabelPl: String) {
    ORDERS("Paczki", "Paczki"),
    AI_ADD("Dodaj AI", "+ Dodaj"),
    FLACONS("Flakony", "Flakony"),
    CUSTOMERS("Klienci", "Klienci"),
    TASKS("Zadania", "Zadania"),
    SHIPMENTS("Wysyłki", "Wysyłki")
}

class AvoireViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AvoireDatabase.getInstance(application)
    val notificationHelper = AvoireNotificationHelper(application)
    private val repository = AvoireRepository(application, database, notificationHelper)

    val orders: StateFlow<List<OrderEntity>> = repository.ordersFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val flacons: StateFlow<List<FlaconEntity>> = repository.flaconsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val customers: StateFlow<List<CustomerEntity>> = repository.customersFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val tasks: StateFlow<List<WorkshopTaskEntity>> = repository.tasksFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notifications: StateFlow<List<NotificationLogItem>> = repository.notificationsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _selectedTab = MutableStateFlow(BottomNavTab.ORDERS)
    val selectedTab: StateFlow<BottomNavTab> = _selectedTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow<OrderStatus?>(null)
    val selectedStatusFilter: StateFlow<OrderStatus?> = _selectedStatusFilter.asStateFlow()

    private val _editingOrder = MutableStateFlow<OrderEntity?>(null)
    val editingOrder: StateFlow<OrderEntity?> = _editingOrder.asStateFlow()

    private val _aiConversationText = MutableStateFlow("")
    val aiConversationText: StateFlow<String> = _aiConversationText.asStateFlow()

    private val _aiSelectedUris = MutableStateFlow<List<Uri>>(emptyList())
    val aiSelectedUris: StateFlow<List<Uri>> = _aiSelectedUris.asStateFlow()

    private val _isAnalyzingAi = MutableStateFlow(false)
    val isAnalyzingAi: StateFlow<Boolean> = _isAnalyzingAi.asStateFlow()

    private val _aiAnalysisResult = MutableStateFlow<AiAnalysisResult?>(null)
    val aiAnalysisResult: StateFlow<AiAnalysisResult?> = _aiAnalysisResult.asStateFlow()

    private val _bannerMessage = MutableStateFlow<String?>(null)
    val bannerMessage: StateFlow<String?> = _bannerMessage.asStateFlow()

    private val _lowStockWarningBanner = MutableStateFlow<String?>(null)
    val lowStockWarningBanner: StateFlow<String?> = _lowStockWarningBanner.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
    }

    fun selectTab(tab: BottomNavTab) {
        _selectedTab.value = tab
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectStatusFilter(status: OrderStatus?) {
        _selectedStatusFilter.value = status
    }

    fun openOrderEditor(order: OrderEntity?) {
        _editingOrder.value = order
    }

    fun dismissBanner() {
        _bannerMessage.value = null
    }

    fun dismissLowStockWarning() {
        _lowStockWarningBanner.value = null
    }

    fun showFeedback(message: String) {
        _bannerMessage.value = message
    }

    // --- Order Actions ---

    fun saveOrder(order: OrderEntity, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            val outcome = repository.saveOrder(order)
            _editingOrder.value = null
            if (outcome.lowStockWarnings.isNotEmpty()) {
                val names = outcome.lowStockWarnings.joinToString(", ") { "${it.fullName} (${it.currentVolumeMl} ml)" }
                _lowStockWarningBanner.value = "Ostrzeżenie o niskim stanie: $names"
            }
            val msg = if (outcome.deductedMessages.isNotEmpty()) {
                "Zapisano zamówienie • ${outcome.deductedMessages.first()}"
            } else {
                "Zapisano paczkę: ${order.displayTitle}"
            }
            _bannerMessage.value = msg
            onSaved()
        }
    }

    fun toggleDecantReady(orderId: String, decantId: String, markReady: Boolean) {
        viewModelScope.launch {
            val outcome = repository.toggleDecantReady(orderId, decantId, markReady)
            if (outcome.lowStockWarnings.isNotEmpty()) {
                val names = outcome.lowStockWarnings.joinToString(", ") { "${it.fullName} (${it.currentVolumeMl} ml)" }
                _lowStockWarningBanner.value = "Niski stan flakonu: $names"
            }
            if (outcome.deductedMessages.isNotEmpty()) {
                _bannerMessage.value = outcome.deductedMessages.joinToString(" • ")
            }
        }
    }

    fun toggleOrderPacked(orderId: String) {
        viewModelScope.launch {
            val outcome = repository.toggleOrderPacked(orderId)
            if (outcome.lowStockWarnings.isNotEmpty()) {
                val names = outcome.lowStockWarnings.joinToString(", ") { "${it.fullName} (${it.currentVolumeMl} ml)" }
                _lowStockWarningBanner.value = "Niski stan flakonu: $names"
            }
            _bannerMessage.value = if (outcome.deductedMessages.isNotEmpty()) {
                outcome.deductedMessages.first()
            } else {
                "Zaktualizowano status spakowania paczki"
            }
        }
    }

    fun changeOrderStatus(
        orderId: String,
        newStatus: OrderStatus,
        trackingNumber: String? = null
    ) {
        viewModelScope.launch {
            val outcome = repository.updateOrderStatus(orderId, newStatus, trackingNumber)
            if (outcome.lowStockWarnings.isNotEmpty()) {
                val names = outcome.lowStockWarnings.joinToString(", ") { "${it.fullName} (${it.currentVolumeMl} ml)" }
                _lowStockWarningBanner.value = "Niski stan flakonu: $names"
            }
            _bannerMessage.value = "Zmieniono status na: ${newStatus.labelPl} (wysłano powiadomienie)"
        }
    }

    fun toggleOrderPaid(orderId: String, isPaid: Boolean) {
        viewModelScope.launch {
            repository.toggleOrderPaid(orderId, isPaid)
            _bannerMessage.value = if (isPaid) "Oznaczono jako opłacone" else "Oznaczono jako nieopłacone"
        }
    }

    fun deleteOrder(orderId: String) {
        viewModelScope.launch {
            val restored = repository.deleteOrder(orderId)
            if (_editingOrder.value?.id == orderId) {
                _editingOrder.value = null
            }
            _bannerMessage.value = if (restored.isNotEmpty()) {
                "Usunięto zamówienie • ${restored.first()}"
            } else {
                "Usunięto zamówienie"
            }
        }
    }

    // --- AI Parser Actions ---

    fun updateAiConversationText(text: String) {
        _aiConversationText.value = text
    }

    fun setAiScreenshots(uris: List<Uri>) {
        _aiSelectedUris.value = uris
    }

    fun removeAiScreenshot(uri: Uri) {
        _aiSelectedUris.value = _aiSelectedUris.value.filterNot { it == uri }
    }

    fun loadSampleConversationForAi(sampleIndex: Int) {
        val sampleText = when (sampleIndex) {
            1 -> """
                Klient: Katarzyna Wiśniewska
                Hej Avoire! Chciałabym zamówić odlewki:
                - Ataraxia Deity 5 ml
                - Ataraxia Amaretto Jazz in The Melting Room 5 ml
                - Avoire Free Candy Inside 2 ml
                Chociaż jednak zamiast Free Candy Inside 2 ml wezmę Ataraxia My Doll's Makeup 5 ml!
                Dorzucicie jakąś próbkę Filippo Sorcinelli Vulnus 2 ml gratis do powąchania?
                Tel: 602 145 892, Paczkomat WAW101M, opłacone BLIKiem 145 zł.
            """.trimIndent()

            2 -> """
                Odbiorca: Piotr Kamiński
                Cześć, poproszę:
                St. Narcissus Possessed Girl in the Attic 10 ml
                Les Liquides Imaginaires Beaute Du Diable 5 ml
                Olympic Orchids Nightflyer 2 ml gratis próbka
                Wysyłka InPost Paczkomat KRA04A
                tel. 504-332-119, mail: piotr.kaminski@example.com
            """.trimIndent()

            else -> """
                Hej! Chcę zamówić:
                - Ataraxia Amaretto Jazz in The Melting Room 5 ml
                - St. Narcissus Dark Cathedral (jeszcze nie wiem czy 5 ml czy 10 ml)
                I jakaś próbka gratis do przetestowania :)
                Wyślijcie do paczkomatu w Gdańsku, numer podam wieczorem.
            """.trimIndent()
        }
        _aiConversationText.value = sampleText
    }

    fun runAiAnalysis(preferLocalOnly: Boolean = false) {
        val text = _aiConversationText.value
        val uris = _aiSelectedUris.value
        if (text.isBlank() && uris.isEmpty()) {
            _bannerMessage.value = "Wklej tekst rozmowy lub wybierz zrzuty ekranu z galerii"
            return
        }

        viewModelScope.launch {
            _isAnalyzingAi.value = true
            try {
                val result = AvoireAiParser.analyzeConversation(
                    context = getApplication(),
                    conversationText = text,
                    imageUris = uris,
                    knownFlacons = flacons.value,
                    knownCustomers = customers.value,
                    preferLocalOnly = preferLocalOnly
                )
                _aiAnalysisResult.value = result
            } finally {
                _isAnalyzingAi.value = false
            }
        }
    }

    fun updateAiDraftOrder(updatedDraft: OrderEntity) {
        val current = _aiAnalysisResult.value ?: return
        _aiAnalysisResult.value = current.copy(draftOrder = updatedDraft)
    }

    fun clearAiDraft() {
        _aiAnalysisResult.value = null
        _aiConversationText.value = ""
        _aiSelectedUris.value = emptyList()
    }

    fun confirmAndSaveAiDraft() {
        val draft = _aiAnalysisResult.value?.draftOrder ?: return
        saveOrder(draft) {
            _aiAnalysisResult.value = null
            _aiConversationText.value = ""
            _aiSelectedUris.value = emptyList()
            _selectedTab.value = BottomNavTab.ORDERS
        }
    }

    // --- Flacon Actions ---

    fun saveFlacon(flacon: FlaconEntity) {
        viewModelScope.launch {
            repository.upsertFlacon(flacon)
            if (flacon.isLowStock) {
                _lowStockWarningBanner.value = "Uwaga: ${flacon.fullName} ma niski stan (${flacon.currentVolumeMl} ml)"
            }
            _bannerMessage.value = "Zapisano flakon: ${flacon.fullName}"
        }
    }

    fun setFlaconVolumeMl(flaconId: String, targetVolumeMl: Int) {
        viewModelScope.launch {
            val updated = repository.setFlaconVolumeMl(flaconId, targetVolumeMl)
            if (updated != null && updated.isLowStock) {
                _lowStockWarningBanner.value = "Niski stan flakonu ${updated.fullName}: pozostało tylko ${updated.currentVolumeMl} ml!"
            }
        }
    }

    fun adjustFlaconMl(flaconId: String, deltaMl: Int) {
        viewModelScope.launch {
            val updated = repository.adjustFlaconVolume(flaconId, deltaMl)
            if (updated != null) {
                if (updated.isLowStock) {
                    _lowStockWarningBanner.value = "Niski stan flakonu ${updated.fullName}: pozostało tylko ${updated.currentVolumeMl} ml!"
                }
                val sign = if (deltaMl > 0) "+$deltaMl" else "$deltaMl"
                _bannerMessage.value = "${updated.fullName}: $sign ml (aktualnie ${updated.currentVolumeMl} ml)"
            }
        }
    }

    fun bulkAddFlaconsFromText(rawListText: String) {
        val lines = rawListText.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) return
        viewModelScope.launch {
            var addedCount = 0
            lines.forEach { rawLine ->
                val clean = rawLine.removePrefix("-").removePrefix("•").trim()
                if (clean.isNotBlank()) {
                    val mlRegex = Regex("""(\d{1,3})\s*/\s*(\d{1,3})\s*ml|(\d{1,3})\s*ml""", RegexOption.IGNORE_CASE)
                    val mlMatch = mlRegex.find(clean)
                    val currentMl = mlMatch?.groupValues?.getOrNull(1)?.toIntOrNull()
                        ?: mlMatch?.groupValues?.getOrNull(3)?.toIntOrNull()
                        ?: 100
                    val initialMl = mlMatch?.groupValues?.getOrNull(2)?.toIntOrNull()
                        ?.coerceAtLeast(currentMl)
                        ?: maxOf(100, currentMl)
                    val namePart = clean.replace(mlRegex, "").trim().trim('-', '—', ',', '•')
                    if (namePart.isNotBlank()) {
                        val words = namePart.split(" ")
                        val brand = if (words.size >= 2) words.first() else "Avoire"
                        val scent = if (words.size >= 2) words.drop(1).joinToString(" ") else namePart
                        repository.upsertFlacon(
                            FlaconEntity(
                                id = UUID.randomUUID().toString(),
                                brand = brand,
                                scentName = scent,
                                initialVolumeMl = initialMl,
                                currentVolumeMl = currentMl,
                                status = FlaconStatus.IN_STOCK
                            )
                        )
                        addedCount++
                    }
                }
            }
            if (addedCount > 0) {
                _bannerMessage.value = "Dodano $addedCount flakonów z wklejonej listy"
            }
        }
    }

    fun deleteFlacon(flaconId: String) {
        viewModelScope.launch {
            repository.deleteFlacon(flaconId)
            _bannerMessage.value = "Usunięto flakon z asortymentu"
        }
    }

    // --- Customer Actions ---

    fun saveCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.upsertCustomer(customer)
            _bannerMessage.value = "Zapisano klienta: ${customer.name}"
        }
    }

    fun deleteCustomer(customerId: String) {
        viewModelScope.launch {
            repository.deleteCustomer(customerId)
            _bannerMessage.value = "Usunięto klienta z bazy"
        }
    }

    // --- Workshop Tasks Actions ---

    fun addWorkshopTask(title: String, noteOrDeadline: String = "") {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.upsertTask(
                WorkshopTaskEntity(
                    title = title.trim(),
                    noteOrDeadline = noteOrDeadline.trim(),
                    isDone = false
                )
            )
            _bannerMessage.value = "Dodano zadanie pracowni"
        }
    }

    fun toggleWorkshopTask(taskId: String) {
        viewModelScope.launch {
            repository.toggleTaskDone(taskId)
        }
    }

    fun deleteWorkshopTask(taskId: String) {
        viewModelScope.launch {
            repository.deleteTask(taskId)
        }
    }

    // --- Notifications & Backup Actions ---

    fun markNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            repository.clearNotifications()
            _bannerMessage.value = "Wyczyszczono historię powiadomień"
        }
    }

    fun sendTestPushNotification() {
        viewModelScope.launch {
            val targetOrder = orders.value.firstOrNull() ?: return@launch
            val notif = notificationHelper.buildOrderStatusNotification(
                order = targetOrder,
                newStatus = OrderStatus.READY_TO_SHIP
            )
            database.notificationLogDao().insertNotification(notif)
            _bannerMessage.value = "Wysłano powiadomienie push: ${notif.title}"
        }
    }

    fun shareBackupJsonFile() {
        viewModelScope.launch {
            runCatching {
                val app = getApplication<Application>()
                val jsonContent = repository.exportBackupJson()
                val backupDir = File(app.cacheDir, "backups").apply { mkdirs() }
                val dateTag = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                val file = File(backupDir, "avoire_backup_$dateTag.json")
                file.writeText(jsonContent)

                val uri = FileProvider.getUriForFile(
                    app,
                    "${app.packageName}.fileprovider",
                    file
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "Kopia zapasowa Avoire Orders ($dateTag)")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = Intent.createChooser(shareIntent, "Eksportuj kopię zapasową Avoire JSON").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(chooser)
            }.onFailure { err ->
                _bannerMessage.value = "Błąd udostępniania pliku: ${err.localizedMessage}"
            }
        }
    }

    fun exportBackupToUri(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                val jsonContent = repository.exportBackupJson()
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(jsonContent.toByteArray(Charsets.UTF_8))
                }
                _bannerMessage.value = "Zapisano kopię zapasową JSON w pamięci telefonu"
            }.onFailure { err ->
                _bannerMessage.value = "Błąd zapisu JSON: ${err.localizedMessage}"
            }
        }
    }

    fun importBackupFromUri(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                val rawJson = getApplication<Application>().contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)
                    ?.use { it.readText() }
                    ?: error("Nie udało się odczytać pliku")

                val imported = repository.importBackupJson(rawJson).getOrThrow()
                _bannerMessage.value = "Zaimportowano bazę: ${imported.orders.size} paczek, ${imported.flacons.size} flakonów, ${imported.customers.size} klientów"
            }.onFailure { err ->
                _bannerMessage.value = "Błąd importu JSON: ${err.localizedMessage}"
            }
        }
    }

    fun importBackupFromRawJson(rawJson: String) {
        viewModelScope.launch {
            repository.importBackupJson(rawJson)
                .onSuccess { imported ->
                    _bannerMessage.value = "Zaimportowano: ${imported.orders.size} paczek, ${imported.flacons.size} flakonów, ${imported.customers.size} klientów"
                }
                .onFailure { err ->
                    _bannerMessage.value = "Nieprawidłowy format JSON: ${err.localizedMessage}"
                }
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetToDemoData()
            _bannerMessage.value = "Przywrócono startowe dane Avoire"
        }
    }
}
