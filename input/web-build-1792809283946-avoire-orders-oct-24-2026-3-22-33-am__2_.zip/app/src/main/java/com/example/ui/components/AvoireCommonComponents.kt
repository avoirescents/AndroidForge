package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NotificationLogItem
import com.example.data.OrderStatus
import com.example.ui.BottomNavTab
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireBorder
import com.example.ui.theme.AvoireBorderHighlight
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireElevated
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoirePrimaryButton
import com.example.ui.theme.AvoireSoftViolet
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary
import com.example.ui.theme.StatusAmberBg
import com.example.ui.theme.StatusAmberBorder
import com.example.ui.theme.StatusAmberText
import com.example.ui.theme.StatusCoralBg
import com.example.ui.theme.StatusCoralBorder
import com.example.ui.theme.StatusCoralText
import com.example.ui.theme.StatusEmeraldBg
import com.example.ui.theme.StatusEmeraldBorder
import com.example.ui.theme.StatusEmeraldText
import com.example.ui.theme.StatusLavenderBg
import com.example.ui.theme.StatusLavenderBorder
import com.example.ui.theme.StatusLavenderText
import com.example.ui.theme.StatusSkyBg
import com.example.ui.theme.StatusSkyBorder
import com.example.ui.theme.StatusSkyText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun copyToClipboard(context: Context, label: String, text: String, onCopied: (String) -> Unit) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
    onCopied("Skopiowano: $label")
}

fun sharePlainText(context: Context, subject: String, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, subject))
}

@Composable
fun AvoireTopBar(
    selectedTab: BottomNavTab = BottomNavTab.ORDERS,
    ordersCount: Int = 0,
    flaconsCount: Int = 0,
    pendingTasksCount: Int = 0,
    unreadNotificationsCount: Int = 0,
    onSelectTab: (BottomNavTab) -> Unit = {},
    onAddClick: () -> Unit = {},
    onOpenNotifications: () -> Unit = {},
    onOpenBackupDialog: () -> Unit = {}
) {
    val pillTabs = listOf(
        Triple(BottomNavTab.ORDERS, "Paczki", ordersCount),
        Triple(BottomNavTab.FLACONS, "Flakony", flaconsCount),
        Triple(BottomNavTab.CUSTOMERS, "Klienci", 0),
        Triple(BottomNavTab.TASKS, "Zadania", pendingTasksCount)
    )

    Surface(
        color = AvoireBackground,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Left: Lavender 'A' monogram square badge (matches screenshot)
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(Color(0xFFA78BFA))
                        .clickable { onSelectTab(BottomNavTab.ORDERS) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "A",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        ),
                        color = AvoireBackground
                    )
                }

                // Center: Scrollable pill container with Paczki, Flakony, Klienci, Zadania
                Surface(
                    color = AvoireCard,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, AvoireBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 4.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        pillTabs.forEach { (tab, label, count) ->
                            val isSelected = selectedTab == tab
                            val icon = when (tab) {
                                BottomNavTab.ORDERS -> Icons.Default.Inventory2
                                BottomNavTab.FLACONS -> Icons.Default.Science
                                BottomNavTab.CUSTOMERS -> Icons.Default.People
                                else -> Icons.Default.CheckBox
                            }
                            Surface(
                                color = if (isSelected) AvoireSoftViolet else Color.Transparent,
                                shape = RoundedCornerShape(13.dp),
                                border = if (isSelected) BorderStroke(1.dp, AvoireBorderHighlight) else null,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(13.dp))
                                    .clickable { onSelectTab(tab) }
                                    .testTag("top_pill_${tab.name.lowercase()}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (isSelected) AvoireLavenderAccent else AvoireTextSecondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        ),
                                        color = if (isSelected) AvoireTextPrimary else AvoireTextSecondary
                                    )
                                    if (count > 0 || tab == BottomNavTab.ORDERS || tab == BottomNavTab.FLACONS) {
                                        Text(
                                            text = count.toString(),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.SemiBold
                                            ),
                                            color = if (isSelected) AvoireLavenderAccent else AvoireTextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Device / Backup / Notifications icon button (matches the phone icon in screenshots)
                IconButton(
                    onClick = onOpenBackupDialog,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(19.dp))
                        .background(AvoireCard)
                        .border(1.dp, AvoireBorder, RoundedCornerShape(19.dp))
                        .testTag("backup_top_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (unreadNotificationsCount > 0) {
                                Badge(
                                    containerColor = AvoirePrimaryButton,
                                    contentColor = AvoireBackground
                                ) {
                                    Text(unreadNotificationsCount.toString())
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = "Kopia zapasowa i powiadomienia",
                            tint = AvoireTextPrimary,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }

                // Primary '+ Dodaj' pill button (matches screenshot)
                Button(
                    onClick = onAddClick,
                    shape = RoundedCornerShape(19.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFA78BFA),
                        contentColor = AvoireBackground
                    ),
                    contentPadding = PaddingValues(horizontal = 13.dp, vertical = 0.dp),
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("top_add_order_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Dodaj",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
            HorizontalDivider(color = AvoireBorder, thickness = 1.dp)
        }
    }
}

@Composable
fun OrderStatusBadge(
    status: OrderStatus,
    modifier: Modifier = Modifier
) {
    val (bg, textCol, borderCol) = when (status) {
        OrderStatus.NEW -> Triple(StatusLavenderBg, StatusLavenderText, StatusLavenderBorder)
        OrderStatus.TO_DECANT -> Triple(StatusAmberBg, StatusAmberText, StatusAmberBorder)
        OrderStatus.DECANTING -> Triple(StatusSkyBg, StatusSkyText, StatusSkyBorder)
        OrderStatus.READY_TO_SHIP -> Triple(StatusSkyBg, StatusSkyText, StatusSkyBorder)
        OrderStatus.SHIPPED -> Triple(StatusEmeraldBg, StatusEmeraldText, StatusEmeraldBorder)
        OrderStatus.COMPLETED -> Triple(StatusEmeraldBg, StatusEmeraldText, StatusEmeraldBorder)
    }

    val simplifiedText = when (status) {
        OrderStatus.NEW, OrderStatus.TO_DECANT -> "Do ogarnięcia"
        OrderStatus.DECANTING, OrderStatus.READY_TO_SHIP -> "W trakcie"
        OrderStatus.SHIPPED, OrderStatus.COMPLETED -> "Wysłane"
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, borderCol),
        modifier = modifier
    ) {
        Text(
            text = "● $simplifiedText",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = textCol,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun TonePill(
    text: String,
    tone: PillTone,
    modifier: Modifier = Modifier
) {
    val (bg, fg, border) = when (tone) {
        PillTone.AMBER -> Triple(StatusAmberBg, StatusAmberText, StatusAmberBorder)
        PillTone.EMERALD -> Triple(StatusEmeraldBg, StatusEmeraldText, StatusEmeraldBorder)
        PillTone.CORAL -> Triple(StatusCoralBg, StatusCoralText, StatusCoralBorder)
        PillTone.LAVENDER -> Triple(StatusLavenderBg, StatusLavenderText, StatusLavenderBorder)
        PillTone.NEUTRAL -> Triple(AvoireElevated, AvoireTextSecondary, AvoireBorder)
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(7.dp),
        border = BorderStroke(1.dp, border),
        modifier = modifier
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = fg,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}

enum class PillTone {
    AMBER, EMERALD, CORAL, LAVENDER, NEUTRAL
}

@Composable
fun LowStockBanner(
    message: String?,
    onDismiss: () -> Unit,
    onGoToFlacons: () -> Unit
) {
    AnimatedVisibility(visible = !message.isNullOrBlank()) {
        if (!message.isNullOrBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = StatusCoralBg),
                border = BorderStroke(1.dp, StatusCoralBorder),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = "Niski stan flakonu",
                        tint = StatusCoralText,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = StatusCoralText,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onGoToFlacons() }
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Zamknij alert",
                            tint = StatusCoralText,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FeedbackToastBar(
    message: String?,
    onDismiss: () -> Unit
) {
    AnimatedVisibility(visible = !message.isNullOrBlank()) {
        if (!message.isNullOrBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = StatusEmeraldBg),
                border = BorderStroke(1.dp, StatusEmeraldBorder),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Potwierdzenie",
                        tint = StatusEmeraldText,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                        color = StatusEmeraldText,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Zamknij",
                            tint = StatusEmeraldText,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsSheet(
    notifications: List<NotificationLogItem>,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onSendTestPush: () -> Unit,
    onClearAll: () -> Unit,
    onCopyFeedback: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val dateFormat = remember { SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = AvoireCard,
        contentColor = AvoireTextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Powiadomienia i komunikacja",
                        style = MaterialTheme.typography.headlineSmall,
                        color = AvoireTextPrimary
                    )
                    Text(
                        text = "Alerty zmian statusu („Gotowe do wysyłki”, „Wysłane”) i wiadomości dla klientów",
                        style = MaterialTheme.typography.bodySmall,
                        color = AvoireTextSecondary
                    )
                }
                if (notifications.isNotEmpty()) {
                    IconButton(
                        onClick = onClearAll,
                        modifier = Modifier.testTag("clear_notifications_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Wyczyść powiadomienia",
                            tint = AvoireTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (!hasPermission) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusAmberBg),
                    border = BorderStroke(1.dp, StatusAmberBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Systemowe powiadomienia Push wyłączone",
                                style = MaterialTheme.typography.titleSmall,
                                color = StatusAmberText
                            )
                            Text(
                                text = "Zezwól aplikacji Avoire Orders na wyświetlanie powiadomień na pasku stanu Androida.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusAmberText
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onRequestPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                            modifier = Modifier.testTag("grant_notifications_button")
                        ) {
                            Text("Włącz Push")
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onSendTestPush,
                    border = BorderStroke(1.dp, AvoireBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = AvoireElevated,
                        contentColor = AvoireLavenderAccent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("send_test_push_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Wyślij testowe powiadomienie „Gotowe do wysyłki”")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (notifications.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Brak powiadomień. Zmiana statusu zamówienia na „Gotowe do wysyłki” lub „Wysłane” wygeneruje powiadomienie push oraz szablon wiadomości dla klienta.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AvoireTextSecondary
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(notifications, key = { it.id }) { item ->
                        val tone = when (item.category) {
                            "STATUS_READY", "STATUS_SHIPPED" -> PillTone.EMERALD
                            "LOW_STOCK" -> PillTone.CORAL
                            else -> PillTone.LAVENDER
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = AvoireElevated),
                            border = BorderStroke(1.dp, AvoireBorder),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TonePill(
                                        text = when (item.category) {
                                            "STATUS_READY" -> "GOTOWE DO WYSYŁKI"
                                            "STATUS_SHIPPED" -> "WYSŁANE"
                                            "LOW_STOCK" -> "NISKI STAN FLAKONU"
                                            else -> "STATUS ZAMÓWIENIA"
                                        },
                                        tone = tone
                                    )
                                    Text(
                                        text = dateFormat.format(Date(item.timestamp)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AvoireTextSecondary
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = AvoireTextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = item.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AvoireTextSecondary
                                )

                                if (item.customerMessageTemplate.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Surface(
                                        color = AvoireCard,
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, AvoireBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = "Gotowa wiadomość dla klienta:",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = AvoireLavenderAccent
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = item.customerMessageTemplate,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = AvoireTextPrimary,
                                                maxLines = 4,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                OutlinedButton(
                                                    onClick = {
                                                        copyToClipboard(
                                                            context,
                                                            "Wiadomość dla klienta",
                                                            item.customerMessageTemplate,
                                                            onCopyFeedback
                                                        )
                                                    },
                                                    border = BorderStroke(1.dp, AvoireBorder),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ContentCopy,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("Kopiuj tekst")
                                                }
                                                Button(
                                                    onClick = {
                                                        sharePlainText(
                                                            context,
                                                            item.title,
                                                            item.customerMessageTemplate
                                                        )
                                                    },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = AvoirePrimaryButton
                                                    ),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Share,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("Wyślij klientowi")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BackupRestoreDialog(
    ordersCount: Int,
    flaconsCount: Int,
    customersCount: Int,
    unreadNotificationsCount: Int = 0,
    onOpenNotificationsSheet: () -> Unit = {},
    onShareJsonFile: () -> Unit,
    onSaveJsonToFile: () -> Unit,
    onImportJsonFromFile: () -> Unit,
    onImportRawJson: (String) -> Unit,
    onResetDemoData: () -> Unit,
    onDismiss: () -> Unit
) {
    var showRawJsonInput by remember { mutableStateOf(false) }
    var rawJsonText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AvoireCard,
        titleContentColor = AvoireTextPrimary,
        textContentColor = AvoireTextSecondary,
        title = {
            Column {
                Text(
                    text = "Dane telefonu i powiadomienia",
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    text = "W bazie: $ordersCount paczek • $flaconsCount flakonów • $customersCount klientów",
                    style = MaterialTheme.typography.labelMedium,
                    color = AvoireLavenderAccent
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onOpenNotificationsSheet()
                    },
                    border = BorderStroke(1.dp, AvoireBorderHighlight),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = AvoireSoftViolet,
                        contentColor = AvoireLavenderAccent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("notifications_top_button")
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (unreadNotificationsCount > 0)
                            "Powiadomienia Push i szablony ($unreadNotificationsCount)"
                        else
                            "Powiadomienia Push i szablony wiadomości"
                    )
                }

                HorizontalDivider(color = AvoireBorder)

                Text(
                    text = "Kopia zapasowa JSON na urządzeniu (eksport / import wszystkich paczek, flakonów, klientów i zadań):",
                    style = MaterialTheme.typography.bodySmall
                )

                Button(
                    onClick = {
                        onShareJsonFile()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("backup_share_json_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Udostępnij / Wyślij plik JSON")
                }

                OutlinedButton(
                    onClick = {
                        onSaveJsonToFile()
                        onDismiss()
                    },
                    border = BorderStroke(1.dp, AvoireBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = AvoireElevated,
                        contentColor = AvoireTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("backup_save_device_button")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Zapisz plik JSON w pamięci telefonu")
                }

                OutlinedButton(
                    onClick = {
                        onImportJsonFromFile()
                        onDismiss()
                    },
                    border = BorderStroke(1.dp, AvoireBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = AvoireElevated,
                        contentColor = AvoireLavenderAccent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("backup_import_file_button")
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Importuj bazę z pliku JSON")
                }

                TextButton(
                    onClick = { showRawJsonInput = !showRawJsonInput },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (showRawJsonInput) "Ukryj wklejanie tekstu JSON" else "Lub wklej zawartość JSON ręcznie",
                        color = AvoireLavenderAccent
                    )
                }

                if (showRawJsonInput) {
                    OutlinedTextField(
                        value = rawJsonText,
                        onValueChange = { rawJsonText = it },
                        label = { Text("Wklej JSON kopii zapasowej") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (rawJsonText.isNotBlank()) {
                                onImportRawJson(rawJsonText)
                                onDismiss()
                            }
                        },
                        enabled = rawJsonText.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Zaimportuj wklejony JSON")
                    }
                }

                HorizontalDivider(color = AvoireBorder)

                OutlinedButton(
                    onClick = {
                        onResetDemoData()
                        onDismiss()
                    },
                    border = BorderStroke(1.dp, StatusAmberBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = StatusAmberBg,
                        contentColor = StatusAmberText
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("backup_reset_demo_button")
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Przywróć startowe dane Avoire")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Zamknij", color = AvoireLavenderAccent)
            }
        }
    )
}
