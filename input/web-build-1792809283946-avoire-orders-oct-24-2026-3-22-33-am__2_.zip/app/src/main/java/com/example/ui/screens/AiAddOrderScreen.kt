package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.ai.AiAnalysisResult
import com.example.data.CarrierType
import com.example.data.DecantItem
import com.example.data.FlaconEntity
import com.example.data.OrderEntity
import com.example.data.formatPln
import com.example.data.generateOrderTitle
import com.example.ui.components.PillTone
import com.example.ui.components.TonePill
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireBorder
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireElevated
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoirePrimaryButton
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary
import com.example.ui.theme.StatusAmberBg
import com.example.ui.theme.StatusAmberBorder
import com.example.ui.theme.StatusAmberText
import com.example.ui.theme.StatusEmeraldBg
import com.example.ui.theme.StatusEmeraldBorder
import com.example.ui.theme.StatusEmeraldText
import com.example.ui.theme.StatusLavenderBg
import com.example.ui.theme.StatusLavenderBorder
import com.example.ui.theme.StatusLavenderText

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiAddOrderScreen(
    conversationText: String,
    selectedUris: List<Uri>,
    isAnalyzing: Boolean,
    analysisResult: AiAnalysisResult?,
    knownFlacons: List<FlaconEntity>,
    onConversationTextChange: (String) -> Unit,
    onScreenshotsSelected: (List<Uri>) -> Unit,
    onRemoveScreenshot: (Uri) -> Unit,
    onLoadSampleConversation: (Int) -> Unit,
    onRunAnalysis: (Boolean) -> Unit,
    onUpdateDraft: (OrderEntity) -> Unit,
    onConfirmAndSaveDraft: () -> Unit,
    onClearDraft: () -> Unit
) {
    val context = LocalContext.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 5)
    ) { uris ->
        if (uris.isNotEmpty()) {
            onScreenshotsSelected((selectedUris + uris).distinct())
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AvoireBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Nagłówek modułu Dodaj AI
        Card(
            colors = CardDefaults.cardColors(containerColor = AvoireCard),
            border = BorderStroke(1.dp, AvoireBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = AvoireLavenderAccent
                    )
                    Text(
                        text = "Kreator zamówień AI (Screenshoty + Rozmowy)",
                        style = MaterialTheme.typography.titleLarge,
                        color = AvoireTextPrimary
                    )
                }
                Text(
                    text = "Wybierz zrzuty ekranu z galerii lub wklej wiadomości z Instagrama, Messengera, WhatsAppa czy Vinted. System wyodrębni ostateczną listę odlewek, wykryje zmiany w rozmowie, dopasuje klienta z bazy i oznaczy brakujące dane jako „Do potwierdzenia”.",
                    style = MaterialTheme.typography.bodySmall,
                    color = AvoireTextSecondary
                )
            }
        }

        if (analysisResult == null) {
            // 1. Wybór zrzutów ekranu z galerii (Photo Picker)
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "1. Zrzuty ekranu rozmowy (Photo Picker)",
                                style = MaterialTheme.typography.titleMedium,
                                color = AvoireLavenderAccent
                            )
                            Text(
                                text = "Wybrano: ${selectedUris.size} zrzutów ekranu",
                                style = MaterialTheme.typography.labelSmall,
                                color = AvoireTextSecondary
                            )
                        }
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(46.dp)
                                .testTag("pick_screenshots_button")
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Wybierz z galerii")
                        }
                    }

                    if (selectedUris.isNotEmpty()) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            selectedUris.forEach { uri ->
                                Box(
                                    modifier = Modifier
                                        .size(86.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.dp, AvoireLavenderAccent, RoundedCornerShape(12.dp))
                                ) {
                                    AsyncImage(
                                        model = uri,
                                        contentDescription = "Zrzut ekranu rozmowy",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .size(22.dp)
                                            .clip(CircleShape)
                                            .background(AvoireBackground.copy(alpha = 0.85f))
                                            .clickable { onRemoveScreenshot(uri) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Usuń zrzut",
                                            tint = AvoireTextPrimary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. Wklejenie tekstu rozmowy + szybkie przykłady testowe
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "2. Treść wiadomości / rozmowy",
                            style = MaterialTheme.typography.titleMedium,
                            color = AvoireLavenderAccent
                        )
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val pasted = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
                                if (!pasted.isNullOrBlank()) {
                                    onConversationTextChange(
                                        if (conversationText.isBlank()) pasted else "$conversationText\n$pasted"
                                    )
                                }
                            },
                            border = BorderStroke(1.dp, AvoireBorder),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("paste_clipboard_button")
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Wklej ze schowka", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    Text(
                        text = "Szybkie przykłady rozmów do przetestowania parsera:",
                        style = MaterialTheme.typography.labelSmall,
                        color = AvoireTextSecondary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TonePill(
                            text = "Przykład 1: Zamiana zapachu + Gratis",
                            tone = PillTone.LAVENDER,
                            modifier = Modifier
                                .clickable { onLoadSampleConversation(1) }
                                .testTag("ai_sample_1")
                        )
                        TonePill(
                            text = "Przykład 2: 2× LV + Paczkomat KRA01A",
                            tone = PillTone.LAVENDER,
                            modifier = Modifier
                                .clickable { onLoadSampleConversation(2) }
                                .testTag("ai_sample_2")
                        )
                        TonePill(
                            text = "Przykład 3: Niepełne dane (do ustalenia)",
                            tone = PillTone.AMBER,
                            modifier = Modifier
                                .clickable { onLoadSampleConversation(3) }
                                .testTag("ai_sample_3")
                        )
                    }

                    OutlinedTextField(
                        value = conversationText,
                        onValueChange = onConversationTextChange,
                        placeholder = {
                            Text(
                                "Wklej wiadomości od klienta, np.:\n- Xerjoff Naxos 10 ml\n- jednak zamiast Baccarat wezmę Nishane Ani 5 ml\n- próbka gratis\nPaczkomat WAW242M, tel. 504 829 104",
                                style = MaterialTheme.typography.bodySmall
                            )
                        },
                        minLines = 6,
                        maxLines = 12,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = AvoireElevated,
                            unfocusedContainerColor = AvoireElevated,
                            focusedBorderColor = AvoirePrimaryButton,
                            unfocusedBorderColor = AvoireBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_conversation_input")
                    )

                    if (isAnalyzing) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(
                                    color = AvoirePrimaryButton,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = "Analizowanie kontekstu rozmowy i dopasowywanie bazy Avoire...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AvoireLavenderAccent
                                )
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onRunAnalysis(false) },
                                colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("analyze_gemini_button")
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Analizuj przez Gemini AI + Parser",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }

                            OutlinedButton(
                                onClick = { onRunAnalysis(true) },
                                border = BorderStroke(1.dp, AvoireBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = AvoireElevated,
                                    contentColor = AvoireLavenderAccent
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("analyze_local_button")
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Szybki parser lokalny (działa 100% offline)")
                            }
                        }
                    }
                }
            }
        } else {
            // EKRAN PODGLĄDU I WERYFIKACJI PRZED ZAPISANIEM ZAMÓWIENIA
            AiDraftVerificationSection(
                result = analysisResult,
                knownFlacons = knownFlacons,
                onUpdateDraft = onUpdateDraft,
                onConfirmAndSave = onConfirmAndSaveDraft,
                onBackToEditInput = onClearDraft
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AiDraftVerificationSection(
    result: AiAnalysisResult,
    knownFlacons: List<FlaconEntity>,
    onUpdateDraft: (OrderEntity) -> Unit,
    onConfirmAndSave: () -> Unit,
    onBackToEditInput: () -> Unit
) {
    val draft = result.draftOrder
    var newConfirmNote by remember { mutableStateOf("") }

    Card(
        colors = CardDefaults.cardColors(containerColor = AvoireCard),
        border = BorderStroke(1.dp, AvoirePrimaryButton),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_verification_card")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    TonePill(text = result.usedEngine, tone = PillTone.LAVENDER)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Podgląd i weryfikacja przed zapisaniem",
                        style = MaterialTheme.typography.headlineSmall,
                        color = AvoireTextPrimary
                    )
                }
                OutlinedButton(
                    onClick = onBackToEditInput,
                    border = BorderStroke(1.dp, AvoireBorder)
                ) {
                    Text("Wróć")
                }
            }

            if (!result.warningMessage.isNullOrBlank()) {
                Surface(
                    color = StatusAmberBg,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StatusAmberBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = result.warningMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusAmberText,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Dopasowany stały klient z bazy
            if (result.matchedCustomer != null) {
                Surface(
                    color = StatusEmeraldBg,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StatusEmeraldBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonSearch,
                            contentDescription = null,
                            tint = StatusEmeraldText
                        )
                        Column {
                            Text(
                                text = "Dopasowano stałego klienta: ${result.matchedCustomer.name}",
                                style = MaterialTheme.typography.labelLarge,
                                color = StatusEmeraldText
                            )
                            Text(
                                text = "Zapisany Paczkomat: ${result.matchedCustomer.defaultPaczkomat.ifBlank { "brak" }} • Tel: ${result.matchedCustomer.phone}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusEmeraldText
                            )
                        }
                    }
                }
            }

            // Sekcja: Wykryte zmiany w rozmowie
            if (draft.detectedChangesList.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(StatusLavenderBg)
                        .border(1.dp, StatusLavenderBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            tint = StatusLavenderText,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Wykryte zmiany w rozmowie (uwzględniono wersję końcową):",
                            style = MaterialTheme.typography.labelLarge,
                            color = StatusLavenderText
                        )
                    }
                    draft.detectedChangesList.forEach { change ->
                        Text(
                            text = "• $change",
                            style = MaterialTheme.typography.bodySmall,
                            color = AvoireTextPrimary
                        )
                    }
                }
            }

            // Sekcja: Do potwierdzenia z klientem (Bursztyn)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(StatusAmberBg)
                    .border(1.dp, StatusAmberBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = null,
                        tint = StatusAmberText,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Do potwierdzenia z klientem (${draft.toConfirmList.size}):",
                        style = MaterialTheme.typography.labelLarge,
                        color = StatusAmberText
                    )
                }
                if (draft.toConfirmList.isEmpty()) {
                    Text(
                        text = "Wszystkie dane kompletne — nic nie wymaga dodatkowego potwierdzenia.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusEmeraldText
                    )
                } else {
                    draft.toConfirmList.forEachIndexed { idx, item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "• $item",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusAmberText,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    val updated = draft.toConfirmList.toMutableList().also { it.removeAt(idx) }
                                    onUpdateDraft(draft.copy(toConfirmList = updated))
                                },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Usuń",
                                    tint = StatusAmberText,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newConfirmNote,
                        onValueChange = { newConfirmNote = it },
                        placeholder = { Text("Dodaj pytanie do klienta...", style = MaterialTheme.typography.bodySmall) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            if (newConfirmNote.isNotBlank()) {
                                onUpdateDraft(draft.copy(toConfirmList = draft.toConfirmList + newConfirmNote.trim()))
                                newConfirmNote = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton)
                    ) {
                        Text("+")
                    }
                }
            }

            // Edycja rozpoznanych pozycji zapachowych
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Rozpoznane odlewki (${draft.paidItemsCount} płatne, ${draft.gratisItemsCount} gratis):",
                    style = MaterialTheme.typography.titleMedium,
                    color = AvoireLavenderAccent
                )
                OutlinedButton(
                    onClick = {
                        val updatedItems = draft.items + DecantItem(
                            perfumeName = knownFlacons.firstOrNull()?.fullName ?: "Xerjoff Naxos",
                            capacityMl = 5,
                            quantity = 1
                        )
                        onUpdateDraft(
                            draft.copy(
                                items = updatedItems,
                                title = generateOrderTitle(draft.customerName, updatedItems)
                            )
                        )
                    },
                    border = BorderStroke(1.dp, AvoireBorder),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Dodaj odlewkę")
                }
            }

            draft.items.forEachIndexed { idx, decant ->
                DecantEditorItemCard(
                    index = idx,
                    item = decant,
                    knownFlacons = knownFlacons,
                    onUpdate = { updatedDecant ->
                        val newList = draft.items.toMutableList().also { it[idx] = updatedDecant }
                        onUpdateDraft(
                            draft.copy(
                                items = newList,
                                title = generateOrderTitle(draft.customerName, newList)
                            )
                        )
                    },
                    onRemove = {
                        val newList = draft.items.toMutableList().also { it.removeAt(idx) }
                        onUpdateDraft(
                            draft.copy(
                                items = newList,
                                title = generateOrderTitle(draft.customerName, newList)
                            )
                        )
                    }
                )
            }

            HorizontalDivider(color = AvoireBorder)

            // Edycja danych klienta, wysyłki i ceny przed zapisaniem
            Text(
                text = "Dane klienta, wysyłki i cena:",
                style = MaterialTheme.typography.titleMedium,
                color = AvoireLavenderAccent
            )

            OutlinedTextField(
                value = draft.customerName,
                onValueChange = { newName ->
                    onUpdateDraft(
                        draft.copy(
                            customerName = newName,
                            recipientName = newName,
                            title = generateOrderTitle(newName, draft.items)
                        )
                    )
                },
                label = { Text("Klient / Odbiorca") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = draft.paczkomatCode,
                    onValueChange = { onUpdateDraft(draft.copy(paczkomatCode = it.uppercase())) },
                    label = { Text("Paczkomat") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = draft.phone,
                    onValueChange = { onUpdateDraft(draft.copy(phone = it)) },
                    label = { Text("Telefon") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                var priceInput by remember(draft.orderPricePln) {
                    mutableStateOf(draft.orderPricePln.toString().replace('.', ','))
                }
                OutlinedTextField(
                    value = priceInput,
                    onValueChange = { raw ->
                        priceInput = raw
                        raw.replace(',', '.').toDoubleOrNull()?.let { validPrice ->
                            onUpdateDraft(draft.copy(orderPricePln = validPrice))
                        }
                    },
                    label = { Text("Cena zamówienia (zł)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Opłacone", style = MaterialTheme.typography.bodySmall)
                    Switch(
                        checked = draft.isPaid,
                        onCheckedChange = { onUpdateDraft(draft.copy(isPaid = it)) }
                    )
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CarrierType.entries.forEach { c ->
                    FilterChip(
                        selected = draft.carrier == c,
                        onClick = { onUpdateDraft(draft.copy(carrier = c)) },
                        label = { Text(c.labelPl) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AvoirePrimaryButton,
                            selectedLabelColor = AvoireTextPrimary
                        )
                    )
                }
            }

            Button(
                onClick = onConfirmAndSave,
                colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("confirm_save_ai_order_button")
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Zatwierdź i zapisz zamówienie (${draft.orderPricePln.formatPln()})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}
