package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CustomerEntity
import com.example.data.OrderEntity
import com.example.data.SimpleOrderBucket
import com.example.ui.components.copyToClipboard
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireBorder
import com.example.ui.theme.AvoireBorderHighlight
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireElevated
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoirePrimaryButton
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary
import com.example.ui.theme.StatusCoralBorder
import com.example.ui.theme.StatusCoralText
import com.example.ui.theme.StatusEmeraldText
import java.util.Locale

@Composable
fun CustomersScreen(
    customers: List<CustomerEntity>,
    orders: List<OrderEntity>,
    onSaveCustomer: (CustomerEntity) -> Unit,
    onDeleteCustomer: (String) -> Unit,
    onCreateOrderForCustomer: (CustomerEntity) -> Unit,
    onEditOrder: (OrderEntity) -> Unit,
    onCopyFeedback: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var editingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }

    val filteredCustomers = remember(customers, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) customers
        else customers.filter { cust ->
            cust.name.lowercase().contains(q) ||
                    cust.phone.lowercase().contains(q) ||
                    cust.email.lowercase().contains(q) ||
                    cust.defaultPaczkomat.lowercase().contains(q) ||
                    cust.city.lowercase().contains(q) ||
                    cust.handleOrSource.lowercase().contains(q) ||
                    cust.favoriteScents.any { it.lowercase().contains(q) }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AvoireBackground)
            .testTag("customers_list"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Top Row: Search Bar + "+ Nowy klient" button (Matches Screenshot 8)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "Szukaj klienta po imieniu, telefonie",
                            style = MaterialTheme.typography.bodySmall,
                            color = AvoireTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Szukaj",
                            tint = AvoireTextSecondary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Wyczyść",
                                    tint = AvoireTextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = AvoireCard,
                        unfocusedContainerColor = AvoireCard,
                        focusedBorderColor = AvoireLavenderAccent,
                        unfocusedBorderColor = AvoireBorder,
                        focusedTextColor = AvoireTextPrimary,
                        unfocusedTextColor = AvoireTextPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("customers_search_input")
                )

                OutlinedButton(
                    onClick = {
                        editingCustomer = CustomerEntity(name = "")
                    },
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, AvoireBorderHighlight),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = AvoireElevated,
                        contentColor = AvoireTextPrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("add_customer_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Nowy klient",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        }

        // 2. Customer Cards (Matches Screenshot 8)
        items(filteredCustomers, key = { it.id }) { customer ->
            val customerOrders = remember(orders, customer.id, customer.name) {
                orders.filter {
                    it.customerId == customer.id ||
                            it.customerName.equals(customer.name, ignoreCase = true)
                }
            }

            SimpleCustomerCard(
                customer = customer,
                customerOrders = customerOrders,
                onEditCustomer = { editingCustomer = customer },
                onDeleteCustomer = { onDeleteCustomer(customer.id) },
                onCreateOrder = { onCreateOrderForCustomer(customer) },
                onClickOrder = onEditOrder,
                onCopyFeedback = onCopyFeedback
            )
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    editingCustomer?.let { cust ->
        CustomerEditModalSheet(
            initialCustomer = cust,
            onSave = { updated ->
                onSaveCustomer(updated)
                editingCustomer = null
            },
            onDelete = { id ->
                onDeleteCustomer(id)
                editingCustomer = null
            },
            onDismiss = { editingCustomer = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SimpleCustomerCard(
    customer: CustomerEntity,
    customerOrders: List<OrderEntity>,
    onEditCustomer: () -> Unit,
    onDeleteCustomer: () -> Unit,
    onCreateOrder: () -> Unit,
    onClickOrder: (OrderEntity) -> Unit,
    onCopyFeedback: (String) -> Unit
) {
    val context = LocalContext.current

    Card(
        colors = CardDefaults.cardColors(containerColor = AvoireCard),
        border = BorderStroke(1.dp, AvoireBorder),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("customer_card_${customer.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // 1. Header: UPPERCASE SERIF NAME + Edit & Trash Icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = customer.name.uppercase(Locale("pl", "PL")),
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp,
                        letterSpacing = 0.5.sp
                    ),
                    color = AvoireTextPrimary,
                    modifier = Modifier.weight(1f)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEditCustomer,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edytuj klienta",
                            tint = AvoireTextSecondary,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    IconButton(
                        onClick = onDeleteCustomer,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Usuń klienta",
                            tint = AvoireTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // 2. Subtitle: Zamówień: X
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = AvoireTextSecondary)) {
                        append("Zamówień:  ")
                    }
                    withStyle(SpanStyle(color = AvoireLavenderAccent, fontWeight = FontWeight.Bold)) {
                        append(customerOrders.size.toString())
                    }
                },
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Contact Rows inside rounded dark boxes (Matches Screenshot 8)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Phone row with green "Zadzwoń" + Copy
                if (customer.phone.isNotBlank()) {
                    Surface(
                        color = Color(0xFF171422),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AvoireBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = AvoireLavenderAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = customer.phone,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AvoireTextPrimary
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Zadzwoń",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    color = StatusEmeraldText,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .clickable {
                                            runCatching {
                                                val dialIntent = Intent(
                                                    Intent.ACTION_DIAL,
                                                    Uri.parse("tel:${customer.phone.replace(" ", "")}")
                                                )
                                                context.startActivity(dialIntent)
                                            }
                                        }
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                )

                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Kopiuj telefon",
                                    tint = AvoireTextSecondary,
                                    modifier = Modifier
                                        .size(17.dp)
                                        .clickable {
                                            copyToClipboard(
                                                context,
                                                "Telefon ${customer.phone}",
                                                customer.phone,
                                                onCopyFeedback
                                            )
                                        }
                                )
                            }
                        }
                    }
                }

                // Email row
                if (customer.email.isNotBlank()) {
                    Surface(
                        color = Color(0xFF171422),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AvoireBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                copyToClipboard(
                                    context,
                                    "E-mail ${customer.email}",
                                    customer.email,
                                    onCopyFeedback
                                )
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Email,
                                    contentDescription = null,
                                    tint = AvoireLavenderAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = customer.email,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AvoireTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Kopiuj e-mail",
                                tint = AvoireTextSecondary,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }

                // Paczkomat & Address row
                val fullAddressLine = listOf(
                    customer.defaultPaczkomat,
                    customer.street,
                    customer.city
                ).filter { it.isNotBlank() }.joinToString(", ")

                if (fullAddressLine.isNotBlank()) {
                    Surface(
                        color = Color(0xFF171422),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AvoireBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                copyToClipboard(
                                    context,
                                    "Paczkomat / Adres",
                                    fullAddressLine,
                                    onCopyFeedback
                                )
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Place,
                                    contentDescription = null,
                                    tint = AvoireLavenderAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = fullAddressLine,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AvoireTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Kopiuj adres",
                                tint = AvoireTextSecondary,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }

            // 4. Preferences & Notes Box (Matches Screenshot 8)
            val preferencesText = customer.handleOrSource.ifBlank {
                customer.favoriteScents.joinToString(", ")
            }
            if (preferencesText.isNotBlank() || customer.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = Color(0xFF171422),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, AvoireBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (preferencesText.isNotBlank()) {
                            Text(
                                text = buildAnnotatedString {
                                    withStyle(SpanStyle(color = AvoireTextSecondary)) {
                                        append("Preferencje: ")
                                    }
                                    withStyle(
                                        SpanStyle(
                                            color = AvoireLavenderAccent,
                                            fontWeight = FontWeight.Medium
                                        )
                                    ) {
                                        append(preferencesText)
                                    }
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (customer.notes.isNotBlank()) {
                            Text(
                                text = "Notatka: ${customer.notes}",
                                style = MaterialTheme.typography.bodySmall,
                                color = AvoireTextSecondary
                            )
                        }
                    }
                }
            }

            // 5. HISTORIA PACZEK W AVOIRE (Matches Screenshot 8)
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "HISTORIA PACZEK W AVOIRE:",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.7.sp
                    ),
                    color = AvoireTextSecondary
                )

                Text(
                    text = "+ Nowa paczka",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = AvoireLavenderAccent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onCreateOrder() }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (customerOrders.isEmpty()) {
                Text(
                    text = "Brak zapisanych paczek dla tego klienta.",
                    style = MaterialTheme.typography.bodySmall,
                    color = AvoireTextSecondary
                )
            } else {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    customerOrders.forEach { order ->
                        val shortStatus = when (order.simpleBucket) {
                            SimpleOrderBucket.TO_HANDLE -> "Do ogarnięcia"
                            SimpleOrderBucket.IN_PROGRESS -> "W trakcie"
                            SimpleOrderBucket.SHIPPED -> "Wysłane"
                            SimpleOrderBucket.ALL -> "W trakcie"
                        }
                        Surface(
                            color = Color(0xFF171422),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, AvoireBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onClickOrder(order) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Inventory2,
                                    contentDescription = null,
                                    tint = AvoireLavenderAccent,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = order.displayTitle.take(26) + if (order.displayTitle.length > 26) "..." else "",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AvoireTextPrimary
                                )
                                Text(
                                    text = "($shortStatus)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AvoireTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CustomerEditModalSheet(
    initialCustomer: CustomerEntity,
    onSave: (CustomerEntity) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var name by remember { mutableStateOf(initialCustomer.name) }
    var handleOrSource by remember { mutableStateOf(initialCustomer.handleOrSource) }
    var phone by remember { mutableStateOf(initialCustomer.phone) }
    var email by remember { mutableStateOf(initialCustomer.email) }
    var defaultPaczkomat by remember { mutableStateOf(initialCustomer.defaultPaczkomat) }
    var street by remember { mutableStateOf(initialCustomer.street) }
    var postalCode by remember { mutableStateOf(initialCustomer.postalCode) }
    var city by remember { mutableStateOf(initialCustomer.city) }
    var favoriteScentsText by remember {
        mutableStateOf(initialCustomer.favoriteScents.joinToString(", "))
    }
    var notes by remember { mutableStateOf(initialCustomer.notes) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = AvoireCard,
        contentColor = AvoireTextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = if (initialCustomer.name.isBlank()) "Nowy klient Avoire" else "Edytuj klienta",
                style = MaterialTheme.typography.headlineSmall,
                color = AvoireTextPrimary
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Imię i nazwisko *") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customer_name_input")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Telefon") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = defaultPaczkomat,
                    onValueChange = { defaultPaczkomat = it.uppercase() },
                    label = { Text("Kod Paczkomatu") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("E-mail") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = street,
                    onValueChange = { street = it },
                    label = { Text("Ulica i numer") },
                    singleLine = true,
                    modifier = Modifier.weight(1.2f)
                )
                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("Miasto") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = handleOrSource,
                onValueChange = { handleOrSource = it },
                label = { Text("Preferencje zapachowe (np. Gourmand, Discovery Set)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = favoriteScentsText,
                onValueChange = { favoriteScentsText = it },
                label = { Text("Ulubione perfumy (oddzielone przecinkiem)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notatka o kliencie") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider(color = AvoireBorder)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (initialCustomer.name.isNotBlank()) {
                    OutlinedButton(
                        onClick = { onDelete(initialCustomer.id) },
                        border = BorderStroke(1.dp, StatusCoralBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusCoralText),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Text("Usuń")
                    }
                }

                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onSave(
                                initialCustomer.copy(
                                    name = name.trim(),
                                    handleOrSource = handleOrSource.trim(),
                                    phone = phone.trim(),
                                    email = email.trim(),
                                    defaultPaczkomat = defaultPaczkomat.trim().uppercase(),
                                    street = street.trim(),
                                    postalCode = postalCode.trim(),
                                    city = city.trim(),
                                    favoriteScents = favoriteScentsText
                                        .split(",")
                                        .map { it.trim() }
                                        .filter { it.isNotBlank() },
                                    notes = notes.trim()
                                )
                            )
                        }
                    },
                    enabled = name.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_customer_button")
                ) {
                    Text(
                        text = "Zapisz klienta",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}
