package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FlaconEntity
import com.example.data.FlaconStatus
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireBorder
import com.example.ui.theme.AvoireBorderHighlight
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireElevated
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoirePrimaryButton
import com.example.ui.theme.AvoireSoftViolet
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary
import com.example.ui.theme.StatusAmberBorder
import com.example.ui.theme.StatusAmberText
import com.example.ui.theme.StatusCoralBorder
import com.example.ui.theme.StatusCoralText
import com.example.ui.theme.StatusEmeraldBorder
import com.example.ui.theme.StatusEmeraldText
import java.util.UUID
import kotlin.math.roundToInt

private enum class FlaconViewMode {
    SLIDER_CONTENT,
    CATALOG_AND_ADD
}

private enum class TrafficLightFilter {
    ALL,
    GREEN,
    ORANGE,
    RED
}

private val CONCENTRATION_OPTIONS = listOf(
    "Extrait de Parfum",
    "Eau de Parfum",
    "Parfum",
    "Eau de Toilette",
    "Elixir"
)

private val FAMILY_OPTIONS = listOf(
    "Ambrowo-gourmand",
    "Drzewno-korzenny",
    "Kwiatowo-orientalny",
    "Cytrusowo-herbaciany",
    "Waniliowo-przyprawowy",
    "Kadzidlano-drzewny",
    "Pudrowo-irysowy"
)

@Composable
fun FlaconsScreen(
    flacons: List<FlaconEntity>,
    onSaveFlacon: (FlaconEntity) -> Unit,
    onAdjustMl: (String, Int) -> Unit,
    onSetVolumeMl: (String, Int) -> Unit = { id, target ->
        val current = flacons.firstOrNull { it.id == id }?.currentVolumeMl ?: 0
        onAdjustMl(id, target - current)
    },
    onBulkAddFlacons: (String) -> Unit = {},
    onDeleteFlacon: (String) -> Unit
) {
    var viewMode by remember { mutableStateOf(FlaconViewMode.SLIDER_CONTENT) }
    var trafficFilter by remember { mutableStateOf(TrafficLightFilter.ALL) }
    var editingFlacon by remember { mutableStateOf<FlaconEntity?>(null) }
    var showBulkPasteDialog by remember { mutableStateOf(false) }

    // Inline quick-add form states (matching Screenshot 3)
    var quickName by remember { mutableStateOf("") }
    var quickBrand by remember { mutableStateOf("") }
    var quickCurrentMl by remember { mutableStateOf("100") }
    var quickInitialMl by remember { mutableStateOf("100") }
    var quickPricePerMl by remember { mutableStateOf("") }
    var showExtendedCatalogFields by remember { mutableStateOf(false) }
    var quickNotesDescription by remember { mutableStateOf("") }

    val greenCount = remember(flacons) { flacons.count { it.fillPercent > 50 } }
    val orangeCount = remember(flacons) { flacons.count { it.fillPercent in 21..50 } }
    val redCount = remember(flacons) { flacons.count { it.fillPercent <= 20 } }

    val filteredFlacons = remember(flacons, trafficFilter) {
        flacons.filter { flacon ->
            when (trafficFilter) {
                TrafficLightFilter.ALL -> true
                TrafficLightFilter.GREEN -> flacon.fillPercent > 50
                TrafficLightFilter.ORANGE -> flacon.fillPercent in 21..50
                TrafficLightFilter.RED -> flacon.fillPercent <= 20
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AvoireBackground)
            .testTag("flacons_list"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Top Segmented Mode Switcher: Stan zawartości (suwak ml) | Asortyment i dodawanie (17)
        item {
            Surface(
                color = AvoireCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, AvoireBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val isSliderMode = viewMode == FlaconViewMode.SLIDER_CONTENT
                    Surface(
                        color = if (isSliderMode) AvoireSoftViolet else Color.Transparent,
                        shape = RoundedCornerShape(12.dp),
                        border = if (isSliderMode) BorderStroke(1.dp, AvoireBorderHighlight) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewMode = FlaconViewMode.SLIDER_CONTENT }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = if (isSliderMode) AvoireLavenderAccent else AvoireTextSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Stan zawartości (suwak ml)",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isSliderMode) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (isSliderMode) AvoireTextPrimary else AvoireTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    val isAddMode = viewMode == FlaconViewMode.CATALOG_AND_ADD
                    Surface(
                        color = if (isAddMode) AvoireSoftViolet else Color.Transparent,
                        shape = RoundedCornerShape(12.dp),
                        border = if (isAddMode) BorderStroke(1.dp, AvoireBorderHighlight) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewMode = FlaconViewMode.CATALOG_AND_ADD }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = if (isAddMode) AvoireLavenderAccent else AvoireTextSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Asortyment i dodawanie (${flacons.size})",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isAddMode) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (isAddMode) AvoireTextPrimary else AvoireTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // 2. Traffic-Light Card: ŚLEDZENIE ZAWARTOŚCI FLAKONÓW (CZERWONY – POMARAŃCZOWY – ZIELONY)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ŚLEDZENIE ZAWARTOŚCI FLAKONÓW (CZERWONY – POMARAŃCZOWY – ZIELONY)",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp
                        ),
                        color = AvoireTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Usunięcie niezakończonego zamówienia zwraca ml do flakonu",
                        style = MaterialTheme.typography.bodySmall,
                        color = AvoireTextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2x2 Grid of Traffic-Light Filter Pills (Matches Screenshot 3)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TrafficLightPill(
                                label = "Wszystkie",
                                count = flacons.size,
                                dotColor = null,
                                activeBorderColor = AvoireLavenderAccent,
                                isSelected = trafficFilter == TrafficLightFilter.ALL,
                                onClick = { trafficFilter = TrafficLightFilter.ALL },
                                modifier = Modifier.weight(1f)
                            )
                            TrafficLightPill(
                                label = "Zielony (>50%)",
                                count = greenCount,
                                dotColor = StatusEmeraldText,
                                activeBorderColor = StatusEmeraldBorder,
                                isSelected = trafficFilter == TrafficLightFilter.GREEN,
                                onClick = { trafficFilter = TrafficLightFilter.GREEN },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TrafficLightPill(
                                label = "Pomarańczowy",
                                count = orangeCount,
                                dotColor = StatusAmberText,
                                activeBorderColor = StatusAmberBorder,
                                isSelected = trafficFilter == TrafficLightFilter.ORANGE,
                                onClick = { trafficFilter = TrafficLightFilter.ORANGE },
                                modifier = Modifier.weight(1f)
                            )
                            TrafficLightPill(
                                label = "Czerwony (≤20%)",
                                count = redCount,
                                dotColor = StatusCoralText,
                                activeBorderColor = StatusCoralBorder,
                                isSelected = trafficFilter == TrafficLightFilter.RED,
                                onClick = { trafficFilter = TrafficLightFilter.RED },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // 3. Inline "+ Dodaj nowy flakon do asortymentu" Card (Matches Screenshot 3)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = AvoireLavenderAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "+ Dodaj nowy flakon do asortymentu",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = AvoireLavenderAccent
                            )
                        }

                        OutlinedButton(
                            onClick = { showBulkPasteDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, AvoireBorderHighlight),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = AvoireSoftViolet,
                                contentColor = AvoireLavenderAccent
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "Wklej listę flakonów",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = quickName,
                        onValueChange = { quickName = it },
                        placeholder = {
                            Text(
                                text = "Nazwa flakonu (np. Tom Ford Oud Wood, Avoire Deity)...",
                                style = MaterialTheme.typography.bodySmall,
                                color = AvoireTextSecondary
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF171422),
                            unfocusedContainerColor = Color(0xFF171422),
                            focusedBorderColor = AvoireLavenderAccent,
                            unfocusedBorderColor = AvoireBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("inline_flacon_name_input")
                    )

                    AnimatedVisibility(visible = showExtendedCatalogFields || viewMode == FlaconViewMode.CATALOG_AND_ADD) {
                        Column(
                            modifier = Modifier.padding(top = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = quickBrand,
                                onValueChange = { quickBrand = it },
                                placeholder = {
                                    Text(
                                        text = "Marka / Dom perfumeryjny (opcjonalnie, np. Ataraxia, Xerjoff)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AvoireTextSecondary
                                    )
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color(0xFF171422),
                                    unfocusedContainerColor = Color(0xFF171422),
                                    focusedBorderColor = AvoireLavenderAccent,
                                    unfocusedBorderColor = AvoireBorder
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = quickNotesDescription,
                                onValueChange = { quickNotesDescription = it },
                                placeholder = {
                                    Text(
                                        text = "Nuty zapachowe / opis (np. wanilia, tytoń, kardamon)...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AvoireTextSecondary
                                    )
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color(0xFF171422),
                                    unfocusedContainerColor = Color(0xFF171422),
                                    focusedBorderColor = AvoireLavenderAccent,
                                    unfocusedBorderColor = AvoireBorder
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Stan: 100 / 100 ml box
                        Surface(
                            color = Color(0xFF171422),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, AvoireBorder),
                            modifier = Modifier.weight(1.25f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Stan:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AvoireTextSecondary
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    androidx.compose.foundation.text.BasicTextField(
                                        value = quickCurrentMl,
                                        onValueChange = { quickCurrentMl = it.filter(Char::isDigit).take(4) },
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                                            color = AvoireTextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        ),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.width(34.dp)
                                    )
                                    Text(
                                        text = "/ ",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AvoireTextSecondary
                                    )
                                    androidx.compose.foundation.text.BasicTextField(
                                        value = quickInitialMl,
                                        onValueChange = { quickInitialMl = it.filter(Char::isDigit).take(4) },
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                                            color = AvoireTextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        ),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.width(34.dp)
                                    )
                                    Text(
                                        text = "ml",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AvoireTextSecondary
                                    )
                                }
                            }
                        }

                        // Cena/ml box
                        Surface(
                            color = Color(0xFF171422),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, AvoireBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                androidx.compose.foundation.text.BasicTextField(
                                    value = quickPricePerMl,
                                    onValueChange = { quickPricePerMl = it.take(6) },
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                                        color = AvoireTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    decorationBox = { inner ->
                                        if (quickPricePerMl.isEmpty()) {
                                            Text(
                                                text = "Cena/ml",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = AvoireTextSecondary
                                            )
                                        }
                                        inner()
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "zł/ml",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AvoireTextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val raw = quickName.trim()
                                if (raw.isNotBlank()) {
                                    val parsedBrand = if (quickBrand.isNotBlank()) {
                                        quickBrand.trim()
                                    } else {
                                        val parts = raw.split(" ")
                                        if (parts.size >= 2) parts.first() else "Avoire"
                                    }
                                    val parsedScent = if (quickBrand.isNotBlank()) {
                                        raw
                                    } else {
                                        val parts = raw.split(" ")
                                        if (parts.size >= 2) parts.drop(1).joinToString(" ") else raw
                                    }
                                    val initMl = (quickInitialMl.toIntOrNull() ?: 100).coerceAtLeast(1)
                                    val currMl = (quickCurrentMl.toIntOrNull() ?: initMl).coerceIn(0, initMl)
                                    val priceMl = quickPricePerMl.replace(',', '.').toDoubleOrNull() ?: 9.0

                                    onSaveFlacon(
                                        FlaconEntity(
                                            id = UUID.randomUUID().toString(),
                                            brand = parsedBrand,
                                            scentName = parsedScent,
                                            notesDescription = quickNotesDescription.trim(),
                                            initialVolumeMl = initMl,
                                            currentVolumeMl = currMl,
                                            pricePerMlPln = priceMl,
                                            status = FlaconStatus.IN_STOCK
                                        )
                                    )
                                    quickName = ""
                                    quickBrand = ""
                                    quickNotesDescription = ""
                                } else {
                                    // Open full modal if clicked while name is empty
                                    editingFlacon = FlaconEntity(
                                        brand = "",
                                        scentName = "",
                                        initialVolumeMl = 100,
                                        currentVolumeMl = 100
                                    )
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFA78BFA),
                                contentColor = AvoireBackground
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("add_flacon_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Dodaj flakon",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                editingFlacon = FlaconEntity(
                                    brand = quickBrand,
                                    scentName = quickName,
                                    initialVolumeMl = quickInitialMl.toIntOrNull() ?: 100,
                                    currentVolumeMl = quickCurrentMl.toIntOrNull() ?: 100
                                )
                            },
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, AvoireBorder),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = AvoireElevated,
                                contentColor = AvoireLavenderAccent
                            ),
                            modifier = Modifier.height(46.dp)
                        ) {
                            Text("Pełny formularz")
                        }
                    }
                }
            }
        }

        // 4. Flacon Cards with Visual Bottle Fill + Interactive Slider + Quick Buttons
        items(filteredFlacons, key = { it.id }) { flacon ->
            FlaconBottleSliderCard(
                flacon = flacon,
                onSetVolumeMl = { newMl -> onSetVolumeMl(flacon.id, newMl) },
                onAdjustMl = { delta -> onAdjustMl(flacon.id, delta) },
                onEditFlacon = { editingFlacon = flacon },
                onDeleteFlacon = { onDeleteFlacon(flacon.id) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Modal pełnej edycji / dodawania zapachu (marka, nuty, koncentracja, rodzina)
    editingFlacon?.let { flaconToEdit ->
        FlaconEditModalSheet(
            initialFlacon = flaconToEdit,
            onSave = { updated ->
                onSaveFlacon(updated)
                editingFlacon = null
            },
            onDelete = { id ->
                onDeleteFlacon(id)
                editingFlacon = null
            },
            onDismiss = { editingFlacon = null }
        )
    }

    // Dialog wklejania listy flakonów
    if (showBulkPasteDialog) {
        BulkPasteFlaconsDialog(
            onConfirmPaste = { rawText ->
                onBulkAddFlacons(rawText)
                showBulkPasteDialog = false
            },
            onDismiss = { showBulkPasteDialog = false }
        )
    }
}

@Composable
private fun TrafficLightPill(
    label: String,
    count: Int,
    dotColor: Color?,
    activeBorderColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (isSelected) AvoireSoftViolet else Color(0xFF171422),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) activeBorderColor else AvoireBorder
        ),
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (dotColor != null) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                }
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    ),
                    color = dotColor ?: AvoireTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Surface(
                color = AvoireElevated,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = count.toString(),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = AvoireTextPrimary,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun FlaconBottleSliderCard(
    flacon: FlaconEntity,
    onSetVolumeMl: (Int) -> Unit,
    onAdjustMl: (Int) -> Unit,
    onEditFlacon: () -> Unit,
    onDeleteFlacon: () -> Unit
) {
    val pct = flacon.fillPercent
    val (accentColor, borderColor, statusLabel) = when {
        pct > 50 -> Triple(
            StatusEmeraldText,
            Color(0xFF1E5641),
            "Wysoki stan (${flacon.currentVolumeMl}/${flacon.initialVolumeMl} ml)"
        )
        pct in 21..50 -> Triple(
            StatusAmberText,
            Color(0xFF6B4C1B),
            "Średni stan (${flacon.currentVolumeMl}/${flacon.initialVolumeMl} ml)"
        )
        else -> Triple(
            StatusCoralText,
            Color(0xFF6E2232),
            "Niski stan (${flacon.currentVolumeMl}/${flacon.initialVolumeMl} ml)"
        )
    }

    var sliderValue by remember(flacon.id, flacon.currentVolumeMl) {
        mutableFloatStateOf(flacon.currentVolumeMl.toFloat())
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = AvoireCard),
        border = BorderStroke(1.2.dp, borderColor),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("flacon_card_${flacon.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Visual Perfume Bottle on left + Name & Status & Segmented Bar on right
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FlaconBottleGauge(
                    percent = pct,
                    fillFraction = flacon.fillFraction,
                    accentColor = accentColor,
                    onClick = onEditFlacon
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = flacon.fullName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            ),
                            color = AvoireTextPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onEditFlacon() }
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onEditFlacon,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edytuj flakon",
                                    tint = AvoireTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(
                                onClick = onDeleteFlacon,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Usuń flakon",
                                    tint = AvoireTextSecondary,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }

                    // Status dot + label
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(accentColor)
                        )
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = accentColor
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Segmented 10-block bar (Matches Screenshots 3-7)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        val activeBlocks = (pct / 10).coerceIn(0, 10)
                        for (i in 1..10) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(
                                        if (i <= activeBlocks) accentColor
                                        else Color(0xFF221E30)
                                    )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interactive Slider Row ("Suwak:")
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Suwak:",
                    style = MaterialTheme.typography.labelSmall,
                    color = AvoireTextSecondary,
                    modifier = Modifier.width(46.dp)
                )
                Slider(
                    value = sliderValue,
                    onValueChange = { newVal ->
                        sliderValue = newVal
                    },
                    onValueChangeFinished = {
                        onSetVolumeMl(sliderValue.roundToInt())
                    },
                    valueRange = 0f..flacon.initialVolumeMl.coerceAtLeast(100).toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = accentColor,
                        activeTrackColor = accentColor,
                        inactiveTrackColor = Color(0xFF252134)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Quick Action Buttons Row: [-5ml] [+5ml] [↺ Pełny] [Stan: 43 / 100 ml]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SmallMlActionChip(
                    text = "-5ml",
                    onClick = { onAdjustMl(-5) },
                    modifier = Modifier.testTag("deduct_5ml_${flacon.id}")
                )
                SmallMlActionChip(
                    text = "+5ml",
                    onClick = { onAdjustMl(5) }
                )
                Surface(
                    color = Color(0xFF1A1726),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, AvoireBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSetVolumeMl(flacon.initialVolumeMl) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = AvoireTextSecondary,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Pełny",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = AvoireTextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // Stan: X / 100 ml badge
                Surface(
                    color = Color(0xFF171422),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, AvoireBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onEditFlacon() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Stan:",
                            style = MaterialTheme.typography.labelSmall,
                            color = AvoireTextSecondary
                        )
                        Text(
                            text = "${flacon.currentVolumeMl}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = AvoireTextPrimary
                        )
                        Text(
                            text = "/ ${flacon.initialVolumeMl} ml",
                            style = MaterialTheme.typography.labelSmall,
                            color = AvoireTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FlaconBottleGauge(
    percent: Int,
    fillFraction: Float,
    accentColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        // Perfume atomizer cap
        Box(
            modifier = Modifier
                .width(18.dp)
                .height(7.dp)
                .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                .background(AvoireBorderHighlight)
        )
        // Bottle neck
        Box(
            modifier = Modifier
                .width(12.dp)
                .height(3.dp)
                .background(AvoireBorder)
        )
        // Bottle glass body with liquid fill and % label
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(58.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF14111D))
                .border(1.5.dp, accentColor.copy(alpha = 0.7f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Liquid fill from bottom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(fillFraction.coerceIn(0.06f, 1f))
                    .align(Alignment.BottomCenter)
                    .background(accentColor.copy(alpha = 0.28f))
            )

            // Percentage text inside bottle
            Text(
                text = "$percent%",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                ),
                color = AvoireTextPrimary
            )
        }
    }
}

@Composable
private fun SmallMlActionChip(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF1A1726),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, AvoireBorder),
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            ),
            color = AvoireTextPrimary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
        )
    }
}

@Composable
private fun BulkPasteFlaconsDialog(
    onConfirmPaste: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var rawText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AvoireCard,
        titleContentColor = AvoireTextPrimary,
        textContentColor = AvoireTextSecondary,
        title = {
            Text(
                text = "Wklej listę flakonów",
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Wpisz lub wklej listę perfum (każdy flakon w nowej linii, np. „Tom Ford Oud Wood 85/100 ml” lub „Byredo Mojave Ghost”):",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = rawText,
                    onValueChange = { rawText = it },
                    placeholder = {
                        Text(
                            "Tom Ford Oud Wood 100 ml\nAmouage Reflection Man 75/100 ml\nLe Labo Santal 33 50/100 ml",
                            style = MaterialTheme.typography.bodySmall
                        )
                    },
                    minLines = 5,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmPaste(rawText) },
                enabled = rawText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton)
            ) {
                Text("Dodaj wszystkie")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Anuluj", color = AvoireLavenderAccent)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun FlaconEditModalSheet(
    initialFlacon: FlaconEntity,
    onSave: (FlaconEntity) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var brand by remember { mutableStateOf(initialFlacon.brand) }
    var scentName by remember { mutableStateOf(initialFlacon.scentName) }
    var concentration by remember { mutableStateOf(initialFlacon.concentration) }
    var fragranceFamily by remember { mutableStateOf(initialFlacon.fragranceFamily) }
    var notesDescription by remember { mutableStateOf(initialFlacon.notesDescription) }
    var initialVolumeText by remember { mutableStateOf(initialFlacon.initialVolumeMl.toString()) }
    var currentVolumeText by remember { mutableStateOf(initialFlacon.currentVolumeMl.toString()) }
    var thresholdText by remember { mutableStateOf(initialFlacon.lowStockThresholdMl.toString()) }
    var pricePerMlText by remember { mutableStateOf(initialFlacon.pricePerMlPln.toString()) }
    var batchCode by remember { mutableStateOf(initialFlacon.batchCode) }
    var status by remember { mutableStateOf(initialFlacon.status) }
    var notes by remember { mutableStateOf(initialFlacon.notes) }
    var validationError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = AvoireCard,
        contentColor = AvoireTextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (initialFlacon.scentName.isBlank()) "Dodaj nowy zapach do bazy" else "Edytuj flakon",
                style = MaterialTheme.typography.headlineSmall,
                color = AvoireTextPrimary
            )

            if (validationError != null) {
                Text(
                    text = validationError!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = StatusCoralText
                )
            }

            OutlinedTextField(
                value = brand,
                onValueChange = {
                    brand = it
                    validationError = null
                },
                label = { Text("Marka / Dom perfumeryjny *") },
                placeholder = { Text("np. Ataraxia, Avoire, Xerjoff, Initio") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("flacon_brand_input")
            )

            OutlinedTextField(
                value = scentName,
                onValueChange = {
                    scentName = it
                    validationError = null
                },
                label = { Text("Nazwa perfum (kompozycji) *") },
                placeholder = { Text("np. Deity, Amaretto Jazz, Naxos") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("flacon_scent_input")
            )

            Text(
                text = "Koncentracja:",
                style = MaterialTheme.typography.labelMedium,
                color = AvoireLavenderAccent
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CONCENTRATION_OPTIONS.forEach { option ->
                    FilterChip(
                        selected = concentration == option,
                        onClick = { concentration = option },
                        label = { Text(option) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AvoireSoftViolet,
                            selectedLabelColor = AvoireLavenderAccent
                        )
                    )
                }
            }

            Text(
                text = "Rodzina zapachowa:",
                style = MaterialTheme.typography.labelMedium,
                color = AvoireLavenderAccent
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FAMILY_OPTIONS.forEach { family ->
                    FilterChip(
                        selected = fragranceFamily == family,
                        onClick = { fragranceFamily = family },
                        label = { Text(family) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AvoireSoftViolet,
                            selectedLabelColor = AvoireLavenderAccent
                        )
                    )
                }
            }

            OutlinedTextField(
                value = notesDescription,
                onValueChange = { notesDescription = it },
                label = { Text("Nuty zapachowe (głowy, serca, bazy)") },
                minLines = 2,
                maxLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("flacon_notes_desc_input")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = initialVolumeText,
                    onValueChange = { initialVolumeText = it.filter(Char::isDigit) },
                    label = { Text("Pojemność (ml)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = currentVolumeText,
                    onValueChange = { currentVolumeText = it.filter(Char::isDigit) },
                    label = { Text("Aktualny stan (ml)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("flacon_current_ml_input")
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = thresholdText,
                    onValueChange = { thresholdText = it.filter(Char::isDigit) },
                    label = { Text("Próg alertu (ml)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = pricePerMlText,
                    onValueChange = { pricePerMlText = it },
                    label = { Text("Cena za 1 ml (zł)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = batchCode,
                onValueChange = { batchCode = it },
                label = { Text("Kod partii (Batch Code) / Półka") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notatka własna") },
                minLines = 2,
                maxLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider(color = AvoireBorder)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (initialFlacon.scentName.isNotBlank()) {
                    OutlinedButton(
                        onClick = { onDelete(initialFlacon.id) },
                        border = BorderStroke(1.dp, StatusCoralBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusCoralText),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Text("Usuń")
                    }
                }

                Button(
                    onClick = {
                        if (brand.isBlank() && scentName.isBlank()) {
                            validationError = "Podaj nazwę perfum."
                            return@Button
                        }
                        val initVol = (initialVolumeText.toIntOrNull() ?: 100).coerceAtLeast(1)
                        val currVol = (currentVolumeText.toIntOrNull() ?: initVol).coerceAtLeast(0)
                        val threshold = (thresholdText.toIntOrNull() ?: 20).coerceAtLeast(1)
                        val pricePerMl = pricePerMlText.replace(',', '.').toDoubleOrNull() ?: 9.0

                        onSave(
                            initialFlacon.copy(
                                brand = brand.trim().ifBlank { "Avoire" },
                                scentName = scentName.trim().ifBlank { brand.trim() },
                                concentration = concentration,
                                fragranceFamily = fragranceFamily,
                                notesDescription = notesDescription.trim(),
                                initialVolumeMl = maxOf(initVol, currVol),
                                currentVolumeMl = currVol,
                                lowStockThresholdMl = threshold,
                                pricePerMlPln = pricePerMl,
                                batchCode = batchCode.trim(),
                                status = status,
                                notes = notes.trim()
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_flacon_dialog_button")
                ) {
                    Text(
                        text = "Zapisz w katalogu Flakonów",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}
