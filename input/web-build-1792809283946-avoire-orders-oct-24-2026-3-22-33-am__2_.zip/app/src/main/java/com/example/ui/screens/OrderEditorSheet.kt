package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.CarrierType
import com.example.data.CustomerEntity
import com.example.data.DecantItem
import com.example.data.FlaconEntity
import com.example.data.OrderEntity
import com.example.data.OrderStatus
import com.example.data.QUICK_CAPACITIES_ML
import com.example.data.formatPln
import com.example.data.generateOrderTitle
import com.example.ui.components.PillTone
import com.example.ui.components.TonePill
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireBorder
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireElevated
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoirePrimaryButton
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary
import com.example.ui.theme.StatusAmberBg
import com.example.ui.theme.StatusAmberBorder
import com.example.ui.theme.StatusAmberText
import com.example.ui.theme.StatusEmeraldText
import java.util.UUID
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun OrderEditorSheet(
    initialOrder: OrderEntity,
    knownCustomers: List<CustomerEntity>,
    knownFlacons: List<FlaconEntity>,
    onSave: (OrderEntity) -> Unit,
    onDelete: ((String) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var customerName by remember { mutableStateOf(initialOrder.customerName) }
    var customerId by remember { mutableStateOf(initialOrder.customerId) }
    var title by remember { mutableStateOf(initialOrder.title) }
    var status by remember { mutableStateOf(initialOrder.status) }
    var items by remember {
        mutableStateOf(
            initialOrder.items.ifEmpty {
                listOf(DecantItem(perfumeName = "Xerjoff Naxos", capacityMl = 5, quantity = 1))
            }
        )
    }
    var orderPriceText by remember {
        mutableStateOf(
            if (initialOrder.orderPricePln > 0) initialOrder.orderPricePln.toString().replace('.', ',') else ""
        )
    }
    var shippingCostText by remember {
        mutableStateOf(initialOrder.shippingCostPln.toString().replace('.', ','))
    }
    var isPaid by remember { mutableStateOf(initialOrder.isPaid) }

    var recipientName by remember { mutableStateOf(initialOrder.recipientName) }
    var phone by remember { mutableStateOf(initialOrder.phone) }
    var email by remember { mutableStateOf(initialOrder.email) }
    var paczkomatCode by remember { mutableStateOf(initialOrder.paczkomatCode) }
    var street by remember { mutableStateOf(initialOrder.street) }
    var postalCode by remember { mutableStateOf(initialOrder.postalCode) }
    var city by remember { mutableStateOf(initialOrder.city) }
    var carrier by remember { mutableStateOf(initialOrder.carrier) }
    var trackingNumber by remember { mutableStateOf(initialOrder.trackingNumber) }
    var deadline by remember { mutableStateOf(initialOrder.deadline) }

    var toConfirmList by remember { mutableStateOf(initialOrder.toConfirmList) }
    var newToConfirmText by remember { mutableStateOf("") }

    var detectedChangesList by remember { mutableStateOf(initialOrder.detectedChangesList) }
    var newChangeText by remember { mutableStateOf("") }

    var notes by remember { mutableStateOf(initialOrder.notes) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = AvoireBackground,
        contentColor = AvoireTextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (initialOrder.customerName.isBlank()) "Nowe zamówienie Avoire" else "Edycja zamówienia",
                        style = MaterialTheme.typography.headlineSmall,
                        color = AvoireTextPrimary
                    )
                    Text(
                        text = generateOrderTitle(customerName, items),
                        style = MaterialTheme.typography.bodySmall,
                        color = AvoireLavenderAccent
                    )
                }
                if (onDelete != null && initialOrder.customerName.isNotBlank()) {
                    IconButton(
                        onClick = { onDelete(initialOrder.id) },
                        modifier = Modifier.testTag("delete_order_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Usuń zamówienie",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            // 1. Klient i szybki wybór z bazy
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "1. Klient i status zamówienia",
                        style = MaterialTheme.typography.titleMedium,
                        color = AvoireLavenderAccent
                    )

                    if (knownCustomers.isNotEmpty()) {
                        Text(
                            text = "Wybierz stałego klienta z bazy (autouzupełnianie Paczkomatu i telefonu):",
                            style = MaterialTheme.typography.labelSmall,
                            color = AvoireTextSecondary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            knownCustomers.forEach { cust ->
                                val selected = customerId == cust.id || customerName.equals(cust.name, ignoreCase = true)
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        customerId = cust.id
                                        customerName = cust.name
                                        recipientName = cust.name
                                        if (cust.phone.isNotBlank()) phone = cust.phone
                                        if (cust.email.isNotBlank()) email = cust.email
                                        if (cust.defaultPaczkomat.isNotBlank()) paczkomatCode = cust.defaultPaczkomat
                                        if (cust.street.isNotBlank()) street = cust.street
                                        if (cust.postalCode.isNotBlank()) postalCode = cust.postalCode
                                        if (cust.city.isNotBlank()) city = cust.city
                                    },
                                    label = { Text(cust.name, style = MaterialTheme.typography.labelMedium) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AvoirePrimaryButton,
                                        selectedLabelColor = AvoireTextPrimary
                                    )
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = customerName,
                        onValueChange = {
                            customerName = it
                            if (recipientName.isBlank()) recipientName = it
                        },
                        label = { Text("Nazwa odbiorcy / klienta") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("order_customer_name_input")
                    )

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Tytuł zamówienia (zostaw puste dla automatycznego)") },
                        placeholder = { Text(generateOrderTitle(customerName, items)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Etap realizacji (6-etapowy workflow):",
                        style = MaterialTheme.typography.labelMedium,
                        color = AvoireTextSecondary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OrderStatus.entries.forEach { st ->
                            FilterChip(
                                selected = status == st,
                                onClick = { status = st },
                                label = { Text("${st.stepNumber}. ${st.labelPl}") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AvoirePrimaryButton,
                                    selectedLabelColor = AvoireTextPrimary
                                )
                            )
                        }
                    }
                }
            }

            // 2. Pozycje zapachowe (Odlewki)
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "2. Pozycje zapachowe (Odlewki)",
                                style = MaterialTheme.typography.titleMedium,
                                color = AvoireLavenderAccent
                            )
                            val paidCnt = items.filter { !it.isGratis }.sumOf { it.quantity }
                            val gratisCnt = items.filter { it.isGratis }.sumOf { it.quantity }
                            val readyCnt = items.count { it.isReady }
                            Text(
                                text = "Płatne: $paidCnt szt. • Gratisy: $gratisCnt szt. • Postęp: $readyCnt/${items.size} odlane",
                                style = MaterialTheme.typography.labelSmall,
                                color = AvoireTextSecondary
                            )
                        }
                        Button(
                            onClick = {
                                items = items + DecantItem(
                                    perfumeName = knownFlacons.firstOrNull()?.fullName ?: "",
                                    capacityMl = 5,
                                    quantity = 1
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("add_decant_item_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Dodaj odlewkę")
                        }
                    }

                    items.forEachIndexed { index, decant ->
                        DecantEditorItemCard(
                            index = index,
                            item = decant,
                            knownFlacons = knownFlacons,
                            onUpdate = { updated ->
                                items = items.toMutableList().also { it[index] = updated }
                            },
                            onRemove = {
                                items = items.toMutableList().also { it.removeAt(index) }
                            }
                        )
                    }
                }
            }

            // 3. Finanse
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "3. Finanse i płatność",
                            style = MaterialTheme.typography.titleMedium,
                            color = AvoireLavenderAccent
                        )
                        OutlinedButton(
                            onClick = {
                                val autoSum = items.filter { !it.isGratis }.sumOf { decant ->
                                    val flac = knownFlacons.firstOrNull {
                                        it.fullName.equals(decant.perfumeName, ignoreCase = true) ||
                                                decant.perfumeName.contains(it.scentName, ignoreCase = true)
                                    }
                                    val rate = flac?.pricePerMlPln ?: 12.0
                                    rate * decant.capacityMl * decant.quantity
                                }
                                val rounded = (autoSum * 100.0).roundToInt() / 100.0
                                orderPriceText = rounded.toString().replace('.', ',')
                            },
                            border = BorderStroke(1.dp, AvoireBorder),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Wylicz z ml", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = orderPriceText,
                            onValueChange = { orderPriceText = it },
                            label = { Text("Cena odlewek (zł)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_price_input")
                        )
                        OutlinedTextField(
                            value = shippingCostText,
                            onValueChange = { shippingCostText = it },
                            label = { Text("Wysyłka (zł)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    val parsedPrice = orderPriceText.replace(',', '.').toDoubleOrNull() ?: 0.0
                    val parsedShip = shippingCostText.replace(',', '.').toDoubleOrNull() ?: 17.0

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(AvoireElevated)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Razem z wysyłką: ${(parsedPrice + parsedShip).formatPln()}",
                                style = MaterialTheme.typography.titleMedium,
                                color = StatusEmeraldText
                            )
                            Text(
                                text = if (isPaid) "Status płatności: Opłacone" else "Status płatności: Oczekuje na przelew / BLIK",
                                style = MaterialTheme.typography.bodySmall,
                                color = AvoireTextSecondary
                            )
                        }
                        Switch(
                            checked = isPaid,
                            onCheckedChange = { isPaid = it },
                            modifier = Modifier.testTag("order_paid_switch")
                        )
                    }
                }
            }

            // 4. Dane wysyłki i termin realizacji
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "4. Dane wysyłki i termin",
                        style = MaterialTheme.typography.titleMedium,
                        color = AvoireLavenderAccent
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CarrierType.entries.forEach { c ->
                            FilterChip(
                                selected = carrier == c,
                                onClick = { carrier = c },
                                label = { Text(c.labelPl) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AvoirePrimaryButton,
                                    selectedLabelColor = AvoireTextPrimary
                                )
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = paczkomatCode,
                            onValueChange = { paczkomatCode = it.uppercase() },
                            label = { Text("Kod Paczkomatu (np. WAW242M)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_paczkomat_input")
                        )
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Telefon (9 cyfr)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_phone_input")
                        )
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("E-mail odbiorcy") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = street,
                            onValueChange = { street = it },
                            label = { Text("Ulica i nr") },
                            singleLine = true,
                            modifier = Modifier.weight(1.3f)
                        )
                        OutlinedTextField(
                            value = postalCode,
                            onValueChange = { postalCode = it },
                            label = { Text("Kod poczt.") },
                            singleLine = true,
                            modifier = Modifier.weight(0.7f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = city,
                            onValueChange = { city = it },
                            label = { Text("Miasto") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = deadline,
                            onValueChange = { deadline = it },
                            label = { Text("Termin realizacji") },
                            placeholder = { Text("np. Dziś 18:00") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = trackingNumber,
                        onValueChange = { trackingNumber = it },
                        label = { Text("Numer nadania / śledzenia przesyłki") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 5. Do ustalenia z klientem + Wykryte zmiany + Notatki
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "5. Do ustalenia, wykryte zmiany i notatki",
                        style = MaterialTheme.typography.titleMedium,
                        color = AvoireLavenderAccent
                    )

                    // Do ustalenia
                    Text(
                        text = "Do potwierdzenia z klientem (Bursztyn):",
                        style = MaterialTheme.typography.labelMedium,
                        color = StatusAmberText
                    )
                    toConfirmList.forEachIndexed { idx, confirmItem ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(StatusAmberBg)
                                .border(1.dp, StatusAmberBorder, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "• $confirmItem",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusAmberText,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    toConfirmList = toConfirmList.toMutableList().also { it.removeAt(idx) }
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Usuń punkt",
                                    tint = StatusAmberText,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newToConfirmText,
                            onValueChange = { newToConfirmText = it },
                            label = { Text("Dodaj rzecz do potwierdzenia...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                if (newToConfirmText.isNotBlank()) {
                                    toConfirmList = toConfirmList + newToConfirmText.trim()
                                    newToConfirmText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton)
                        ) {
                            Text("Dodaj")
                        }
                    }

                    HorizontalDivider(color = AvoireBorder)

                    // Wykryte zmiany w rozmowie
                    Text(
                        text = "Wykryte zmiany w rozmowie:",
                        style = MaterialTheme.typography.labelMedium,
                        color = AvoireLavenderAccent
                    )
                    detectedChangesList.forEachIndexed { idx, changeItem ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(AvoireElevated)
                                .border(1.dp, AvoireBorder, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "⇄ $changeItem",
                                style = MaterialTheme.typography.bodySmall,
                                color = AvoireLavenderAccent,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    detectedChangesList = detectedChangesList.toMutableList().also { it.removeAt(idx) }
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Usuń zmianę",
                                    tint = AvoireLavenderAccent,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newChangeText,
                            onValueChange = { newChangeText = it },
                            label = { Text("Dodaj adnotację o zmianie...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                if (newChangeText.isNotBlank()) {
                                    detectedChangesList = detectedChangesList + newChangeText.trim()
                                    newChangeText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton)
                        ) {
                            Text("Dodaj")
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notatki własne do zamówienia") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Zapisz / Anuluj
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    border = BorderStroke(1.dp, AvoireBorder),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                ) {
                    Text("Anuluj", color = AvoireTextPrimary)
                }

                Button(
                    onClick = {
                        val cleanCustomer = customerName.trim().ifBlank { "Klient Avoire" }
                        val parsedPrice = orderPriceText.replace(',', '.').toDoubleOrNull() ?: 0.0
                        val parsedShip = shippingCostText.replace(',', '.').toDoubleOrNull() ?: 17.0
                        val finalOrder = initialOrder.copy(
                            customerName = cleanCustomer,
                            customerId = customerId,
                            title = title.trim().ifBlank { generateOrderTitle(cleanCustomer, items) },
                            status = status,
                            items = items.filter { it.perfumeName.isNotBlank() },
                            orderPricePln = parsedPrice,
                            shippingCostPln = parsedShip,
                            isPaid = isPaid,
                            recipientName = recipientName.ifBlank { cleanCustomer },
                            phone = phone.trim(),
                            email = email.trim(),
                            paczkomatCode = paczkomatCode.trim().uppercase(),
                            street = street.trim(),
                            postalCode = postalCode.trim(),
                            city = city.trim(),
                            carrier = carrier,
                            trackingNumber = trackingNumber.trim(),
                            deadline = deadline.trim(),
                            toConfirmList = toConfirmList,
                            detectedChangesList = detectedChangesList,
                            notes = notes.trim(),
                            updatedAt = System.currentTimeMillis()
                        )
                        onSave(finalOrder)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                    modifier = Modifier
                        .weight(1.5f)
                        .height(52.dp)
                        .testTag("save_order_button")
                ) {
                    Text(
                        text = "Zapisz zamówienie",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DecantEditorItemCard(
    index: Int,
    item: DecantItem,
    knownFlacons: List<FlaconEntity>,
    onUpdate: (DecantItem) -> Unit,
    onRemove: () -> Unit
) {
    var customMlText by remember(item.capacityMl) {
        mutableStateOf(item.capacityMl.toString())
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = AvoireElevated),
        border = BorderStroke(1.dp, AvoireBorder),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Odlewka #${index + 1}",
                        style = MaterialTheme.typography.labelLarge,
                        color = AvoireLavenderAccent
                    )
                    if (item.isGratis) {
                        TonePill(text = "GRATIS / PRÓBKA", tone = PillTone.LAVENDER)
                    }
                    if (item.needsAvailabilityCheck) {
                        TonePill(text = "SPRAWDŹ FLAKON", tone = PillTone.AMBER)
                    }
                }
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Usuń odlewkę",
                        tint = AvoireTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            OutlinedTextField(
                value = item.perfumeName,
                onValueChange = { onUpdate(item.copy(perfumeName = it)) },
                label = { Text("Nazwa perfum (np. Xerjoff Naxos)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            if (knownFlacons.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    knownFlacons.take(6).forEach { flac ->
                        val isCurrent = item.perfumeName.equals(flac.fullName, ignoreCase = true)
                        TonePill(
                            text = "${flac.fullName} (${flac.currentVolumeMl} ml)",
                            tone = if (isCurrent) PillTone.LAVENDER else PillTone.NEUTRAL,
                            modifier = Modifier.clickable {
                                onUpdate(
                                    item.copy(
                                        perfumeName = flac.fullName,
                                        needsAvailabilityCheck = flac.isLowStock
                                    )
                                )
                            }
                        )
                    }
                }
            }

            Text(
                text = "Pojemność odlewki w ml (szybki wybór lub własna):",
                style = MaterialTheme.typography.labelSmall,
                color = AvoireTextSecondary
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                QUICK_CAPACITIES_ML.forEach { ml ->
                    val selected = item.capacityMl == ml
                    SurfaceChip(
                        label = "$ml ml",
                        selected = selected,
                        onClick = {
                            customMlText = ml.toString()
                            onUpdate(item.copy(capacityMl = ml))
                        }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = customMlText,
                    onValueChange = { raw ->
                        customMlText = raw
                        raw.toIntOrNull()?.let { validMl ->
                            if (validMl > 0) onUpdate(item.copy(capacityMl = validMl))
                        }
                    },
                    label = { Text("Własna (ml)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(AvoireCard)
                        .border(1.dp, AvoireBorder, RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("Sztuk:", style = MaterialTheme.typography.labelMedium)
                    OutlinedButton(
                        onClick = {
                            if (item.quantity > 1) onUpdate(item.copy(quantity = item.quantity - 1))
                        },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("-")
                    }
                    Text(
                        text = item.quantity.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        color = AvoireTextPrimary
                    )
                    OutlinedButton(
                        onClick = {
                            onUpdate(item.copy(quantity = item.quantity + 1))
                        },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("+")
                    }
                }
            }

            // Przełączniki: Gratis, Odlane/Gotowe, Sprawdź dostępność
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = item.isReady,
                    onClick = { onUpdate(item.copy(isReady = !item.isReady)) },
                    label = { Text("Odlane / Gotowe") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StatusEmeraldText.copy(alpha = 0.2f),
                        selectedLabelColor = StatusEmeraldText
                    )
                )
                FilterChip(
                    selected = item.isGratis,
                    onClick = { onUpdate(item.copy(isGratis = !item.isGratis)) },
                    label = { Text("Gratis / Próbka") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AvoirePrimaryButton,
                        selectedLabelColor = AvoireTextPrimary
                    )
                )
                FilterChip(
                    selected = item.needsAvailabilityCheck,
                    onClick = { onUpdate(item.copy(needsAvailabilityCheck = !item.needsAvailabilityCheck)) },
                    label = { Text("Sprawdź flakon") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StatusAmberBg,
                        selectedLabelColor = StatusAmberText
                    )
                )
            }

            OutlinedTextField(
                value = item.note,
                onValueChange = { onUpdate(item.copy(note = it)) },
                label = { Text("Notatka do odlewki (np. złoty atomizer, podpis)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun SurfaceChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (selected) AvoirePrimaryButton else AvoireCard
    val fg = if (selected) AvoireTextPrimary else AvoireTextSecondary
    val border = if (selected) AvoireLavenderAccent else AvoireBorder

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = fg
        )
    }
}
