package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DecantItem
import com.example.data.OrderEntity
import com.example.data.OrderStatus
import com.example.data.SimpleOrderBucket
import com.example.data.WorkshopTaskEntity
import com.example.data.formatPlnCompact
import com.example.ui.components.copyToClipboard
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireBorder
import com.example.ui.theme.AvoireBorderHighlight
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireElevated
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoirePrimaryButton
import com.example.ui.theme.AvoireSoftViolet
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary
import com.example.ui.theme.StatusAmberText
import com.example.ui.theme.StatusCoralText
import com.example.ui.theme.StatusEmeraldText
import com.example.ui.theme.StatusSkyText
import java.util.Locale

@Composable
fun OrdersScreen(
    orders: List<OrderEntity>,
    tasks: List<WorkshopTaskEntity> = emptyList(),
    searchQuery: String,
    selectedStatusFilter: OrderStatus?,
    onSearchChange: (String) -> Unit,
    onStatusFilterChange: (OrderStatus?) -> Unit,
    onOpenNewOrder: () -> Unit,
    onOpenAiTab: () -> Unit,
    onOpenTasksTab: () -> Unit = {},
    onToggleTaskDone: (String) -> Unit = {},
    onEditOrder: (OrderEntity) -> Unit,
    onToggleDecantReady: (String, String, Boolean) -> Unit,
    onToggleOrderPacked: (String) -> Unit = {},
    onAdvanceStatus: (OrderEntity, OrderStatus) -> Unit,
    onTogglePaid: (String, Boolean) -> Unit,
    onCopyFeedback: (String) -> Unit = {}
) {
    // Default to ALL so all 3 sample orders are immediately visible as in Screenshot 1
    var selectedBucket by remember { mutableStateOf(SimpleOrderBucket.ALL) }

    val toHandleCount = remember(orders) {
        orders.count { it.simpleBucket == SimpleOrderBucket.TO_HANDLE }
    }
    val inProgressCount = remember(orders) {
        orders.count { it.simpleBucket == SimpleOrderBucket.IN_PROGRESS }
    }
    val shippedCount = remember(orders) {
        orders.count { it.simpleBucket == SimpleOrderBucket.SHIPPED }
    }
    val allCount = orders.size

    val filteredOrders = remember(orders, searchQuery, selectedBucket, selectedStatusFilter) {
        orders.filter { order ->
            val matchesBucket = when (selectedBucket) {
                SimpleOrderBucket.TO_HANDLE -> order.simpleBucket == SimpleOrderBucket.TO_HANDLE
                SimpleOrderBucket.IN_PROGRESS -> order.simpleBucket == SimpleOrderBucket.IN_PROGRESS
                SimpleOrderBucket.SHIPPED -> order.simpleBucket == SimpleOrderBucket.SHIPPED
                SimpleOrderBucket.ALL -> true
            }
            val matchesStatus = selectedStatusFilter == null || order.status == selectedStatusFilter
            val q = searchQuery.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                    order.customerName.lowercase().contains(q) ||
                    order.displayTitle.lowercase().contains(q) ||
                    order.paczkomatCode.lowercase().contains(q) ||
                    order.phone.lowercase().contains(q) ||
                    order.trackingNumber.lowercase().contains(q) ||
                    order.items.any { it.perfumeName.lowercase().contains(q) }
            matchesBucket && matchesStatus && matchesQuery
        }
    }

    val pendingTasks = remember(tasks) { tasks.filter { !it.isDone } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AvoireBackground)
            .testTag("orders_list"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Rounded Pill Search Bar (Matches Screenshot 1)
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = {
                    Text(
                        text = "Szukaj odbiorcy, zapachu, Paczkomatu lub telefonu...",
                        color = AvoireTextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Szukaj",
                        tint = AvoireTextSecondary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Wyczyść wyszukiwanie",
                                tint = AvoireTextSecondary
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = AvoireCard,
                    unfocusedContainerColor = AvoireCard,
                    focusedBorderColor = AvoireLavenderAccent,
                    unfocusedBorderColor = AvoireBorder,
                    focusedTextColor = AvoireTextPrimary,
                    unfocusedTextColor = AvoireTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("orders_search_input")
            )
        }

        // 2. Segmented 4-Tab Filter Bar (Do ogarnięcia | W trakcie | Wysłane | Wszystkie)
        item {
            SegmentedOrderBucketBar(
                selectedBucket = selectedBucket,
                toHandleCount = toHandleCount,
                inProgressCount = inProgressCount,
                shippedCount = shippedCount,
                allCount = allCount,
                onSelectBucket = { bucket ->
                    selectedBucket = bucket
                    onStatusFilterChange(null)
                }
            )
        }

        // 3. Orders List or Empty State
        if (filteredOrders.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AvoireCard),
                    border = BorderStroke(1.dp, AvoireBorder),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Brak paczek w tym widoku",
                            style = MaterialTheme.typography.titleMedium,
                            color = AvoireTextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Przełącz filtr na „Wszystkie” lub dodaj nową paczkę jednym kliknięciem.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AvoireTextSecondary
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { selectedBucket = SimpleOrderBucket.ALL },
                                border = BorderStroke(1.dp, AvoireBorder),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Pokaż wszystkie ($allCount)", color = AvoireLavenderAccent)
                            }
                            Button(
                                onClick = onOpenNewOrder,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFA78BFA),
                                    contentColor = AvoireBackground
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.testTag("new_manual_order_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Dodaj paczkę")
                            }
                        }
                    }
                }
            }
        } else {
            items(filteredOrders, key = { it.id }) { order ->
                SimplePaczkaCard(
                    order = order,
                    onEditOrder = { onEditOrder(order) },
                    onToggleDecantReady = { decantId, ready ->
                        onToggleDecantReady(order.id, decantId, ready)
                    },
                    onTogglePacked = { onToggleOrderPacked(order.id) },
                    onAdvanceStatus = { next -> onAdvanceStatus(order, next) },
                    onCopyFeedback = onCopyFeedback
                )
            }
        }

        // 4. Quick Action Bar (Dodaj ręcznie / Wklej z rozmowy AI)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenNewOrder,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AvoirePrimaryButton,
                        contentColor = AvoireTextPrimary
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("new_manual_order_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Nowa paczka", fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = onOpenAiTab,
                    border = BorderStroke(1.dp, AvoireBorderHighlight),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = AvoireSoftViolet,
                        contentColor = AvoireLavenderAccent
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("shortcut_ai_order_button")
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Z rozmowy AI", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // 5. SZYBKIE ZADANIA Widget (Matches Screenshot 2)
        item {
            QuickTasksSummaryCard(
                pendingTasks = pendingTasks,
                onOpenTasksTab = onOpenTasksTab,
                onToggleTaskDone = onToggleTaskDone
            )
        }

        // 6. OSTATNIE ZAMÓWIENIA Widget (Matches Screenshot 2)
        if (orders.isNotEmpty()) {
            item {
                RecentOrdersSummaryCard(
                    orders = orders,
                    onShowAll = { selectedBucket = SimpleOrderBucket.ALL },
                    onClickOrder = onEditOrder
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SegmentedOrderBucketBar(
    selectedBucket: SimpleOrderBucket,
    toHandleCount: Int,
    inProgressCount: Int,
    shippedCount: Int,
    allCount: Int,
    onSelectBucket: (SimpleOrderBucket) -> Unit
) {
    Surface(
        color = AvoireCard,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, AvoireBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val buckets = listOf(
                Triple(SimpleOrderBucket.TO_HANDLE, toHandleCount, null),
                Triple(SimpleOrderBucket.IN_PROGRESS, inProgressCount, StatusSkyText),
                Triple(SimpleOrderBucket.SHIPPED, shippedCount, StatusEmeraldText),
                Triple(SimpleOrderBucket.ALL, allCount, null)
            )

            buckets.forEach { (bucket, count, dotColor) ->
                val isSelected = selectedBucket == bucket
                Surface(
                    color = if (isSelected) AvoireSoftViolet else Color.Transparent,
                    shape = RoundedCornerShape(12.dp),
                    border = if (isSelected) BorderStroke(1.dp, AvoireBorderHighlight) else null,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectBucket(bucket) }
                        .testTag("filter_bucket_${bucket.name.lowercase()}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (dotColor != null) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(dotColor)
                            )
                        }
                        Text(
                            text = bucket.labelPl,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (isSelected) AvoireTextPrimary else AvoireTextSecondary
                        )
                        Text(
                            text = count.toString(),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = if (isSelected) AvoireLavenderAccent else AvoireTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SimplePaczkaCard(
    order: OrderEntity,
    onEditOrder: () -> Unit,
    onToggleDecantReady: (String, Boolean) -> Unit,
    onTogglePacked: () -> Unit,
    onAdvanceStatus: (OrderStatus) -> Unit,
    onCopyFeedback: (String) -> Unit
) {
    val context = LocalContext.current
    var showDecantsChecklist by remember { mutableStateOf(false) }

    val (statusLabel, statusColor) = when (order.simpleBucket) {
        SimpleOrderBucket.TO_HANDLE -> "Do ogarnięcia" to StatusAmberText
        SimpleOrderBucket.IN_PROGRESS -> "W trakcie" to StatusSkyText
        SimpleOrderBucket.SHIPPED -> "Wysłane" to StatusEmeraldText
        SimpleOrderBucket.ALL -> "W trakcie" to StatusSkyText
    }

    val nextBucketStatus = when (order.simpleBucket) {
        SimpleOrderBucket.TO_HANDLE -> OrderStatus.DECANTING
        SimpleOrderBucket.IN_PROGRESS -> OrderStatus.SHIPPED
        SimpleOrderBucket.SHIPPED -> OrderStatus.NEW
        SimpleOrderBucket.ALL -> OrderStatus.SHIPPED
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = AvoireCard),
        border = BorderStroke(1.dp, AvoireBorder),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEditOrder() }
            .testTag("order_card_${order.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // 1. Header: UPPERCASE SERIF CUSTOMER NAME + Status Pill on right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = order.customerName.uppercase(Locale("pl", "PL")),
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp,
                        letterSpacing = 0.5.sp
                    ),
                    color = AvoireTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onAdvanceStatus(nextBucketStatus) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                        .testTag("advance_status_${order.id}")
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Text(
                        text = statusLabel,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = statusColor
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Zmień status",
                        tint = statusColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // 2. Optional Warning line: "⚠ Do potwierdzenia (1)"
            if (order.toConfirmList.isNotEmpty() || order.items.any { it.needsAvailabilityCheck }) {
                val warnCount = maxOf(
                    order.toConfirmList.size,
                    order.items.count { it.needsAvailabilityCheck }
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = "Do potwierdzenia",
                        tint = StatusCoralText,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Do potwierdzenia ($warnCount)",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = StatusCoralText
                    )
                }
            }

            // 3. Subtitle: Short descriptive order title
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = order.displayTitle,
                style = MaterialTheme.typography.bodyMedium,
                color = AvoireTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Zawartość pill box (Matches Screenshot 1 & 2, expands checklist on tap)
            Surface(
                color = Color(0xFF171422),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, AvoireBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { showDecantsChecklist = !showDecantsChecklist }
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Zawartość: ",
                                style = MaterialTheme.typography.bodySmall,
                                color = AvoireTextSecondary
                            )
                            Text(
                                text = order.contentSummaryText,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = AvoireTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "${order.totalVolumeMl} ml (${order.totalItemsCount} szt.) · ${order.orderPricePln.formatPlnCompact()}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = AvoireLavenderAccent
                        )
                    }

                    // Expandable decant items checklist when tapped
                    AnimatedVisibility(visible = showDecantsChecklist) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            HorizontalDivider(color = AvoireBorder)
                            order.items.forEach { decant ->
                                DecantQuickRow(
                                    decant = decant,
                                    onToggleReady = { ready ->
                                        onToggleDecantReady(decant.id, ready)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 5. Status icons row: Niespakowana/Spakowana | Nienadana/Nadana | Paczkomat Code
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                val isPacked = order.isEffectivelyPacked
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onTogglePacked() }
                        .padding(vertical = 2.dp)
                        .testTag("toggle_packed_${order.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = null,
                        tint = if (isPacked) StatusEmeraldText else AvoireTextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = if (isPacked) "Spakowana" else "Niespakowana",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = if (isPacked) FontWeight.SemiBold else FontWeight.Normal
                        ),
                        color = if (isPacked) StatusEmeraldText else AvoireTextSecondary
                    )
                }

                val isShipped = order.isEffectivelyShipped
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            val target = if (isShipped) OrderStatus.READY_TO_SHIP else OrderStatus.SHIPPED
                            onAdvanceStatus(target)
                        }
                        .padding(vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalShipping,
                        contentDescription = null,
                        tint = if (isShipped) StatusEmeraldText else AvoireTextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = if (isShipped) "Nadana" else "Nienadana",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = if (isShipped) FontWeight.SemiBold else FontWeight.Normal
                        ),
                        color = if (isShipped) StatusEmeraldText else AvoireTextSecondary
                    )
                }

                val locationCode = order.paczkomatCode.ifBlank { order.city.ifBlank { "Brak kodu" } }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            if (order.paczkomatCode.isNotBlank()) {
                                copyToClipboard(
                                    context,
                                    "Kod Paczkomatu ${order.paczkomatCode}",
                                    order.paczkomatCode,
                                    onCopyFeedback
                                )
                            } else {
                                onEditOrder()
                            }
                        }
                        .padding(vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = null,
                        tint = AvoireLavenderAccent,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = locationCode,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = AvoireTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 6. Date badge & Tracking number row (Matches Screenshot 1 & 2)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = AvoireElevated,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, AvoireBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = AvoireLavenderAccent,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = order.deadline.ifBlank { "2026-10-25" },
                            style = MaterialTheme.typography.labelMedium,
                            color = AvoireTextPrimary
                        )
                    }
                }

                if (order.trackingNumber.isNotBlank()) {
                    Text(
                        text = "Nr: ${order.trackingNumber}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = StatusEmeraldText,
                        modifier = Modifier.clickable {
                            copyToClipboard(
                                context,
                                "Numer nadania ${order.trackingNumber}",
                                order.trackingNumber,
                                onCopyFeedback
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun DecantQuickRow(
    decant: DecantItem,
    onToggleReady: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onToggleReady(!decant.isReady) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = if (decant.isReady) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                contentDescription = null,
                tint = if (decant.isReady) StatusEmeraldText else AvoireLavenderAccent,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = decant.perfumeName,
                style = MaterialTheme.typography.bodySmall.copy(
                    textDecoration = if (decant.isReady) TextDecoration.LineThrough else TextDecoration.None
                ),
                color = if (decant.isReady) AvoireTextSecondary else AvoireTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "${decant.quantity}x ${decant.capacityMl} ml" + if (decant.isGratis) " (GRATIS)" else "",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = if (decant.isGratis) StatusAmberText else AvoireLavenderAccent
        )
    }
}

@Composable
private fun QuickTasksSummaryCard(
    pendingTasks: List<WorkshopTaskEntity>,
    onOpenTasksTab: () -> Unit,
    onToggleTaskDone: (String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = AvoireCard),
        border = BorderStroke(1.dp, AvoireBorder),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckBox,
                        contentDescription = null,
                        tint = AvoireLavenderAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "SZYBKIE ZADANIA (${pendingTasks.size})",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        ),
                        color = AvoireTextSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onOpenTasksTab() }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Wszystkie",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = AvoireLavenderAccent
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = AvoireLavenderAccent,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (pendingTasks.isEmpty()) {
                Text(
                    text = "Wszystkie zadania wykonane.",
                    style = MaterialTheme.typography.bodySmall,
                    color = AvoireTextSecondary
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    pendingTasks.take(3).forEach { task ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(AvoireElevated)
                                .clickable { onToggleTaskDone(task.id) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckBoxOutlineBlank,
                                contentDescription = null,
                                tint = AvoireLavenderAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.bodySmall,
                                color = AvoireTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecentOrdersSummaryCard(
    orders: List<OrderEntity>,
    onShowAll: () -> Unit,
    onClickOrder: (OrderEntity) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = AvoireCard),
        border = BorderStroke(1.dp, AvoireBorder),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "OSTATNIE ZAMÓWIENIA",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    ),
                    color = AvoireTextSecondary
                )
                Text(
                    text = "Pokaż wszystkie (${orders.size})",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = AvoireLavenderAccent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onShowAll() }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                orders.take(3).forEach { order ->
                    Surface(
                        color = Color(0xFF171422),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, AvoireBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onClickOrder(order) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = order.customerName,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = AvoireTextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = order.displayTitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AvoireTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${order.items.size} poz.",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = AvoireTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
