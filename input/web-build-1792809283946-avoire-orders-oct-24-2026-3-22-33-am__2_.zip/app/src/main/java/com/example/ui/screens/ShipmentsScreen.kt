package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CarrierType
import com.example.data.OrderEntity
import com.example.data.OrderStatus
import com.example.data.formatPln
import com.example.ui.components.OrderStatusBadge
import com.example.ui.components.PillTone
import com.example.ui.components.TonePill
import com.example.ui.components.copyToClipboard
import com.example.ui.components.sharePlainText
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireBorder
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireElevated
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoirePrimaryButton
import com.example.ui.theme.AvoireSoftViolet
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary
import com.example.ui.theme.StatusAmberText
import com.example.ui.theme.StatusCoralText
import com.example.ui.theme.StatusEmeraldBg
import com.example.ui.theme.StatusEmeraldBorder
import com.example.ui.theme.StatusEmeraldText

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShipmentsScreen(
    orders: List<OrderEntity>,
    onMarkAsShipped: (OrderEntity, String) -> Unit,
    onMarkReadyToShip: (OrderEntity) -> Unit,
    onEditOrder: (OrderEntity) -> Unit,
    onCopyFeedback: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedCarrier by remember { mutableStateOf<CarrierType?>(null) }
    var showShippedHistory by remember { mutableStateOf(false) }
    var orderForTrackingDialog by remember { mutableStateOf<OrderEntity?>(null) }

    val pendingShipmentOrders = remember(orders, selectedCarrier) {
        orders.filter { ord ->
            val isPending = ord.status == OrderStatus.READY_TO_SHIP ||
                    ord.status == OrderStatus.DECANTING ||
                    ord.status == OrderStatus.TO_DECANT ||
                    ord.status == OrderStatus.NEW
            val matchesCarrier = selectedCarrier == null || ord.carrier == selectedCarrier
            isPending && matchesCarrier
        }.sortedByDescending { it.status == OrderStatus.READY_TO_SHIP }
    }

    val shippedOrders = remember(orders, selectedCarrier) {
        orders.filter { ord ->
            (ord.status == OrderStatus.SHIPPED || ord.status == OrderStatus.COMPLETED) &&
                    (selectedCarrier == null || ord.carrier == selectedCarrier)
        }
    }

    val displayedOrders = if (showShippedHistory) shippedOrders else pendingShipmentOrders
    val groupedByCarrier = remember(displayedOrders) {
        displayedOrders.groupBy { it.carrier }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AvoireBackground)
            .testTag("shipments_list"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Podsumowanie wysyłek i przewoźników
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(AvoireSoftViolet.copy(alpha = 0.7f), AvoireCard)
                            )
                        )
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CENTRUM WYSYŁEK I NADANIA",
                                style = MaterialTheme.typography.labelSmall,
                                color = AvoireLavenderAccent
                            )
                            val readyCnt = orders.count { it.status == OrderStatus.READY_TO_SHIP }
                            Text(
                                text = "$readyCnt gotowych do nadania",
                                style = MaterialTheme.typography.displaySmall,
                                color = AvoireTextPrimary
                            )
                        }
                        TonePill(
                            text = "Oczekujące: ${pendingShipmentOrders.size}",
                            tone = PillTone.EMERALD
                        )
                    }

                    // Przełącznik: Oczekujące na wysyłkę vs Wysłane
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showShippedHistory = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!showShippedHistory) AvoirePrimaryButton else AvoireElevated,
                                contentColor = AvoireTextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        ) {
                            Text("Do wysyłki (${pendingShipmentOrders.size})")
                        }
                        Button(
                            onClick = { showShippedHistory = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (showShippedHistory) AvoirePrimaryButton else AvoireElevated,
                                contentColor = AvoireTextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        ) {
                            Text("Wysłane (${shippedOrders.size})")
                        }
                    }

                    // Filtry przewoźników (InPost Paczkomat / Kurier / DPD / Orlen Paczka)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CarrierChip(
                            label = "Wszyscy przewoźnicy",
                            selected = selectedCarrier == null,
                            onClick = { selectedCarrier = null }
                        )
                        CarrierType.entries.forEach { carrier ->
                            val cnt = orders.count {
                                it.carrier == carrier &&
                                        (if (showShippedHistory) it.status == OrderStatus.SHIPPED || it.status == OrderStatus.COMPLETED
                                        else it.status != OrderStatus.SHIPPED && it.status != OrderStatus.COMPLETED)
                            }
                            CarrierChip(
                                label = "${carrier.shortLabel} ($cnt)",
                                selected = selectedCarrier == carrier,
                                onClick = {
                                    selectedCarrier = if (selectedCarrier == carrier) null else carrier
                                }
                            )
                        }
                    }
                }
            }
        }

        // 2. Grupowanie według przewoźnika
        if (groupedByCarrier.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AvoireCard),
                    border = BorderStroke(1.dp, AvoireBorder),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Brak przesyłek w wybranej kategorii",
                            style = MaterialTheme.typography.titleMedium,
                            color = AvoireTextPrimary
                        )
                    }
                }
            }
        } else {
            groupedByCarrier.forEach { (carrier, carrierOrders) ->
                item(key = "header_${carrier.name}") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, bottom = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalShipping,
                                contentDescription = null,
                                tint = AvoireLavenderAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = carrier.labelPl.uppercase(),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = AvoireLavenderAccent
                            )
                        }
                        TonePill(
                            text = "${carrierOrders.size} paczek",
                            tone = PillTone.LAVENDER
                        )
                    }
                }

                items(carrierOrders, key = { "ship_${it.id}" }) { order ->
                    ShipmentOrderCard(
                        order = order,
                        onCopyField = { label, value ->
                            copyToClipboard(context, label, value, onCopyFeedback)
                        },
                        onMarkReady = { onMarkReadyToShip(order) },
                        onOpenShippedDialog = { orderForTrackingDialog = order },
                        onEditOrder = { onEditOrder(order) }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    orderForTrackingDialog?.let { targetOrder ->
        MarkAsShippedDialog(
            order = targetOrder,
            onConfirmShipped = { trackingNumber ->
                onMarkAsShipped(targetOrder, trackingNumber)
                orderForTrackingDialog = null
            },
            onDismiss = { orderForTrackingDialog = null }
        )
    }
}

@Composable
private fun CarrierChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) AvoirePrimaryButton else AvoireElevated,
        shape = RoundedCornerShape(9.dp),
        border = BorderStroke(1.dp, if (selected) AvoireLavenderAccent else AvoireBorder),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) AvoireTextPrimary else AvoireTextSecondary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ShipmentOrderCard(
    order: OrderEntity,
    onCopyField: (String, String) -> Unit,
    onMarkReady: () -> Unit,
    onOpenShippedDialog: () -> Unit,
    onEditOrder: () -> Unit
) {
    val context = LocalContext.current
    val fullAddress = remember(order) {
        listOf(order.street, "${order.postalCode} ${order.city}".trim())
            .filter { it.isNotBlank() }
            .joinToString(", ")
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = AvoireCard),
        border = BorderStroke(
            1.dp,
            if (order.status == OrderStatus.READY_TO_SHIP) StatusEmeraldBorder else AvoireBorder
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shipment_card_${order.id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onEditOrder() }
                ) {
                    Text(
                        text = order.recipientName.ifBlank { order.customerName },
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = AvoireTextPrimary
                    )
                    Text(
                        text = order.displayTitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = AvoireTextSecondary
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    OrderStatusBadge(status = order.status)
                    Spacer(modifier = Modifier.height(4.dp))
                    TonePill(
                        text = if (order.isPaid) "Opłacone (${order.totalWithShippingPln.formatPln()})"
                        else "Nieopłacone (${order.totalWithShippingPln.formatPln()})",
                        tone = if (order.isPaid) PillTone.EMERALD else PillTone.CORAL
                    )
                }
            }

            // Kopiowanie danych jednym kliknięciem: Kod Paczkomatu, Telefon, E-mail, Adres
            Text(
                text = "Kopiuj dane wysyłkowe jednym kliknięciem:",
                style = MaterialTheme.typography.labelSmall,
                color = AvoireLavenderAccent
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OneTapCopyButton(
                    title = "Paczkomat",
                    value = order.paczkomatCode.ifBlank { "Brak kodu!" },
                    isMissing = order.paczkomatCode.isBlank() && order.carrier == CarrierType.INPOST_LOCKER,
                    onClick = {
                        if (order.paczkomatCode.isNotBlank()) {
                            onCopyField("Kod Paczkomatu", order.paczkomatCode)
                        }
                    },
                    testTag = "copy_paczkomat_${order.id}"
                )

                OneTapCopyButton(
                    title = "Telefon",
                    value = order.phone.ifBlank { "Brak telefonu!" },
                    isMissing = order.phone.isBlank(),
                    onClick = {
                        if (order.phone.isNotBlank()) {
                            onCopyField("Telefon", order.phone)
                        }
                    },
                    testTag = "copy_phone_${order.id}"
                )

                if (order.email.isNotBlank()) {
                    OneTapCopyButton(
                        title = "E-mail",
                        value = order.email,
                        isMissing = false,
                        onClick = { onCopyField("E-mail", order.email) },
                        testTag = "copy_email_${order.id}"
                    )
                }

                if (fullAddress.isNotBlank()) {
                    OneTapCopyButton(
                        title = "Adres",
                        value = fullAddress,
                        isMissing = false,
                        onClick = { onCopyField("Adres", fullAddress) },
                        testTag = "copy_address_${order.id}"
                    )
                }
            }

            if (order.trackingNumber.isNotBlank()) {
                Surface(
                    color = StatusEmeraldBg,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StatusEmeraldBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Numer śledzenia przesyłki:",
                                style = MaterialTheme.typography.labelSmall,
                                color = StatusEmeraldText
                            )
                            Text(
                                text = order.trackingNumber,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = StatusEmeraldText
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { onCopyField("Numer śledzenia", order.trackingNumber) },
                                border = BorderStroke(1.dp, StatusEmeraldBorder),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Kopiuj nr")
                            }
                            OutlinedButton(
                                onClick = {
                                    val msg = "Dzień dobry! Twoja paczka z odlewkami Avoire została nadana (${order.carrier.labelPl}). Numer śledzenia: ${order.trackingNumber}"
                                    sharePlainText(context, "Przesyłka Avoire", msg)
                                },
                                border = BorderStroke(1.dp, StatusEmeraldBorder),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = AvoireBorder)

            // Przycisk oznaczania jako "Gotowe do wysyłki" lub "Oznacz jako wysłane (z numerem śledzenia)"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (order.status != OrderStatus.READY_TO_SHIP &&
                    order.status != OrderStatus.SHIPPED &&
                    order.status != OrderStatus.COMPLETED
                ) {
                    OutlinedButton(
                        onClick = onMarkReady,
                        border = BorderStroke(1.dp, StatusEmeraldBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = StatusEmeraldBg,
                            contentColor = StatusEmeraldText
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Gotowe do wysyłki")
                    }
                }

                Button(
                    onClick = onOpenShippedDialog,
                    colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp)
                        .testTag("mark_shipped_button_${order.id}")
                ) {
                    Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (order.status == OrderStatus.SHIPPED) "Zmień nr nadania" else "Oznacz jako wysłane",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun OneTapCopyButton(
    title: String,
    value: String,
    isMissing: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        color = AvoireElevated,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(
            1.dp,
            if (isMissing) StatusCoralText.copy(alpha = 0.7f) else AvoireBorder
        ),
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ContentCopy,
                contentDescription = "Kopiuj $title",
                tint = if (isMissing) StatusCoralText else AvoireLavenderAccent,
                modifier = Modifier.size(15.dp)
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = AvoireTextSecondary
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = if (isMissing) StatusCoralText else AvoireTextPrimary
                )
            }
        }
    }
}

@Composable
private fun MarkAsShippedDialog(
    order: OrderEntity,
    onConfirmShipped: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var trackingNumber by remember {
        mutableStateOf(
            order.trackingNumber.ifBlank {
                "620000${(100000..999999).random()}"
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AvoireCard,
        titleContentColor = AvoireTextPrimary,
        textContentColor = AvoireTextSecondary,
        title = {
            Text(
                text = "Oznacz jako wysłane",
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Odbiorca: ${order.recipientName.ifBlank { order.customerName }}\nPrzewoźnik: ${order.carrier.labelPl} ${order.paczkomatCode}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AvoireLavenderAccent
                )
                OutlinedTextField(
                    value = trackingNumber,
                    onValueChange = { trackingNumber = it },
                    label = { Text("Numer śledzenia / nadania przesyłki") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tracking_number_input")
                )
                Text(
                    text = "Po zatwierdzeniu zamówienie zmieni status na „5. Wysłane”, a aplikacja wyśle powiadomienie push i przygotuje wiadomość z numerem śledzenia dla klienta.",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusAmberText
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmShipped(trackingNumber.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = AvoirePrimaryButton),
                modifier = Modifier.testTag("confirm_shipped_dialog_button")
            ) {
                Text("Zatwierdź wysyłkę")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Anuluj", color = AvoireTextSecondary)
            }
        }
    )
}
