package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WorkshopTaskEntity
import com.example.ui.theme.AvoireBackground
import com.example.ui.theme.AvoireBorder
import com.example.ui.theme.AvoireCard
import com.example.ui.theme.AvoireLavenderAccent
import com.example.ui.theme.AvoireTextPrimary
import com.example.ui.theme.AvoireTextSecondary

@Composable
fun TasksScreen(
    tasks: List<WorkshopTaskEntity>,
    onAddTask: (String, String) -> Unit,
    onToggleTask: (String) -> Unit,
    onDeleteTask: (String) -> Unit
) {
    var taskTitle by remember { mutableStateOf("") }
    var taskNote by remember { mutableStateOf("") }
    var showNoteField by remember { mutableStateOf(false) }

    val pendingTasks = remember(tasks) { tasks.filter { !it.isDone } }
    val doneTasks = remember(tasks) { tasks.filter { it.isDone } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AvoireBackground)
            .testTag("tasks_list"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Quick Add Workshop Task Card (Matches Screenshot 9)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AvoireCard),
                border = BorderStroke(1.dp, AvoireBorder),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = taskTitle,
                            onValueChange = { taskTitle = it },
                            placeholder = {
                                Text(
                                    text = "Dodaj szybkie zadanie pracowni (np. Zamówi...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AvoireTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF171422),
                                unfocusedContainerColor = Color(0xFF171422),
                                focusedBorderColor = AvoireLavenderAccent,
                                unfocusedBorderColor = AvoireBorder,
                                focusedTextColor = AvoireTextPrimary,
                                unfocusedTextColor = AvoireTextPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("task_title_input")
                        )

                        Button(
                            onClick = {
                                if (taskTitle.isNotBlank()) {
                                    onAddTask(taskTitle, taskNote)
                                    taskTitle = ""
                                    taskNote = ""
                                    showNoteField = false
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFA78BFA),
                                contentColor = AvoireBackground
                            ),
                            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
                            modifier = Modifier
                                .height(50.dp)
                                .testTag("add_task_button")
                        ) {
                            Text(
                                text = "Dodaj",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    AnimatedVisibility(visible = showNoteField) {
                        OutlinedTextField(
                            value = taskNote,
                            onValueChange = { taskNote = it },
                            placeholder = {
                                Text(
                                    text = "Notatka lub termin (np. Do piątku / Hurtownia szkła)...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AvoireTextSecondary
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF171422),
                                unfocusedContainerColor = Color(0xFF171422),
                                focusedBorderColor = AvoireLavenderAccent,
                                unfocusedBorderColor = AvoireBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (showNoteField) "- Ukryj notatkę" else "+ Dodaj notatkę lub termin",
                            style = MaterialTheme.typography.labelMedium,
                            color = AvoireLavenderAccent,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { showNoteField = !showNoteField }
                                .padding(vertical = 2.dp)
                        )

                        Text(
                            text = "${pendingTasks.size} pozostało do zrobienia",
                            style = MaterialTheme.typography.labelMedium,
                            color = AvoireTextSecondary
                        )
                    }
                }
            }
        }

        // 2. Pending Tasks List
        if (pendingTasks.isNotEmpty()) {
            item {
                Text(
                    text = "DO ZROBIENIA (${pendingTasks.size}):",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    ),
                    color = AvoireLavenderAccent
                )
            }

            items(pendingTasks, key = { it.id }) { task ->
                WorkshopTaskRowCard(
                    task = task,
                    onToggle = { onToggleTask(task.id) },
                    onDelete = { onDeleteTask(task.id) }
                )
            }
        }

        // 3. Completed Tasks Section: ZROBIONE (4) (Matches Screenshot 9)
        if (doneTasks.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ZROBIONE (${doneTasks.size}):",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    ),
                    color = AvoireTextSecondary
                )
            }

            items(doneTasks, key = { it.id }) { task ->
                WorkshopTaskRowCard(
                    task = task,
                    onToggle = { onToggleTask(task.id) },
                    onDelete = { onDeleteTask(task.id) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun WorkshopTaskRowCard(
    task: WorkshopTaskEntity,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = AvoireCard,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, AvoireBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onToggle() }
            .testTag("task_item_${task.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Custom Lavender Checkbox (Matches Screenshot 9)
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (task.isDone) Color(0xFFA78BFA) else Color(0xFF1A1726)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (task.isDone) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Wykonane",
                            tint = AvoireBackground,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            textDecoration = if (task.isDone) TextDecoration.LineThrough else TextDecoration.None
                        ),
                        color = if (task.isDone) AvoireTextSecondary else AvoireTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (task.noteOrDeadline.isNotBlank() && !task.isDone) {
                        Text(
                            text = task.noteOrDeadline,
                            style = MaterialTheme.typography.labelSmall,
                            color = AvoireLavenderAccent
                        )
                    }
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Usuń zadanie",
                    tint = AvoireTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
