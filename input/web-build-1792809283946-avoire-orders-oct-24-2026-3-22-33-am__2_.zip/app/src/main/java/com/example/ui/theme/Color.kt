package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nocturnal Lavender / Dark Luxury Palette
val AvoireBackground = Color(0xFF0B0A0F)
val AvoireCard = Color(0xFF13111C)
val AvoireElevated = Color(0xFF1B1828)
val AvoireBorder = Color(0xFF262235)
val AvoireBorderHighlight = Color(0xFF3E355B)

val AvoireLavenderAccent = Color(0xFFC4B5FD)
val AvoirePrimaryButton = Color(0xFF9F7AEA)
val AvoirePrimaryButtonDark = Color(0xFF6D28D9)
val AvoireSoftViolet = Color(0xFF231B38)

val AvoireTextPrimary = Color(0xFFF5F3FF)
val AvoireTextSecondary = Color(0xFFA099B8)
val AvoireTextMuted = Color(0xFF6E6786)

// Status Colors
val StatusAmberText = Color(0xFFFCD34D)
val StatusAmberBg = Color(0xFF2A2012)
val StatusAmberBorder = Color(0xFF523C1E)

val StatusEmeraldText = Color(0xFF6EE7B7)
val StatusEmeraldBg = Color(0xFF10261E)
val StatusEmeraldBorder = Color(0xFF1C4738)

val StatusCoralText = Color(0xFFFDA4AF)
val StatusCoralBg = Color(0xFF2C1219)
val StatusCoralBorder = Color(0xFF59202F)

val StatusLavenderText = Color(0xFFC4B5FD)
val StatusLavenderBg = Color(0xFF1E1736)
val StatusLavenderBorder = Color(0xFF3B2E66)

val StatusSkyText = Color(0xFF38BDF8)
val StatusSkyBg = Color(0xFF0F2233)
val StatusSkyBorder = Color(0xFF1E4464)
