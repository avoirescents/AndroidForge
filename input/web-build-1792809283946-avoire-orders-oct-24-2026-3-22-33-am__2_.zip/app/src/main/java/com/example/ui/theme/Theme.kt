package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val AvoireDarkColorScheme = darkColorScheme(
    primary = AvoirePrimaryButton,
    onPrimary = AvoireTextPrimary,
    primaryContainer = AvoireSoftViolet,
    onPrimaryContainer = AvoireLavenderAccent,
    secondary = AvoireLavenderAccent,
    onSecondary = AvoireBackground,
    secondaryContainer = AvoireElevated,
    onSecondaryContainer = AvoireLavenderAccent,
    tertiary = StatusEmeraldText,
    onTertiary = StatusEmeraldBg,
    tertiaryContainer = StatusEmeraldBg,
    onTertiaryContainer = StatusEmeraldText,
    background = AvoireBackground,
    onBackground = AvoireTextPrimary,
    surface = AvoireCard,
    onSurface = AvoireTextPrimary,
    surfaceVariant = AvoireElevated,
    onSurfaceVariant = AvoireTextSecondary,
    outline = AvoireBorder,
    outlineVariant = AvoireBorderHighlight,
    error = StatusCoralText,
    onError = StatusCoralBg,
    errorContainer = StatusCoralBg,
    onErrorContainer = StatusCoralText
)

val AvoireShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun AvoireOrdersTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AvoireDarkColorScheme,
        typography = Typography,
        shapes = AvoireShapes,
        content = content
    )
}
