package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.FlaconEntity
import com.example.data.NotificationLogItem
import com.example.data.OrderEntity
import com.example.data.OrderStatus
import com.example.data.formatPln

class AvoireNotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ORDER_STATUS = "avoire_order_status_channel"
        const val CHANNEL_STOCK_ALERTS = "avoire_stock_alerts_channel"
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val statusChannel = NotificationChannel(
                CHANNEL_ORDER_STATUS,
                context.getString(R.string.notification_channel_orders_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.notification_channel_orders_desc)
                enableVibration(true)
            }

            val stockChannel = NotificationChannel(
                CHANNEL_STOCK_ALERTS,
                "Alerty magazynowe flakonów Avoire",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Ostrzeżenia o niskim stanie mililitrów w flakonach"
            }

            manager.createNotificationChannel(statusChannel)
            manager.createNotificationChannel(stockChannel)
        }
    }

    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun buildOrderStatusNotification(
        order: OrderEntity,
        newStatus: OrderStatus
    ): NotificationLogItem {
        val scentSummary = order.items.joinToString(", ") {
            "${it.perfumeName} (${it.capacityMl} ml${if (it.isGratis) " gratis" else ""})"
        }
        val shippingTarget = if (order.paczkomatCode.isNotBlank()) {
            "${order.carrier.shortLabel} ${order.paczkomatCode}"
        } else {
            order.carrier.labelPl
        }

        val (title, body, customerTemplate, category) = when (newStatus) {
            OrderStatus.READY_TO_SHIP -> {
                val titleText = "Gotowe do wysyłki • ${order.customerName}"
                val bodyText = "${order.displayTitle} zostało w pełni odlane i czeka na nadanie ($shippingTarget)."
                val custMsg = buildString {
                    append("Dzień dobry ${order.customerName.substringBefore(" ")}! ✨ ")
                    append("Twoje zamówienie w Avoire ($scentSummary) zostało już odlane, zabezpieczone i jest gotowe do wysyłki ")
                    append("przez $shippingTarget. Dam znać od razu po nadaniu paczki!")
                }
                Quad(titleText, bodyText, custMsg, "STATUS_READY")
            }

            OrderStatus.SHIPPED -> {
                val trackingInfo = if (order.trackingNumber.isNotBlank()) {
                    "Nr nadania: ${order.trackingNumber}"
                } else {
                    "Przewoźnik: $shippingTarget"
                }
                val titleText = "Wysłane • ${order.customerName}"
                val bodyText = "Paczka dla ${order.customerName} została oznaczona jako wysłana ($trackingInfo)."
                val custMsg = buildString {
                    append("Dzień dobry ${order.customerName.substringBefore(" ")}! 📦 ")
                    append("Twoja przesyłka z odlewkami Avoire została nadana ($shippingTarget). ")
                    if (order.trackingNumber.isNotBlank()) {
                        append("Numer śledzenia przesyłki: ${order.trackingNumber}. ")
                    }
                    append("Życzę pięknych testów zapachowych!")
                }
                Quad(titleText, bodyText, custMsg, "STATUS_SHIPPED")
            }

            OrderStatus.DECANTING -> {
                val titleText = "W trakcie odlewania • ${order.customerName}"
                val bodyText = "Rozpoczęto przygotowywanie odlewek (${order.readyEntriesCount}/${order.totalEntriesCount} gotowe)."
                val custMsg = "Dzień dobry! Twoje odlewki Avoire ($scentSummary) są właśnie przygotowywane w naszym atelier."
                Quad(titleText, bodyText, custMsg, "STATUS_CHANGE")
            }

            OrderStatus.COMPLETED -> {
                val titleText = "Zamówienie zakończone • ${order.customerName}"
                val bodyText = "${order.displayTitle} (${order.totalWithShippingPln.formatPln()}) zostało pomyślnie zamknięte."
                val custMsg = "Dziękujemy za zakupy w Avoire! Daj znać, jak wrażenia po testach zapachów: $scentSummary ✨"
                Quad(titleText, bodyText, custMsg, "STATUS_CHANGE")
            }

            else -> {
                val titleText = "Status: ${newStatus.labelPl} • ${order.customerName}"
                val bodyText = "Zamówienie ${order.displayTitle} zmieniło status na „${newStatus.labelPl}”."
                val custMsg = "Aktualizacja zamówienia Avoire (${order.displayTitle}): ${newStatus.labelPl}."
                Quad(titleText, bodyText, custMsg, "STATUS_CHANGE")
            }
        }

        postSystemNotification(
            notificationId = (order.id.hashCode() xor newStatus.ordinal),
            channelId = CHANNEL_ORDER_STATUS,
            title = title,
            message = body
        )

        return NotificationLogItem(
            title = title,
            message = body,
            customerMessageTemplate = customerTemplate,
            orderId = order.id,
            category = category
        )
    }

    fun buildLowStockNotification(flacon: FlaconEntity): NotificationLogItem {
        val title = "Niski stan flakonu: ${flacon.fullName}"
        val body = "Pozostało tylko ${flacon.currentVolumeMl} ml (próg alarmowy: ${flacon.lowStockThresholdMl} ml)."

        postSystemNotification(
            notificationId = flacon.id.hashCode(),
            channelId = CHANNEL_STOCK_ALERTS,
            title = title,
            message = body
        )

        return NotificationLogItem(
            title = title,
            message = body,
            customerMessageTemplate = "",
            orderId = null,
            category = "LOW_STOCK"
        )
    }

    private fun postSystemNotification(
        notificationId: Int,
        channelId: String,
        title: String,
        message: String
    ) {
        if (!hasNotificationPermission()) return

        runCatching {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val pendingIntent = PendingIntent.getActivity(context, notificationId, intent, pendingIntentFlags)

            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_avoire_emblem)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            NotificationManagerCompat.from(context).notify(notificationId, notification)
        }
    }

    private data class Quad(
        val first: String,
        val second: String,
        val third: String,
        val fourth: String
    )
}
