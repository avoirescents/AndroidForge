package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.AvoireAiParser
import com.example.data.OrderStatus
import com.example.data.SampleData
import com.example.data.formatPln
import com.example.util.AvoireNotificationHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class ExampleRobolectricTest {

    @Test
    fun `read app_name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Avoire Orders", appName)
    }

    @Test
    fun `formatPln formats currency in Polish style`() {
        assertEquals("245,00 zł", 245.0.formatPln())
    }

    @Test
    fun `local AI parser detects decants, gratis, changes, and matches customer`() {
        val conversation = """
            Klient: Katarzyna Wiśniewska
            Poproszę:
            - Xerjoff Naxos 10 ml
            - Baccarat Rouge 540 Extrait 5 ml
            Jednak zamiast Baccarat Rouge 540 Extrait wezmę Nishane Ani 10 ml
            Initio Oud for Greatness 2 ml gratis do powąchania
            Tel: 602 145 892
        """.trimIndent()

        val result = AvoireAiParser.parseLocally(
            conversationText = conversation,
            knownFlacons = SampleData.initialFlacons,
            knownCustomers = SampleData.initialCustomers
        )

        assertNotNull(result.matchedCustomer)
        assertEquals("WAW101M", result.draftOrder.paczkomatCode)
        assertTrue(result.draftOrder.detectedChangesList.isNotEmpty())
        assertTrue(result.draftOrder.items.any { it.isGratis })
        assertTrue(result.draftOrder.items.any { it.perfumeName.contains("Naxos") && it.capacityMl == 10 })
    }

    @Test
    fun `notification helper creates Ready to Ship and Shipped notifications`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val helper = AvoireNotificationHelper(context)
        val sampleOrder = SampleData.buildInitialOrders().first()

        val readyNotif = helper.buildOrderStatusNotification(sampleOrder, OrderStatus.READY_TO_SHIP)
        assertEquals("STATUS_READY", readyNotif.category)
        assertTrue(readyNotif.title.contains("Gotowe do wysyłki"))
        assertTrue(readyNotif.customerMessageTemplate.isNotBlank())

        val shippedNotif = helper.buildOrderStatusNotification(
            sampleOrder.copy(trackingNumber = "620000123456"),
            OrderStatus.SHIPPED
        )
        assertEquals("STATUS_SHIPPED", shippedNotif.category)
        assertTrue(shippedNotif.customerMessageTemplate.contains("620000123456"))
    }
}
